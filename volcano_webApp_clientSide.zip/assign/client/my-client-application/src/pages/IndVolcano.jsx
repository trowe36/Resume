import React from "react";
import { useEffect, useState } from "react";
import Chart from 'chart.js/auto'; //DONT REMOVE -> produces error even though unused 
import { AuthMapChart } from "../components/AuthMapChart";

export default function IndVolcano({ id }) {
  const { loading, volcano } = useVolcano(id);
  return (
    <div>
      {!loading ? <Headline volcano={volcano} /> : null}
      {!loading ? <AuthMapChart volcano={volcano} /> : null}
    </div>
  )
}

function Headline(props) {
  const { volcano } = props;
  let token = localStorage.getItem("token")

  if (token != null) {
    const { name, country, region, subregion, last_eruption, summit, elevation, latitude, longitude, population_5km, population_10km, population_30km, population_100km } = volcano
    return (
      <div className="Headline">
        <h1>SCROLL TO SEE VOLCANO INFORMATION</h1>
        <h2>Name: {name}</h2>
        <h2>Country:  {country}</h2>
        <h2>Region: {region}</h2>
        <h2>Subregion:  {subregion}</h2>
        <h2>Last_eruption:  {last_eruption}</h2>
        <h2>Summit: {summit}</h2>
        <h2>Elevation:  {elevation}</h2>
        <h2>Latitude: {latitude}</h2>
        <h2>Longitude:  {longitude}</h2>
        <h2>Population_5km: {population_5km}</h2>
        <h2>Population_10km:  {population_10km}</h2>
        <h2>Population_30km:  {population_30km}</h2>
        <h2>Population_100km: {population_100km}</h2>
      </div>
    );
  }

  else {
    const { name, country, region, subregion, last_eruption, summit, elevation, latitude, longitude } = volcano
    return (
      <div className="Headline">
        <h1>SCROLL TO SEE VOLCANO INFORMATION</h1>
        <h2>Name: {name}</h2>
        <h2>Country:  {country}</h2>
        <h2>Region: {region}</h2>
        <h2>Subregion:  {subregion}</h2>
        <h2>Last_eruption:  {last_eruption}</h2>
        <h2>Summit: {summit}</h2>
        <h2>Elevation:  {elevation}</h2>
        <h2>Latitude: {latitude}</h2>
        <h2>Longitude:  {longitude}</h2>
      </div>
    );
  }
}

function useVolcano(id) {
  const [loading, setLoading] = useState(true);
  const [volcano, setVolcano] = useState([]);
  useEffect(() => {
    getForecastByQuery(id).then((data) => {
      setVolcano(data);

      setLoading(false);
    });
  }, [id]);

  return {
    loading,
    volcano
  };
}

function getForecastByQuery(q) {
  let token = localStorage.getItem("token")

  if (token != undefined) {
    const url = 'http://sefdb02.qut.edu.au:3001/volcano/' + q;
    const token = localStorage.getItem("token")
    const headers = {
      accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    }
    return fetch(url, { headers })
      .then((res) => res.json())
      .then((data) =>
      ({
        name: data.name,
        country: data.country,
        region: data.region,
        subregion: data.subregion,
        last_eruption: data.last_eruption,
        summit: data.summit,
        elevation: data.elevation,
        latitude: data.latitude,
        longitude: data.longitude,
        population_5km: data.population_5km,
        population_10km: data.population_10km,
        population_30km: data.population_30km,
        population_100km: data.population_100km,
      }))
  }
  else {
    return fetch('http://sefdb02.qut.edu.au:3001/volcano/' + q)
      .then((res) => res.json())
      .then((data) =>
      ({
        name: data.name,
        country: data.country,
        region: data.region,
        subregion: data.subregion,
        last_eruption: data.last_eruption,
        summit: data.summit,
        elevation: data.elevation,
        latitude: data.latitude,
        longitude: data.longitude
      }))
  }
}

