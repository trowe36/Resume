import React from "react";
import {useState} from "react"
import { Link } from "react-router-dom";

export default function Register() {
  const [name, setName] = useState("");
  const [error, setError] = useState(null);
  const [password, setPassword] = useState("");
  const [registerError, setRegisterError] = useState("")
  const USER_EXISTS = "User already exists"
  const BAD_REQUEST = "Request body incomplete, both email and password are required"
  const USER_CREATED = "User created"

      //regex: http://jsfiddle.net/ghvj4gy9/
  const validateEmail = (email) => {
    return String(email)
      .toLowerCase()
      .match(
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      );
  };

  function RegisterUser(){
    const url = 'http://sefdb02.qut.edu.au:3001/user/register'
    
    if(validateEmail(name)){
      return fetch(url, {
        method: "POST",
        headers: {accept: "application/json", "Content-Type": "application/json"},
        body: JSON.stringify({email: name, password: password})
      })
      .then(res => res.json ())
      .then(res => {
        if(res.message === USER_EXISTS){
          setRegisterError("User already exists")
        }
        if(res.message === BAD_REQUEST){
          setRegisterError("Both email and password are required")
        }        
        if(res.message === USER_CREATED){
          console.log("USER SUCCESSFULLY CREATED")
          window.location.replace("/volcanos");
        }
      })
    }
    else{
      setRegisterError("email not valid")
      return console.log("email is not valid")
      
    }
  }

  return (
    <div className="App">
      <h1>REGISTER</h1>
      {registerError !== "" ? <h1>Error: {registerError}</h1> : null}
      <form
        onSubmit={(event) => {
          event.preventDefault();
        }}
      >
        <label htmlFor="name">Email: </label>
        <input
          id="name"
          name="name"
          type="text"
          value={name}
          onChange={(event) => {
            const newName = event.target.value;
            //check for errors here then set name
            setName(newName);
          }}
        />
        <div>  <label htmlFor="pass">Password: </label>
        <input
          id="pass"
          name ="pass"
          type="text"
          value={password}
          onChange={(event) => {
            const newPassword = event.target.value;
            //check for errors here then set name
            setPassword(newPassword);
          }}
        />
        </div>
      
        <button onClick = {RegisterUser} type="submit">Submit</button>
      </form>
    </div>
  );
  }