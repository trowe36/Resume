import React from "react";

export default function Default() {
    return (
      <section className = "pic" title="A photo of an erupting volcano">
      </section>
    );
  }