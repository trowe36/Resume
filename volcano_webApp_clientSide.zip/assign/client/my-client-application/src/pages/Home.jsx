import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
    return (
      <section className = "pic" title="A photo of an erupting volcano">
      </section>
    );
  }