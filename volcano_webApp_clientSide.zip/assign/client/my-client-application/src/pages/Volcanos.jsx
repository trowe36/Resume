import "../App.css";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-balham.css"
import React, { useState, useEffect} from "react";
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { useBetween } from "use-between";
import IndVolcano from "./IndVolcano";


// // Make a custom hook for sharing your form state between any components
const useFormState = () => {
  const [rowData, setRowData] = useState([])
  const [country, setCountry] = useState('Australia')
  return {
    rowData, setRowData, country, setCountry
  }
}
const useSharedFormState = () => useBetween(useFormState);


export default function Volcanos() {
  const { rowData, setRowData } = useSharedFormState([]);
  const { country, setCountry } = useSharedFormState();
  const [volcId, setVolcId] = useState();
  const [popWithin, setPopWithin] = useState(0)

  const table = {
    columns: [
      { headerName: "Id", field: "id", sortable: true, filter: "agNumberColumnFilter" },
      { headerName: "Name", field: "name", sortable: true, filter: true },
      { headerName: "Country", field: "country", sortable: true, filter: true },
      { headerName: "Region", field: "region", sortable: true, filter: true },
      { headerName: "Subregion", field: "subregion", sortable: true, filter: true }
    ],
  }

  function fetchVolcanoInfo() {
    let fetchLink = 'http://sefdb02.qut.edu.au:3001/volcanoes?country=' + country;
    let acceptHeader = 'volcanoes?country=' + country;
    return fetch(fetchLink, {
      method: "GET", headers: {
        'Accept': acceptHeader
      }
    })
      .then((res) => res.json())
  }
  useEffect(
    () => {

      fetchVolcanoInfo().then((volcanoList) => setRowData(volcanoList));
    },
    [country]
  )

  return (
    <div className="ag-theme-balham">
      <DropDown onSelect={setCountry} />
      <PopulationWithinDropDown onSelect={setPopWithin} />
      <AgGridReact
        columnDefs={table.columns}
        rowData={rowData}
        pagination={true}
        paginationPageSize={15}
        onRowClicked={(row) => setVolcId(row.data.id)}
        rowSelection='single'
      />
      {volcId ? <VolcInfoPane volcId={volcId} /> : null}

    </div>
  );
}

function PopulationWithinDropDown({ onSelect }) {
  const [popWithin, setPopWithin] = useState(0)
  const { rowData, setRowData } = useSharedFormState([])
  const [populationData, setPopulationData] = useState(['Default', '5km', '10km', '30km', '100km'])
  const [countryData, setCountryData] = React.useState([]);
  const { country, setCountry } = useSharedFormState();

  const changePopWithinValue = event => {
    setPopWithin(event.target.value)
    onSelect(event.target.value)
  }

  function fetchCountryAndPopulation() {
    if (popWithin === 0 || popWithin === 'Default') {
      return fetch(`http://sefdb02.qut.edu.au:3001/volcanoes?country=${country}`, {
        method: "GET", headers: {
          'Accept': 'application/json'
        }
      })
        .then((res) => res.json())
    }
    else {
      return fetch(`http://sefdb02.qut.edu.au:3001/volcanoes?country=${country}&populatedWithin=${popWithin}`, {
        method: "GET", headers: {
          'Accept': 'application/json'
        }
      })
        .then((res) => res.json())
    }
  }

  useEffect(
    () => {
      fetchCountryAndPopulation().then((data) => setRowData(data));
    },
    [popWithin, country]
  );

  return (
    <Box sx={{ minWidth: 120 }}>
      <FormControl fullWidth>
        <InputLabel id="demo-simple-select-label">Population within</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={popWithin}
          label="Age"
          onChange={changePopWithinValue}
        >{populationData.map((item) =>
          <MenuItem key={item} value={item} >{item}</MenuItem>)}
        </Select>
      </FormControl>
    </Box>
  );
}

function DropDown({ onSelect }) {
  const [countryData, setCountryData] = React.useState([]);
  const [country, setCountry] = useState('Australia');

  function fetchCountryInfo() {
    return fetch('http://sefdb02.qut.edu.au:3001/countries', {
      method: "GET", headers: {
        'Accept': 'application/json'
      }
    })
      .then((res) => res.json())
  }

  useEffect(
    () => {
      fetchCountryInfo().then((countryList) => setCountryData(countryList));
    },
    []
  );

  const changeCountryValue = event => {
    setCountry(event.target.value)
    onSelect(event.target.value)
  }

  return (
    <div>
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth className="countryClass">
          <InputLabel id="demo-simple-select-label">Country</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={country}
            label="Age"
            onChange={changeCountryValue}
          >{countryData.map((item) =>
            <MenuItem key={item} value={item} >{item}</MenuItem>)}

          </Select>
        </FormControl>
      </Box>
    </div>
  );
}

function VolcInfoPane({ volcId }) {
  const [dataValue, setDataValue] = useState({ data: "" })
  const handleClick = () => {
    setDataValue({ data: volcId });
  };

  if (volcId !== 0) {
    return (
      <div>
        <IndVolcano id={volcId} />
      </div>
    );
  }
  else {
    <div>
      <button onClick={handleClick}>
        Go see volcano
      </button>
    </div>
  }
}

