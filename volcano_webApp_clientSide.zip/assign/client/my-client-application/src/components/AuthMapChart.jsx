import React from "react";
import { Map, Marker, ZoomControl } from "pigeon-maps"
import {useState, useEffect} from "react";

import {Bar} from 'react-chartjs-2'
import {osm} from 'pigeon-maps/providers'


export function AuthMapChart(props) {
  const { volcano } = props;
  const { latitude, longitude, population_5km, population_10km, population_30km, population_100km } = volcano
  const token = localStorage.getItem("token")

  if (token !== null && token !== undefined) {
    return (
      <div>
        <h1>Map and Chart of Chosen Volcano</h1>
        <MyMap latitude={latitude} longitude={longitude} />
        <MyChart pop5km={population_5km} pop10km={population_10km} pop30km={population_30km} pop100km={population_100km} />
      </div>
    );
  }
  else {
    return (
      <div>
        <h1>Map of Chosen Volcano</h1>
        <MyMap latitude={latitude} longitude={longitude} />
      </div>
    );
  }
}


export function MyMap(props) {
  const [hue, setHue] = useState(0)
  const latitude = parseFloat(props.latitude)
  const longitude = parseFloat(props.longitude)
  const color = `hsl(${hue % 360}deg 39% 70%)`
  const HEIGHT = 300
  const ZOOM = 5
  const WIDTH = 50;


  const [center, setCenter] = useState([Number(props.latitude), Number(props.longitude)])
  useEffect(() => {
    setCenter([Number(props.latitude), Number(props.longitude)])
  }, [props]);

  return (
    <Map provider={osm} height={HEIGHT} defaultCenter={[latitude, longitude]} defaultZoom={ZOOM} center={center}>
      <Marker
        width={WIDTH}
        anchor={center}
        color={color}
        onClick={() => setHue(hue + 20)}
      />
      <ZoomControl />
    </Map>
  )
}
  

export function MyChart(props) {
  const [km5, setkm5] = useState(0)
  const [km10, setkm10] = useState(0)
  const [km30, setkm30] = useState(0)
  const [km100, setkm100] = useState(0)

  useEffect(() => {
    setkm5(Number(props.pop5km))
    setkm10(Number(props.pop10km))
    setkm30(Number(props.pop30km))
    setkm100(Number(props.pop100km))
    }, [props]);  


  const dataAndLabel = {
    labels: ['5km', '10km', '30km',
             '100km'],
    datasets: [
      {
        label: 'Population Density',
        backgroundColor: 'rgba(75,192,192,1)',
        borderColor: 'rgba(0,0,0,1)',
        borderWidth: 2,
        data: [km5, km10, km30, km100]
      }
    ]
  }
  return(
    <div className="chart-component">
      <Bar
          data={dataAndLabel}
          options={{
            title:{
              display:true,
              text:'Population Density',
              fontSize:20
            },
            legend:{
              display:true,
              position:'right'
            }
          }}
        />
        <div className="child-chart"></div>
    </div>
  )
}