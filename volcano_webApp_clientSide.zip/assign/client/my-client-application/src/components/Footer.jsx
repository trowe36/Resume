import React from "react";
import "../App.css";

// the footer
export default function Footer() {
  return (
    <footer>
      <span>
        Volcano Assignment 1 Tom Rowen
        <br />
        Copyright &copy; 2022{" "}
      </span>
    </footer>
  );
}
