﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Assignment
{
    public class Member : iMember, IComparable<Member>
    {
        public string firstName;
        public string lastName;
        public static string contactNumber;
        public static string pin;
        public static int toolsBorrowed;
        public string[] tools = new string[3];
        public static int toolCount = 0;
        public Member() //constructor for use in toollibsystem. eg is not an actual member registered in the system. just for method accessibility
        {

        }
        public Member(string firstName, string lastName, string contactNumber, string pin)
        {
            FirstName = firstName;
            LastName = lastName;
                ContactNumber = contactNumber;   
            PIN = pin;
            toolsBorrowed = 0;
            //constructer
        }// can create more than one constructer (to find another member, create a temporary member so that you can search in the bst. )
        public Member(string firstName, string lastName, string contactNumber)
        {
            FirstName = firstName;
            LastName = lastName;
            ContactNumber = contactNumber;
            //PIN = "xxxx";          REMOVED BECAUSE "XXXX" WOULD OVERRIDE CONTACTNUMBER. SEE MAINMENU()
            toolsBorrowed = 0;
            //constructer
        }// can create more than one constructer (to find another member, create a temporary member so that you can search in the bst. )
        public Member(string fistName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }
        public Member(string firstName, string lastName, string[] toolPlacehold)
        {
            FirstName = firstName;
            LastName = lastName;
            tools = toolPlacehold;
        }
        public string FirstName 
        { 
            get { return firstName; }
            set { firstName = value; }
        }
        public string LastName 
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string ContactNumber
        {
            get { return contactNumber; }
            set { contactNumber = value; }
        }
        public string PIN
        {
            get { return pin; }
            set { pin = value; }
        }
            
        public int ToolsBorrowed//dont need probs
        {
            get { return toolsBorrowed; }
            set { toolsBorrowed = value; }
        }
        public string[] Tools
        {
            get { return tools; }
            set { tools = value; }//wont save properly to array
        }

        public bool MemberHasTool(Member aMember, Tool aTool)
        {
            foreach (string toolN in aMember.Tools)
            {
                if (toolN == aTool.Name)
                {
                    return true;
                }
            }
            return false;
        }

        public void addTool(Tool aTool)
        {
            if (Tools[0] == null)
            {
                tools[0] += aTool.Name.ToString();
                ToolsBorrowed++;
            }
            else if (Tools[Tools.Length - 2] == null)//if second position is free
            {
                tools[1] += aTool.Name.ToString();
                ToolsBorrowed++;
            }
            else if (Tools[Tools.Length - 1] == null)
            {
                tools[2] += aTool.Name.ToString();
                ToolsBorrowed++;
            }

            //tools[]
        }


        public int CompareTo(Member obj) // compare last names then compare first names. // go steal custeomer object bst wk 5 example. compare to method there
        {
            Member memberTmp = (Member)obj;

                if (this.lastName.CompareTo(memberTmp.LastName) < 0) //maybe add null check
                    return -1;
                else
                if (this.lastName.CompareTo(memberTmp.LastName) == 0)
                    return this.firstName.CompareTo(memberTmp.FirstName);
                else
                    return 1;           
        }

        public void deleteTool(Tool aTool)
        {
            for (int i = 0; i < Tools.Length; i++) //this should be amember.tools.count. 
            {
                if (Tools[i] == aTool.Name.ToString())
                {
                    Tools[i] = null; //dummy variable.
                    ToolsBorrowed--;
                    Console.WriteLine("Tool was successfully returned to the tool library");
                    return; // only want to return one tool of same name (works)
                }
            }
        }
        public override string ToString()
        {
            return this.FirstName + this.LastName + this.ContactNumber;
        }
        public string MemberAddedMsg()
        {
            return "The member " + this.FirstName + " " + this.LastName + " was successfully added to member list \t" + "(" + this.ContactNumber + ")";
        }

        void iMember.addTool(iTool aTool)
        {
            throw new NotImplementedException();
        }

        void iMember.deleteTool(iTool aTool)
        {
            throw new NotImplementedException();
        }
    }
}
