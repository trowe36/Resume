﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment
{
    public class BTreeNode
    {
        private Member aMember; // value
        private BTreeNode lchild; // reference to its left child 
        private BTreeNode rchild; // reference to its right child

        public BTreeNode(Member aMember)
        {
            this.aMember = aMember;
            lchild = null;
            rchild = null;
        }

        public Member Member
        {
            get { return aMember; }
            set { aMember = value; }
        }

        public BTreeNode LChild
        {
            get { return lchild; }
            set { lchild = value; }
        }

        public BTreeNode RChild
        {
            get { return rchild; }
            set { rchild = value; }
        }
    }

    public class MemberCollection : iMemberCollection
    {

        private BTreeNode root;
        private int numberMembers;
        public Member[] memberArray; //declare size later in preodertraverse method
        private int memberArrayCountVar;

        public MemberCollection()
        {

            root = null; //need logic here to ensure new collection isnt made every time a member is made. 
        }

        public int Number  //get the number of members in the community library
        {
            get { return numberMembers; }
            set { numberMembers = value; }
        }

        public void add(Member aMember)
        {
            if (root == null)
            {
                root = new BTreeNode(aMember);
                numberMembers++;
            }
            else
            {
                add(aMember, root);
            }
        }

        public void add(Member aMember, BTreeNode ptr)
        {
            if (aMember.CompareTo(ptr.Member) < 0)
            {
                if (ptr.LChild == null)
                {
                    ptr.LChild = new BTreeNode(aMember);
                    numberMembers++;
                }
                else
                {
                    add(aMember, ptr.LChild);
                }
            }
            else
            {
                if (ptr.RChild == null)
                {
                    ptr.RChild = new BTreeNode(aMember);
                    numberMembers++;
                }
                else
                {
                    add(aMember, ptr.RChild);
                }
            }
        }

        public void delete(Member aMember) // add functionality to remove them from borrow list
        {
            // search for item and its parent
            BTreeNode ptr = root; // search reference
            BTreeNode parent = null; // parent of ptr
            while ((ptr != null) && (aMember.CompareTo(ptr.Member) != 0))
            {
                parent = ptr;
                if (aMember.CompareTo(ptr.Member) < 0) // move to the left child of ptr
                    ptr = ptr.LChild;
                else
                    ptr = ptr.RChild;
            }

            if (ptr != null) // if the search was successful
            {
                // case 3: item has two children
                if ((ptr.LChild != null) && (ptr.RChild != null))
                {
                    // find the right-most node in left subtree of ptr
                    if (ptr.LChild.RChild == null) // a special case: the right subtree of ptr.LChild is empty
                    {
                        ptr.Member = ptr.LChild.Member;
                        ptr.LChild = ptr.LChild.LChild;
                        numberMembers--;
                    }
                    else
                    {
                        BTreeNode p = ptr.LChild;
                        BTreeNode pp = ptr; // parent of p
                        while (p.RChild != null)
                        {
                            pp = p;
                            p = p.RChild;
                        }
                        // copy the item at p to ptr
                        ptr.Member = p.Member;
                        pp.RChild = p.LChild;
                        numberMembers--;
                    }
                }
                else // cases 1 & 2: item has no or only one child
                {
                    BTreeNode c;
                    if (ptr.LChild != null)
                        c = ptr.LChild;
                    else
                        c = ptr.RChild;

                    // remove node ptr
                    if (ptr == root) //need to change root
                    {
                        numberMembers--;
                        root = c;
                    }
                        
                    
                    else
                    {
                        if (ptr == parent.LChild)
                            parent.LChild = c;
                        else
                            parent.RChild = c;
                        numberMembers--;
                    }
                }
            }
        }

        public bool search(Member aMember)
        {
            return search(aMember, root);
        }

        public bool search(Member aMember, BTreeNode r) // if search returns true. member (parameter) exists in collection
        {
            {
                if (r != null)
                {
                    if (aMember.CompareTo(r.Member) == 0)
                        return true;
                    else
                        if (aMember.CompareTo(r.Member) < 0)
                        return search(aMember, r.LChild);
                    else
                        return search(aMember, r.RChild);
                }
                else
                    return false;
            }
        }


        public Member[] toArray() // do a traversal, each time you visit a node, add item to array, see example. 
        {
            memberArrayCountVar = 0;
            //factor size of array declared at top of class
            memberArray = new Member[numberMembers];
            PreOrderTraverse();
            return memberArray;           
        }
        public void PreOrderTraverse()
        {
            PreOrderTraverse(root);
        }

        private void PreOrderTraverse(BTreeNode root)
        {
            if (root != null)
            {
                Member tempMember = new Member(root.Member.firstName, root.Member.lastName, root.Member.tools);
                memberArray[memberArrayCountVar] = tempMember;
                memberArrayCountVar++;                
                PreOrderTraverse(root.LChild);
                PreOrderTraverse(root.RChild);
            }
        }
    }
}
