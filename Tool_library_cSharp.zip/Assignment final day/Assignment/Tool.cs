﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Assignment
{
    public class Tool : iTool, IComparable<Tool> //maybe icomparable to search to tools (teacher)
    {
        public int quantity;
        public string name;
        public static int availableQuantity;
        public int noBorrowings;
        public int toolCategory;
        public string toolType;
        private static MemberCollection memberCollection;
   

        //-------------------------COUNTER VARIABLES FOR TOOL TYPE ARRAY INCREMENT
        //-------------------------
        public Tool(string name)
        {
            Name = name;
            memberCollection = new MemberCollection();
        }
     
        public Tool(string name, int quantity, int availableQuantity) : this(name)//calls constructor above first. 
        {
            Quantity = quantity;
            AvailableQuantity = availableQuantity;
            //NoBorrowings = noBorrowings;
        }

        public string Name 
        {
            get { return name; }
            set { name = value; }
        }
        public int Quantity 
        { 
            get { return quantity; }
            set { quantity = value; }
        }
        public int AvailableQuantity 
        {
            get { return Quantity - memberCollection.Number; } //available quanity is quantity of tool minus number borrowed in membercollection
            set { Quantity = value + memberCollection.Number; } 
        }
        public int NoBorrowings
        {
            get { return memberCollection.Number; }
            set { memberCollection.Number = value; }
        }


        public MemberCollection GetBorrowers => memberCollection;  //just acts like a getter for the collection


        public int CompareTo([AllowNull] Tool other)// to find tools
        {
            throw new NotImplementedException();
        }


        public void addBorrower(Member aMember)
        {
            if (availableQuantity <= 0) //FIX
            {
                Console.WriteLine("We cannot loan out tool as they are all on loan");
            }
            else
            {
                memberCollection.add(aMember);
                AvailableQuantity--;
                NoBorrowings++;
            }
        }

        public void deleteBorrower(Member aMember)
        {
            memberCollection.delete(aMember);
            AvailableQuantity++;
        }


    }
}
