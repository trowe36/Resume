﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment
{
    class MainClass 
    {
        public static MemberCollection memberCollection = new MemberCollection();
        public static ToolCollection toolCollection = new ToolCollection();
        public static ToolLibrarySystem toolLibrarySystem = new ToolLibrarySystem(memberCollection);
        public static bool hasLoggedIn = false;
        public static bool memberLoggedIn = false;
        public static Member CurrentLoggedMBR; //program is code to hold 15 registered members at a time. ths could be changed 
        protected static void InitialiseCounters()
        {
            memberCollection.Number = 0;
            toolCollection.lineTrimmerCount = 0;
        }

        //public static tool[,] gardeningToolsArray = new tool[8, 30]; // 9 types of gardening tools. fist column denotes type. second column denotes tool eg
        //initialise number of members in collection to 0


        public static void StartMenu() 
        {
            bool mainMenuDisplay = true;
            bool staffMenuDisplay = true;
            bool memberMenuDisplay = true;

            while (mainMenuDisplay)
            {
                mainMenuDisplay = MenuMain();
            }
            while (staffMenuDisplay)
            {
                staffMenuDisplay = MenuStaff();
            }
            while (memberMenuDisplay)
            {
                memberMenuDisplay = MenuMember();
            }
        }
        public static bool MenuMain()
        {
            memberLoggedIn = false;
            Console.WriteLine("Welcome to the Tool Library");
            Console.WriteLine("===========Main Menu===========");
            Console.WriteLine("1. Staff Login");
            Console.WriteLine("2. Member Login");
            Console.WriteLine("0. Exit");
            Console.WriteLine("===============================");
            Console.WriteLine("\nPlease make a selection (1-2, or 0 exit):");

            switch (Console.ReadLine())
            {
                case "1":
                    MenuStaff();
                    return true;
                case "2":
                    MenuMember();
                    return true;
                case "0":
                    ExitMenu();
                    return false;
                default:
                    Console.WriteLine("Enter valid option: ");
                    Console.ReadKey();
                    MenuMain();
                    return true;
            }
        }


        private static void ExitMenu()
        {
            Environment.Exit(0);//check:  if ok with marking
        }

        private static void StaffSelection(string selection)
        {
            if (selection == "0") // see staff menu for option meanings
            {
                MenuMain();
            }
            else if (selection == "1")
            {
                Console.WriteLine("Please enter in order: \n1. Tool Category (number) \n2. Tool Type (number 1 - 50) \n3. Tool Name (string)");
                string toolCatt = Console.ReadLine();
                int toolCat;
                string toolType = Console.ReadLine();
                string toolName = Console.ReadLine();
                Tool newTool = new Tool(toolName);

                if (int.TryParse(toolCatt, out toolCat))
                {
                    newTool.toolCategory = toolCat;
                }
                else
                {
                    Console.WriteLine("Please enter integer representation of tool category (1-9) ");
                    Console.ReadKey();
                    MenuStaff();
                }
                //newTool.toolCategory = (int.Parse(toolCatt, out toolCat));
                newTool.toolType = toolType;

                toolLibrarySystem.add(newTool);
                Console.WriteLine("New tool added: " + toolName);
                MenuStaff();
            }
            else if (selection == "2")
            {
                Console.WriteLine("Please enter in order: \n1. Tool type (number) \n2. Tool Name (string) \n3. Quantity to add");
                
                string toolType = Console.ReadLine();
                string toolName = Console.ReadLine();
                string quantityString = Console.ReadLine();
                int quantity;
                
                if (int.TryParse(quantityString, out quantity))
                {
                    
                }
                else
                {
                    Console.WriteLine("Quantity was not an integer");
                    MenuStaff();
                }
                int.Parse(quantityString);
                Tool newTool = new Tool(toolName);
                newTool.toolCategory = (int.Parse(toolType));
                newTool.toolType = toolType;
                //check if existsss first
                if (toolCollection.search(newTool))// if the new tools search is true
                {
                    Console.WriteLine("The tool exists in the library, adding " + quantityString + " more to the collection");
                    toolLibrarySystem.add(newTool, quantity);
                }
                else
                {
                    Console.WriteLine("Could not add new pieces of the tool as it does not exist in the library");
                }
                
                Console.ReadKey();
                MenuStaff();
            }
            else if (selection == "3")
            {
                Console.WriteLine("Please enter: \n1. Name of tool to be deleted \n2. Type of tool (1 - 50)");
                string toolName = Console.ReadLine();
                string toolTypeString = Console.ReadLine();

                Tool deleteTool = new Tool(toolName);
                deleteTool.toolType = toolTypeString;

                if (toolCollection.search(deleteTool))
                {
                    toolLibrarySystem.delete(deleteTool);                    
                }
                else// the tool does not exist. 
                {
                    Console.Write("The tool to be deleted does not exist in the system");
                }


            }
            else if (selection == "4")//register a new member
            {
                NotMemberMenu(); // go to menu to create new member
            }
            else if (selection == "5") // delete a memeber
            {
                Console.Write("Please enter the following details of member to be deleted:\n1. First Name: ");
                string firstN = Console.ReadLine();
                Console.Write("2. Last Name: ");
                string lastN = Console.ReadLine();
                string phNumber = "dummy";
                Member newMember = new Member(firstN, lastN, phNumber);
                if (memberCollection.search(newMember))
                {
                    Console.WriteLine(newMember.ToString() + "is a registered user. Deleting membership now...");
                    toolLibrarySystem.delete(newMember);
                    Console.ReadKey();
                    MenuMain();
                    //delete function
                }
                else
                {
                    Console.WriteLine("Could not delete member as they do not exist in the system");
                    MenuMain();
                }
            }

            else if (selection == "6") //find contact number of member
            {
                Console.WriteLine("To find the contact information of a member enter:\n1. First Name");
                string firstN = Console.ReadLine();
                Console.WriteLine("2. LastName");
                string lastN = Console.ReadLine();
                bool memberExists = false;
                //Member tmpMember = new Member(firstN, lastN);
                //login with details

                Member[] members = memberCollection.toArray();//get members
                for (int i = 0; i < members.GetLength(0); i++)
                {
                    if (members[i].FirstName == firstN && members[i].LastName == lastN)
                    {
                        Console.WriteLine("Member Exists: First Name: " + members[i].FirstName + "\t Last Name: " + members[i].LastName + "\t Contact: " + members[i].ContactNumber);
                        memberExists = true;
                    }
                }
                if (memberExists != true)
                {
                    Console.WriteLine("The member does not exist");
                }
                Console.ReadKey();
                MenuStaff();

            }
            else if (selection == "7")
            {
                Console.WriteLine("Tembers registered with tool library: " + memberCollection.Number);
                Console.ReadKey();
                MenuStaff();
            }
            MenuStaff();
        }

        private static bool MenuStaff()
        {
            if (hasLoggedIn == false)
            {
                Console.Clear();
                Console.Write("Staff Username: ");
                string username = Console.ReadLine();
                Console.Write("Staff Password: ");
                string password = Console.ReadLine();
                if (username == "staff" && password == "today123")
                {
                    hasLoggedIn = true;
                    Console.WriteLine("Welcome to the Tool Library");
                    Console.WriteLine("================Staff Menu===============");
                    Console.WriteLine("1. Add a new tool");
                    Console.WriteLine("2. Add new pieces of an existing tool");
                    Console.WriteLine("3. Remove a tool");
                    Console.WriteLine("4. Register a new member");
                    Console.WriteLine("5. Remove a member");
                    Console.WriteLine("6. Find the contact number of a member");
                    Console.WriteLine("7. Return number of members registered");
                    Console.WriteLine("0. Return to main menu");
                    Console.WriteLine("==========================================");
                    Console.WriteLine("\nPlease make a selection (1-6, or 0 to return to main menu):");
                    string selection = Console.ReadLine();
                    StaffSelection(selection);
                }
                else
                {
                    Console.WriteLine("Username or Password was incorrect, options:\n1. Try Again \n2. Back to main menu");
                    string selection = Console.ReadLine();
                    if (selection == "1")
                    {
                        MenuStaff();
                    }
                    else if (selection == "2")
                    {
                        MenuMain();
                    }
                    else
                    {
                        Console.WriteLine("Please select a valid option");
                    }
                }
            }
            else // they have aready logged into system. password not required. 
            {
                Console.WriteLine("Welcome to the Tool Library");
                Console.WriteLine("================Staff Menu===============");
                Console.WriteLine("1. Add a new tool");
                Console.WriteLine("2. Add new pieces of an existing tool");
                Console.WriteLine("3. Remove a tool");
                Console.WriteLine("4. Register a new member");
                Console.WriteLine("5. Remove a member");
                Console.WriteLine("6. Find the contact number of a member");
                Console.WriteLine("7. Return number of members registered");
                Console.WriteLine("0. Return to main menu");
                Console.WriteLine("==========================================");
                Console.WriteLine("\nPlease make a selection (1-6, or 0 to return to main menu):");
                string selection = Console.ReadLine();
                StaffSelection(selection);
            }

            return true; 
        }


        private static void ShowToolTypes(string catSelected)
        {
            if (catSelected == "1")
            {
                Console.WriteLine("1. Line Trimmers");
                Console.WriteLine("2. Lawn Mowers");
                Console.WriteLine("3. Hand Tools");
                Console.WriteLine("4. WheelBarrows");
                Console.WriteLine("5. Garden Power Tools");
                Console.WriteLine("Enter to exit: ");
                Console.ReadKey();
            }
            else if (catSelected == "2")
            {
                Console.WriteLine("6 Scrapers");
                Console.WriteLine("7. Floor Lasers");
                Console.WriteLine("8. Floor Levelling Tools");
                Console.WriteLine("9. Floor Levelling Materials");
                Console.WriteLine("10. Floor Hand Tools");
                Console.WriteLine("11. Tiling Tools");
                Console.WriteLine("Enter to exit: ");
                Console.ReadKey();
            }
            else if (catSelected == "3")
            {
                Console.WriteLine("12. Hand Tools");
                Console.WriteLine("13. Electric Fencing");
                Console.WriteLine("14. Steel Fencing Tools");
                Console.WriteLine("15. Power Tools");
                Console.WriteLine("16. Fencing Accessories");
                Console.WriteLine("Enter to exit: ");
                Console.ReadKey();
            }
            else if (catSelected == "4")
            {
                Console.WriteLine("17. Distance Tools");
                Console.WriteLine("18. Laser Measurer");
                Console.WriteLine("19. Measuring Jugs");
                Console.WriteLine("20. Temperature & Humidity Tools");
                Console.WriteLine("21. Levelling Tools");
                Console.WriteLine("22. Markers");
                Console.WriteLine("Enter to exit: ");
                Console.ReadKey();
            }
            else if (catSelected == "5")
            {
                Console.WriteLine("23. Draining");
                Console.WriteLine("24. Car Cleaning");
                Console.WriteLine("25. Vacuum");
                Console.WriteLine("26. Pressure Cleaners");
                Console.WriteLine("27. Pool Cleaning");
                Console.WriteLine("28. Pool Cleaning");
                Console.WriteLine("29. Floor Cleaning");
                Console.WriteLine("Enter to exit: ");
                Console.ReadKey();
            }
            else if (catSelected == "6")
            {
                Console.WriteLine("30. Sanding Tools");
                Console.WriteLine("31. Brushes");
                Console.WriteLine("32. Rollers");
                Console.WriteLine("33. Paint Removal Tools");
                Console.WriteLine("34. Paint Scrapers");
                Console.WriteLine("35. Sprayers");
                Console.WriteLine("Enter to exit: ");
                Console.ReadKey();
            }
            else if (catSelected == "7")
            {
                Console.WriteLine("36. Voltage Tester");
                Console.WriteLine("37. Oscilloscopes");
                Console.WriteLine("38. Thermal Imaging");
                Console.WriteLine("39. Data Test Tool");
                Console.WriteLine("40. Insulation Testers");
                Console.ReadKey();
            }
            else if (catSelected == "8")
            {
                Console.WriteLine("41. Testy Equipment");
                Console.WriteLine("42. Safety Equipment");
                Console.WriteLine("43. Basic hand Tools");
                Console.WriteLine("44. Circuit Protection");
                Console.WriteLine("45. Cable Tools");
                Console.WriteLine("Enter to exit: ");
                Console.ReadKey();
            }
            else if (catSelected == "9")
            {
                Console.WriteLine("45. Jacks");
                Console.WriteLine("46. Air Compressors");
                Console.WriteLine("47. Battery Chargers");
                Console.WriteLine("48. Socket Tools");
                Console.WriteLine("49. Braking ");
                Console.WriteLine("50. Drivetrain");
                Console.ReadKey();
            }
            else if (catSelected == "10")
            {
                string x = ShowToolType();
                Console.ReadKey();
            }
            else if (catSelected == "0")//exit to main menu
            {
                ShowMemberOptions();
            }
            Console.WriteLine("Press 1 to exit or 0 to continue looking at types ");

            string y = Console.ReadLine();
            if (y == "0")
            {
                ShowToolCatagories();
            }
            else if (y == "1")
            {
                ShowMemberOptions();
            }


        }

        private static void ShowToolCatagories()
        {
            Console.WriteLine("Select a tool category(number) or 10 to show all tool types and numbers for program use: ");
            Console.WriteLine("1. Gardening Tools");
            Console.WriteLine("2. Flooring Tools");
            Console.WriteLine("3. Fencing Tools");
            Console.WriteLine("4. Measuring Tools");
            Console.WriteLine("5. Cleaning Tools");
            Console.WriteLine("6. Painting Tools");
            Console.WriteLine("7. Electronic Tools");
            Console.WriteLine("8. Electricity Tools");
            Console.WriteLine("9. Automotive Tools");
            Console.WriteLine("10. Show all tool types");
            Console.WriteLine("0. Return to Member Menu");
            string selection = Console.ReadLine();
            ShowToolTypes(selection);
            
        }
        private static void ShowMemberOptions()
        {
            Console.WriteLine("Welcome to the Tool Library");
            Console.WriteLine("==========================Member Menu==========================");
            Console.WriteLine("1. Display all the tools of a tool type");
            Console.WriteLine("2. Borrow a tool");
            Console.WriteLine("3. Return a tool");
            Console.WriteLine("4. List all the tools that I am renting");
            Console.WriteLine("5. Display top three (3) most fequentely rented tools");
            Console.WriteLine("6. Tool types and tool categories");
            Console.WriteLine("0. Return to main menu");
            Console.WriteLine("===============================================================");
            Console.WriteLine("\nPlease make a selection (1-5, or 0 to return to main menu):");
            string selection = Console.ReadLine();          
            if (selection == "0")
            {
                MenuMain();
            }
            MemberSelection(selection);


        }
        private static string ShowToolType()
        {
            Console.WriteLine("Types (1 - 50) and Categories: ");
            Console.WriteLine("-----------------------------Gardening Tools---------------------------- - ");
            Console.WriteLine("1. Line Trimmers");
            Console.WriteLine("2. Lawn Mowers");
            Console.WriteLine("3. Hand Tools");
            Console.WriteLine("4. WheelBarrows");
            Console.WriteLine("5. Garden Power Tools");
            Console.WriteLine("----------------------------- Flooring Tools -----------------------------");
            Console.WriteLine("6 Scrapers");
            Console.WriteLine("7. Floor Lasers");
            Console.WriteLine("8. Floor Levelling Tools");
            Console.WriteLine("9. Floor Levelling Materials");
            Console.WriteLine("10. Floor Hand Tools");
            Console.WriteLine("11. Tiling Tools");
            Console.WriteLine("----------------------------- Fencing Tools -----------------------------");
            Console.WriteLine("12. Hand Tools");
            Console.WriteLine("13. Electric Fencing");
            Console.WriteLine("14. Steel Fencing Tools");
            Console.WriteLine("15. Power Tools");
            Console.WriteLine("16. Fencing Accessories");
            Console.WriteLine("----------------------------- Measuring Tools -----------------------------");
            Console.WriteLine("17. Distance Tools");
            Console.WriteLine("18. Laser Measurer");
            Console.WriteLine("19. Measuring Jugs");
            Console.WriteLine("20. Temperature & Humidity Tools");
            Console.WriteLine("21. Levelling Tools");
            Console.WriteLine("22. Markers");
            Console.WriteLine("----------------------------- Cleaning Tools -----------------------------");
            Console.WriteLine("23. Draining");
            Console.WriteLine("24. Car Cleaning");
            Console.WriteLine("25. Vacuum");
            Console.WriteLine("26. Pressure Cleaners");
            Console.WriteLine("27. Pool Cleaning");
            Console.WriteLine("28. Pool Cleaning");
            Console.WriteLine("29. Floor Cleaning");
            Console.WriteLine("----------------------------- Painting Tools -----------------------------");
            Console.WriteLine("30. Sanding Tools");
            Console.WriteLine("31. Brushes");
            Console.WriteLine("32. Rollers");
            Console.WriteLine("33. Paint Removal Tools");
            Console.WriteLine("34. Paint Scrapers");
            Console.WriteLine("35. Sprayers");
            Console.WriteLine("----------------------------- Electronic Tools -----------------------------");
            Console.WriteLine("36. Voltage Tester");
            Console.WriteLine("37. Oscilloscopes");
            Console.WriteLine("38. Thermal Imaging");
            Console.WriteLine("39. Data Test Tool");
            Console.WriteLine("40. Insulation Testers");
            Console.WriteLine("----------------------------- Electricity Tools -----------------------------");
            Console.WriteLine("41. Testy Equipment");
            Console.WriteLine("42. Safety Equipment");
            Console.WriteLine("43. Basic hand Tools");
            Console.WriteLine("44. Circuit Protection");
            Console.WriteLine("45. Cable Tools");
            Console.WriteLine("----------------------------- Automotive Tools -----------------------------");
            Console.WriteLine("45. Jacks");
            Console.WriteLine("46. Air Compressors");
            Console.WriteLine("47. Battery Chargers");
            Console.WriteLine("48. Socket Tools");
            Console.WriteLine("49. Braking ");
            Console.WriteLine("50. Drivetrain");
            string selection = Console.ReadLine();
            return selection;
        }
        private static void MemberSelection(string selection)
        {
            if (selection == "1")
            {
                Console.WriteLine("What type of tool would you like to display? ");
                string choice = ShowToolType();
                toolLibrarySystem.displayTools(choice);//display chosen type based on user
                Console.ReadKey();
                ShowMemberOptions();
            }
            else if (selection == "2") //GIVES ERROR WHEN SEARCHING IF MEMBER EXISTS.
            { // enter member name -> search membercollection.toArray() - >if they are in array, remember that array index. -> search tool -> if available -add to that member.tools[] at the saved
                //membercollection array index. 

                //Console.WriteLine("Please enter: \n1. Firstname: \n2. Last Name: \n3. Pin");
                //string firstN = Console.ReadLine();
                //string lastN = Console.ReadLine();
                //string pin = Console.ReadLine();
                // Member member = new Member(firstN, lastN);
                //if (memberCollection.search(member))//exists in tree. therefore they can borrow
                //{
                if (memberLoggedIn)
                {
                    Member[] members = memberCollection.toArray();//get member collection into array
                    for (int i = 0; i < memberCollection.Number; i++) //first member in array that matches first and last name. update tools[]
                    {
                        if (members[i].FirstName == CurrentLoggedMBR.FirstName && members[i].LastName == CurrentLoggedMBR.LastName && members[i].PIN == CurrentLoggedMBR.PIN)
                        {
                            Console.Write("Please enter: \n1. Name of tool: \n2. Tool type (as number 1-50)");
                            string toolName = Console.ReadLine();
                            //if tool exists in system. borrow tool
                            Tool toolTmp = new Tool(toolName);
                            toolTmp.toolType = Console.ReadLine();

                            if (toolCollection.search(toolTmp)) // tool with that name exists in [,] arrays. //maybe check others
                            {
                                toolLibrarySystem.borrowTool(members[i], toolTmp);
                            }
                        }
                    }
                }
               
                Console.ReadKey();
                ShowMemberOptions();

            }
            else if (selection == "3")
            {
                Console.WriteLine("To return a tool please enter: \n1. Firstname: \n2. Last Name: \n3. Pin");
                string firstN = Console.ReadLine();
                string lastN = Console.ReadLine();
                string pin = Console.ReadLine();
                Member[] members = memberCollection.toArray();//get member collection into array
                //search the array for member
                for (int i = 0; i < memberCollection.Number; i++)
                {
                    if (members[i].firstName == firstN && members[i].lastName == lastN && members[i].PIN == pin)//true -> member is valid
                    {
                        Console.WriteLine("The tools are currently borrowing are: ");
                        toolLibrarySystem.displayBorrowingTools(members[i]);
                        Console.WriteLine("Which tool would you like to return?");
                        Console.Write("Please enter: \n1. Name of tool: \n2. Tool type (as number 1-35)");
                        string toolN = Console.ReadLine();
                        string tType = Console.ReadLine();
                        Tool toolTmp = new Tool(toolN);
                        toolTmp.toolType = tType;
                        //check if member currently has that tool before returning. 

                        toolLibrarySystem.returnTool(members[i], toolTmp);
                        
                        Console.ReadKey();
                       // string toolName = Console.ReadLine();
                        //if tool exists in system. borrow tool
                       // Tool toolTmp = new Tool(toolName);
                        //toolTmp.toolType = Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("Not a valid member");
                    }
                }

                Console.ReadKey();
                ShowMemberOptions();
            }
            else if (selection == "4") //display tools that are being rented by the user
            {
                Console.WriteLine("Please enter: \n1. Firstname: \n2. Last Name: \n3. Pin");
                string firstN = Console.ReadLine();
                string lastN = Console.ReadLine();
                string pin = Console.ReadLine();
                Member[] members = memberCollection.toArray();

                for (int i = 0; i < memberCollection.Number; i++) //first member in array that matches first and last name. update tools[]
                {
                    if (members[i].firstName == firstN && members[i].lastName == lastN && members[i].PIN == pin)
                    {
                        Console.WriteLine("The user is currently borrowing the following tools: ");
                        toolLibrarySystem.displayBorrowingTools(members[i]);
                    }
                    else
                    {
                        Console.WriteLine("Please ensure you enter the correct name, surname and pin");
                    }
                }
                Console.ReadKey();
                ShowMemberOptions();
            }
            else if (selection == "5")
            {
                toolLibrarySystem.displayTopThree();
                Console.ReadKey();
                ShowMemberOptions();
            }
            else if (selection == "6")
            {
                ShowToolCatagories();
            }

            
        }



        private static void PreMemberMenu()
        {
            Console.WriteLine("To login as a member please provide:\n1. First Name\n2. Last Name\n3. 4-Digit PIN");
            string firstN = Console.ReadLine();
            string lastN = Console.ReadLine();
            string pin = Console.ReadLine();
            //Member tmpMember = new Member(firstN, lastN, "dummycontact" ,pin);
            //login with details
            Member[] members = memberCollection.toArray();
            for (int i = 0; i < memberCollection.Number; i++)
            {
                if (members[i].PIN == pin && members[i].FirstName == firstN && members[i].LastName == lastN)
                {
                    Console.Clear();
                    Console.WriteLine("you have logged in");
                    CurrentLoggedMBR = members[i];
                    memberLoggedIn = true;
                    ShowMemberOptions();
                }
            }
            if (memberLoggedIn == false)
            {
                Console.WriteLine("No member matching those details was found in our system");
            }


            Console.WriteLine("Plese push 1 to try again or 0 to exit to main menu");
            string tmp = Console.ReadLine();
            if ("1" == tmp)
            {
                PreMemberMenu();
            }
            else if ("0" == tmp)
            {
                MenuMain();
            }
            else
            {
                Console.WriteLine("Invalid option");
                Console.ReadKey();
                PreMemberMenu();
            }
        }

        private static void NotMemberMenu()
        {
            Console.WriteLine("To sign up please provid:\n1. First name\n2. Last name \n3. Contact phone number in order\n");
            string firstN = Console.ReadLine();
            string lastN = Console.ReadLine();
            string phNumber = Console.ReadLine();
            //string defaultPIN = "xxxx"; //search for this pin later to determine which members need to set up a pin - not needed, in constructor (has 2 constrcyutors). 
            //create new member with details
            Member newMember = new Member(firstN, lastN, phNumber);
            if (memberCollection.search(newMember))
            {
                Console.WriteLine(newMember.ToString() + "is already registered. Login using 4 digit PIN");
                Console.ReadKey();
                PreMemberMenu();
            }
            else//member doesnt exist in system. prompt for pin /////////////////// THIS IS WHERE I AM UP TO
            {

                Console.WriteLine("The member does not exist in the system. Creating member now");                
                //toolLibrarySystem.add(newMember);
                toolLibrarySystem.add(newMember);
                Console.WriteLine(newMember.MemberAddedMsg());
                Console.WriteLine("Please enter 4 digit password:");
                string tmp = Console.ReadLine();

                if (int.TryParse(tmp, out int pin))
                {
                    newMember.PIN = tmp;
                    Console.WriteLine("The member pin is set to " + pin);
                    Console.WriteLine("Please select: \n 1. Return to Main Menu \n 2. exit");
                    
                    string selection = Console.ReadLine();
                    if (selection == "1")
                    {
                        MenuMain();
                    }
                    else if (selection == "2")
                    {
                        Environment.Exit(0);
                    }
                    else
                    {
                        Console.WriteLine("please select existent option");
                    }
                }
                else
                {
                    Console.WriteLine("Please enter 4-digit integer for pin. " + tmp + " is not valid");
                }
            }
        }

        private static bool MenuMember()
        {
            //sign in 
            Console.WriteLine("Are you a pre-existing member of our service?\n1: I am a member\n2. I am not a member");
            string x = Console.ReadLine();
            if (x == "1")
            {
                PreMemberMenu();
            }
            else if (x == "2")
            {
                NotMemberMenu();
            }
            else
            {
                Console.WriteLine("Please enter valid option: ");
                Console.ReadKey();
                MenuMember();               
            }
            return false;
        }
    }
}


