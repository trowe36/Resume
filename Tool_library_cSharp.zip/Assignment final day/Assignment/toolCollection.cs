﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment
{
    class ToolCollection : iToolCollection// implement interace methods
    {
        const int indToolCapacity = 30;
        public static Tool[,] GardeningTools = new Tool[4, indToolCapacity];
        public static Tool[,] FlooringTools = new Tool[5, indToolCapacity];
        public static Tool[,] FencingTools = new Tool[4, indToolCapacity];
        public static Tool[,] MeasureTools = new Tool[5, indToolCapacity];
        public static Tool[,] CleaningTools = new Tool[5, indToolCapacity];
        public static Tool[,] PaintingTools = new Tool[5, indToolCapacity];
        public static Tool[,] ElectronicTools = new Tool[4, indToolCapacity];
        public static Tool[,] ElectricityTools = new Tool[4, indToolCapacity];
        public static Tool[,] AutomotiveTools = new Tool[5, indToolCapacity];
      
        public int lineTrimmerCount;
        public int lawnMowerCount;
        public int handToolGCount;
        public int wheelBarrowsCount;
        public int gardenPowerToolsCount;

        public int scrapersCount;
        public int floorLasersCount;
        public int floorLevToolCount;
        public int floorLevMaterialsCount;
        public int floorHandToolsCount;
        public int tilingToolsCount;

        public int fenceHandToolCount;
        public int electricFenceCount;
        public int steelFenceCount;
        public int powerToolsCount;
        public int fenceAccessCount;

        public int distanceToolsCount;
        public int laserMeasurerCount;
        public int measureJugsCount;
        public int tempHumidToolsCount;
        public int levelToolsCount;
        public int markersCount;

        public int drainingCount;
        public int carCleaningCount;
        public int vacuumCount;
        public int pressureCleanerCount;
        public int poolCleanCount;
        public int floorCleanCount;

        public int sandingToolCount;
        public int brushesCount;
        public int rollerCount;
        public int painRmvToolCount;
        public int paintScrapersCount;
        public int sprayersCount;

        public int voltageTesterCount;
        public int oscilloscopeCount;
        public int thermImgCount;
        public int dataTestTCount;
        public int insulationTesterCount;

        public int testEquipCount;
        public int safetyEquipCount;
        public int basicHandToolCount;
        public int circuitProtectCount;
        public int cableToolsCount;

        public int jacksCount;
        public int airCompressCount;
        public int batteryChargeCount;
        public int socketToolCount;
        public int brakingCount;
        public int driveTrainCount;
       
        public static List<Tool> tools = new List<Tool>();
        public int Number => throw new NotImplementedException();
        //STORE MEMBER BORROWING ARRAYS AS CONTACT AS MATCH KEY. UNIQUE EASY ETC. 
        public static List<Tool> Tools
        {
            get
            {
                return tools;
            }
            set
            {
                tools = value;
            }
        }
        public void add(Tool aTool) //q2
        {
            int type = int.Parse(aTool.toolType);
            // if (aTool.toolCategory == 1 )
            //{
            if (type <= 25) //line trimmers //just assign tools by type number not category.
            {
                if (type <= 10)
                {
                    //---------------------------------------------------------------------------------
                    if (type == 1)
                    {
                        GardeningTools[type - 1 , lineTrimmerCount] = aTool; 
                        lineTrimmerCount++;
                    }
                    else if (type == 2)
                    {
                        GardeningTools[type - 1, lawnMowerCount] = aTool;
                        lawnMowerCount++;
                    }
                    else if (type == 3)
                    {
                        GardeningTools[type - 1, handToolGCount] = aTool;
                        handToolGCount++;
                    }
                    else if (type == 4)
                    {
                        GardeningTools[type - 1, wheelBarrowsCount] = aTool;
                        wheelBarrowsCount++;
                    }
                    else if(type == 5)
                    {
                        GardeningTools[type - 1, gardenPowerToolsCount] = aTool;
                        gardenPowerToolsCount++;
                    }
                    else if (type == 6)
                    {
                        FlooringTools[type - 1, scrapersCount] = aTool;
                        scrapersCount++;
                    }
                    else if (type == 7)
                    {
                        FlooringTools[type - 1, floorLasersCount] = aTool;
                        floorLasersCount++;
                    }
                    else if (type == 8)
                    {

                        FlooringTools[type - 1, floorLevToolCount] = aTool;
                        floorLevToolCount++;
                    }
                    else if (type == 9)
                    {
                        FlooringTools[type - 1, floorLevMaterialsCount] = aTool;
                        floorLevMaterialsCount++;
                    }
                    else if (type == 10)
                    {
                        FlooringTools[type - 1, floorHandToolsCount] = aTool;
                        floorHandToolsCount++;
                    }
                }
                else// type is between 11 and 25
                {
                    //----------------------------------------------------------------------------
                    if (type == 11)
                    {
                        FlooringTools[type - 1, tilingToolsCount] = aTool;
                        tilingToolsCount++;
                    }
                    else if (type == 12)
                    {
                        FencingTools[type - 1, fenceHandToolCount] = aTool;
                        fenceHandToolCount++;
                    }
                    else if (type == 13)
                    {
                        FencingTools[type - 1, electricFenceCount] = aTool;
                        electricFenceCount++;
                    }
                    else if (type == 14)
                    {
                        FencingTools[type - 1, steelFenceCount] = aTool;
                        steelFenceCount++;
                    }
                    else if (type == 15)
                    {
                        FencingTools[type - 1, powerToolsCount] = aTool;
                        powerToolsCount++;
                    }
                    else if (type == 16)
                    {
                        FencingTools[type - 1, fenceAccessCount] = aTool;
                        fenceAccessCount++;
                    }
                    else if (type == 17)
                    {
                        MeasureTools[type - 1, distanceToolsCount] = aTool;
                        distanceToolsCount++;
                    }
                    else if (type == 18)
                    {
                        MeasureTools[type - 1, laserMeasurerCount] = aTool;
                        laserMeasurerCount++;
                    }
                    else if (type == 19)
                    {
                        MeasureTools[type - 1, measureJugsCount] = aTool;
                        measureJugsCount++;
                    }
                    else if (type == 20)
                    {
                        MeasureTools[type - 1, tempHumidToolsCount] = aTool;
                        tempHumidToolsCount++;
                    }
                    else if (type == 21)
                    {
                        MeasureTools[type - 1, levelToolsCount] = aTool;
                        levelToolsCount++;
                    }
                    else if (type == 22)
                    {
                        MeasureTools[type - 1, markersCount] = aTool;
                        markersCount++;
                    }
                    else if (type == 23)
                    {

                        CleaningTools[type - 1, drainingCount] = aTool;
                        drainingCount++;
                    }
                    else if (type == 24)
                    {
                        CleaningTools[type - 1, carCleaningCount] = aTool;
                        carCleaningCount++;

                    }
                    else if (type == 25)
                    {
                        CleaningTools[type - 1, vacuumCount] = aTool;
                        vacuumCount++;

                    }
                }
            }
            else//type is equal to 26 or greater
            {
                if (type >= 26 && type <= 38)
                {
                    if (type == 26)
                    {
                        CleaningTools[type - 1, pressureCleanerCount] = aTool;
                        pressureCleanerCount++;

                    }
                    else if (type == 27)
                    {
                        CleaningTools[type - 1, poolCleanCount] = aTool;
                        poolCleanCount++;

                    }
                    else if (type == 28)
                    {
                        CleaningTools[type - 1, floorCleanCount] = aTool;
                        floorCleanCount++;

                    }
                    else if (type == 29)
                    {
                        PaintingTools[type - 1, sandingToolCount] = aTool;
                        sandingToolCount++;
                    }
                    else if (type == 30)
                    {
                        PaintingTools[type - 1, brushesCount] = aTool;
                        brushesCount++;
                    }
                    else if (type == 31)
                    {
                        PaintingTools[type - 1, rollerCount] = aTool;
                        rollerCount++;
                    }
                    else if (type == 32)
                    {
                        PaintingTools[type - 1, painRmvToolCount] = aTool;
                        painRmvToolCount++;
                    }
                    else if (type == 33)
                    {
                        PaintingTools[type - 1, paintScrapersCount] = aTool;
                        paintScrapersCount++;
                    }
                    else if (type == 34)
                    {
                        PaintingTools[type - 1, sprayersCount] = aTool;
                        sprayersCount++;

                    }
                    else if (type == 35)
                    {
                        ElectronicTools[type - 1, voltageTesterCount] = aTool;
                        voltageTesterCount++;
                    }
                    else if (type == 36)
                    {
                        ElectronicTools[type - 1, oscilloscopeCount] = aTool;
                        oscilloscopeCount++;
                    }
                    else if (type == 37)
                    {
                        ElectronicTools[type - 1, thermImgCount] = aTool;
                        thermImgCount++;
                    }
                    else if (type == 38)
                    {
                        ElectronicTools[type - 1, dataTestTCount] = aTool;
                        dataTestTCount++;
                    }
                }
                else// type is greater than or equal to 39
                {
                    if (type == 39)
                    {
                        ElectricityTools[type - 1, insulationTesterCount] = aTool;
                        insulationTesterCount++;
                    }
                    else if (type == 40)
                    {
                        ElectricityTools[type - 1, testEquipCount] = aTool;
                        testEquipCount++;
                    }
                    else if (type == 41)
                    {
                        ElectricityTools[type - 1, safetyEquipCount] = aTool;
                        safetyEquipCount++;
                    }
                    else if (type == 42)
                    {
                        ElectricityTools[type - 1, basicHandToolCount] = aTool;
                        basicHandToolCount++;

                    }
                    else if (type == 43)
                    {
                        ElectricityTools[type - 1, circuitProtectCount] = aTool;
                        circuitProtectCount++;

                    }
                    else if (type == 44)
                    {
                        ElectricityTools[type - 1, cableToolsCount] = aTool;
                        cableToolsCount++;
                    }
                    else if (type == 45)
                    {
                        AutomotiveTools[type - 1, jacksCount] = aTool;
                        jacksCount++;
                    }
                    else if (type == 46)
                    {
                        AutomotiveTools[type - 1, airCompressCount] = aTool;
                        airCompressCount++;
                    }
                    else if (type == 47)
                    {
                        AutomotiveTools[type - 1, batteryChargeCount] = aTool;
                        batteryChargeCount++;
                    }
                    else if (type == 48)
                    {
                        AutomotiveTools[type - 1, socketToolCount] = aTool;
                        socketToolCount++;
                    }
                    else if (type == 49)
                    {
                        AutomotiveTools[type - 1, brakingCount] = aTool;
                        brakingCount++;
                    }
                    else if (type == 50)
                    {
                        AutomotiveTools[type - 1, driveTrainCount] = aTool;
                        driveTrainCount++;
                    }
                }
            }       
        }

        public void add(Tool aTool, int quantity)
        {
            for (int i = 0; i < quantity; i++)
            {
                Tools.Add(aTool);
            }          
        }

        public void delete(Tool aTool)
        {
            if (aTool.toolType == "1")
            {                
                for (int k = 0; k < 1; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < GardeningTools.GetLength(1); l++)
                    {
                        if (GardeningTools[k, l] != null)
                        {
                            if (GardeningTools[k, l].name == aTool.name)
                            {
                                GardeningTools[k, l] = null;                                                           
                                return; 
                            }
                        }
                    }
            }
            else if (aTool.toolType == "2")
            {
                for (int k = 1; k < 2; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < GardeningTools.GetLength(1); l++)
                    {
                        if (GardeningTools[k, l] != null)
                        {
                            if (GardeningTools[k, l].name == aTool.name)
                            {
                                GardeningTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "3")
            {
                for (int k = 2; k < 3; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < GardeningTools.GetLength(1); l++)
                    {
                        if (GardeningTools[k, l] != null)
                        {
                            if (GardeningTools[k, l].name == aTool.name)
                            {
                                GardeningTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "4")
            {
                for (int k = 3; k < 4; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < GardeningTools.GetLength(1); l++)
                    {
                        if (GardeningTools[k, l] != null)
                        {
                            if (GardeningTools[k, l].name == aTool.name)
                            {
                                GardeningTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "5")
            {
                for (int k = 4; k < 5; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < GardeningTools.GetLength(1); l++)
                    {
                        if (GardeningTools[k, l] != null)
                        {
                            if (GardeningTools[k, l].name == aTool.name)
                            {
                                GardeningTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "6")
            {
                for (int k = 0; k < 1; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < FlooringTools.GetLength(1); l++)
                    {
                        if (FlooringTools[k, l] != null)
                        {
                            if (FlooringTools[k, l].name == aTool.name)
                            {
                                FlooringTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "7")
            {
                for (int k = 1; k < 2; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < FlooringTools.GetLength(1); l++)
                    {
                        if (FlooringTools[k, l] != null)
                        {
                            if (FlooringTools[k, l].name == aTool.name)
                            {
                                FlooringTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "8")
            {
                for (int k = 2; k < 3; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < FlooringTools.GetLength(1); l++)
                    {
                        if (FlooringTools[k, l] != null)
                        {
                            if (FlooringTools[k, l].name == aTool.name)
                            {
                                FlooringTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "9")
            {
                for (int k = 3; k < 4; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < FlooringTools.GetLength(1); l++)
                    {
                        if (FlooringTools[k, l] != null)
                        {
                            if (FlooringTools[k, l].name == aTool.name)
                            {
                                FlooringTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "10")
            {
                for (int k = 4; k < 5; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < FlooringTools.GetLength(1); l++)
                    {
                        if (FlooringTools[k, l] != null)
                        {
                            if (FlooringTools[k, l].name == aTool.name)
                            {
                                FlooringTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "11")
            {
                for (int k = 5; k < 6; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < FlooringTools.GetLength(1); l++)
                    {
                        if (FlooringTools[k, l] != null)
                        {
                            if (FlooringTools[k, l].name == aTool.name)
                            {
                                FlooringTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "12")
            {
                for (int k = 0; k < 1; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < FencingTools.GetLength(1); l++)
                    {
                        if (FencingTools[k, l] != null)
                        {
                            if (FencingTools[k, l].name == aTool.name)
                            {
                                FencingTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "13")
            {
                for (int k = 1; k < 2; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < FencingTools.GetLength(1); l++)
                    {
                        if (FencingTools[k, l] != null)
                        {
                            if (FencingTools[k, l].name == aTool.name)
                            {
                                FencingTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "14")
            {
                for (int k = 2; k < 3; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < FencingTools.GetLength(1); l++)
                    {
                        if (FencingTools[k, l] != null)
                        {
                            if (FencingTools[k, l].name == aTool.name)
                            {
                                FencingTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "15")
            {
                for (int k = 3; k < 4; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < FencingTools.GetLength(1); l++)
                    {
                        if (FencingTools[k, l] != null)
                        {
                            if (FencingTools[k, l].name == aTool.name)
                            {
                                FencingTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "16")
            {
                for (int k = 4; k < 5; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < FencingTools.GetLength(1); l++)
                    {
                        if (FencingTools[k, l] != null)
                        {
                            if (FencingTools[k, l].name == aTool.name)
                            {
                                FencingTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "17")
            {
                for (int k = 0; k < 1; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < MeasureTools.GetLength(1); l++)
                    {
                        if (MeasureTools[k, l] != null)
                        {
                            if (MeasureTools[k, l].name == aTool.name)
                            {
                                MeasureTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "18")
            {
                for (int k = 1; k < 2; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < MeasureTools.GetLength(1); l++)
                    {
                        if (MeasureTools[k, l] != null)
                        {
                            if (MeasureTools[k, l].name == aTool.name)
                            {
                                MeasureTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "19")
            {
                for (int k = 2; k < 3; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < MeasureTools.GetLength(1); l++)
                    {
                        if (MeasureTools[k, l] != null)
                        {
                            if (MeasureTools[k, l].name == aTool.name)
                            {
                                MeasureTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "20")
            {
                for (int k = 3; k < 4; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < MeasureTools.GetLength(1); l++)
                    {
                        if (MeasureTools[k, l] != null)
                        {
                            if (MeasureTools[k, l].name == aTool.name)
                            {
                                MeasureTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "21")
            {
                for (int k = 4; k < 5; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < MeasureTools.GetLength(1); l++)
                    {
                        if (MeasureTools[k, l] != null)
                        {
                            if (MeasureTools[k, l].name == aTool.name)
                            {
                                MeasureTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "22")
            {
                for (int k = 5; k < 6; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < MeasureTools.GetLength(1); l++)
                    {
                        if (MeasureTools[k, l] != null)
                        {
                            if (MeasureTools[k, l].name == aTool.name)
                            {
                                MeasureTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "23")
            {
                for (int k = 0; k < 1; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < CleaningTools.GetLength(1); l++)
                    {
                        if (CleaningTools[k, l] != null)
                        {
                            if (CleaningTools[k, l].name == aTool.name)
                            {
                                CleaningTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "24")
            {
                for (int k = 1; k < 2; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < CleaningTools.GetLength(1); l++)
                    {
                        if (CleaningTools[k, l] != null)
                        {
                            if (CleaningTools[k, l].name == aTool.name)
                            {
                                CleaningTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "25")
            {
                for (int k = 2; k < 3; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < CleaningTools.GetLength(1); l++)
                    {
                        if (CleaningTools[k, l] != null)
                        {
                            if (CleaningTools[k, l].name == aTool.name)
                            {
                                CleaningTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "26")
            {
                for (int k = 3; k < 4; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < CleaningTools.GetLength(1); l++)
                    {
                        if (CleaningTools[k, l] != null)
                        {
                            if (CleaningTools[k, l].name == aTool.name)
                            {
                                CleaningTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "27")
            {
                for (int k = 4; k < 5; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < CleaningTools.GetLength(1); l++)
                    {
                        if (CleaningTools[k, l] != null)
                        {
                            if (CleaningTools[k, l].name == aTool.name)
                            {
                                CleaningTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "28")
            {
                for (int k = 5; k < 6; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < CleaningTools.GetLength(1); l++)
                    {
                        if (CleaningTools[k, l] != null)
                        {
                            if (CleaningTools[k, l].name == aTool.name)
                            {
                                CleaningTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "29")
            {
                for (int k = 0; k < 1; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < PaintingTools.GetLength(1); l++)
                    {
                        if (PaintingTools[k, l] != null)
                        {
                            if (PaintingTools[k, l].name == aTool.name)
                            {
                                PaintingTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "30")
            {
                for (int k = 1; k < 2; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < PaintingTools.GetLength(1); l++)
                    {
                        if (PaintingTools[k, l] != null)
                        {
                            if (PaintingTools[k, l].name == aTool.name)
                            {
                                PaintingTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "31")
            {
                for (int k = 2; k < 3; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < PaintingTools.GetLength(1); l++)
                    {
                        if (PaintingTools[k, l] != null)
                        {
                            if (PaintingTools[k, l].name == aTool.name)
                            {
                                PaintingTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "32")
            {
                for (int k = 3; k < 4; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < PaintingTools.GetLength(1); l++)
                    {
                        if (PaintingTools[k, l] != null)
                        {
                            if (PaintingTools[k, l].name == aTool.name)
                            {
                                PaintingTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "33")
            {
                for (int k = 4; k < 5; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < PaintingTools.GetLength(1); l++)
                    {
                        if (PaintingTools[k, l] != null)
                        {
                            if (PaintingTools[k, l].name == aTool.name)
                            {
                                PaintingTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "34")
            {
                for (int k = 5; k < 6; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < PaintingTools.GetLength(1); l++)
                    {
                        if (PaintingTools[k, l] != null)
                        {
                            if (PaintingTools[k, l].name == aTool.name)
                            {
                                PaintingTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "35")
            {
                for (int k = 0; k < 1; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < ElectronicTools.GetLength(1); l++)
                    {
                        if (ElectronicTools[k, l] != null)
                        {
                            if (ElectronicTools[k, l].name == aTool.name)
                            {
                                ElectronicTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "36")
            {
                for (int k = 1; k < 2; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < ElectronicTools.GetLength(1); l++)
                    {
                        if (ElectronicTools[k, l] != null)
                        {
                            if (ElectronicTools[k, l].name == aTool.name)
                            {
                                ElectronicTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "37")
            {
                for (int k = 2; k < 3; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < ElectronicTools.GetLength(1); l++)
                    {
                        if (ElectronicTools[k, l] != null)
                        {
                            if (ElectronicTools[k, l].name == aTool.name)
                            {
                                ElectronicTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "38")
            {
                for (int k = 3; k < 4; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < ElectronicTools.GetLength(1); l++)
                    {
                        if (ElectronicTools[k, l] != null)
                        {
                            if (ElectronicTools[k, l].name == aTool.name)
                            {
                                ElectronicTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "39")
            {
                for (int k = 4; k < 5; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < ElectronicTools.GetLength(1); l++)
                    {
                        if (ElectronicTools[k, l] != null)
                        {
                            if (ElectronicTools[k, l].name == aTool.name)
                            {
                                ElectronicTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "40")
            {
                for (int k = 0; k < 1; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < ElectricityTools.GetLength(1); l++)
                    {
                        if (ElectricityTools[k, l] != null)
                        {
                            if (ElectricityTools[k, l].name == aTool.name)
                            {
                                ElectricityTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "41")
            {
                for (int k = 1; k < 2; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < ElectricityTools.GetLength(1); l++)
                    {
                        if (ElectricityTools[k, l] != null)
                        {
                            if (ElectricityTools[k, l].name == aTool.name)
                            {
                                ElectricityTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "42")
            {
                for (int k = 2; k < 3; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < ElectricityTools.GetLength(1); l++)
                    {
                        if (ElectricityTools[k, l] != null)
                        {
                            if (ElectricityTools[k, l].name == aTool.name)
                            {
                                ElectricityTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "43")
            {
                for (int k = 3; k < 4; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < ElectricityTools.GetLength(1); l++)
                    {
                        if (ElectricityTools[k, l] != null)
                        {
                            if (ElectricityTools[k, l].name == aTool.name)
                            {
                                ElectricityTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "44")
            {
                for (int k = 4; k < 5; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < ElectricityTools.GetLength(1); l++)
                    {
                        if (ElectricityTools[k, l] != null)
                        {
                            if (ElectricityTools[k, l].name == aTool.name)
                            {
                                ElectricityTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "45")
            {
                for (int k = 0; k < 1; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < AutomotiveTools.GetLength(1); l++)
                    {
                        if (AutomotiveTools[k, l] != null)
                        {
                            if (AutomotiveTools[k, l].name == aTool.name)
                            {
                                AutomotiveTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "46")
            {
                for (int k = 1; k < 2; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < AutomotiveTools.GetLength(1); l++)
                    {
                        if (AutomotiveTools[k, l] != null)
                        {
                            if (AutomotiveTools[k, l].name == aTool.name)
                            {
                                AutomotiveTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "47")
            {
                for (int k = 2; k < 3; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < AutomotiveTools.GetLength(1); l++)
                    {
                        if (AutomotiveTools[k, l] != null)
                        {
                            if (AutomotiveTools[k, l].name == aTool.name)
                            {
                                AutomotiveTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "48")
            {
                for (int k = 3; k < 4; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < AutomotiveTools.GetLength(1); l++)
                    {
                        if (AutomotiveTools[k, l] != null)
                        {
                            if (AutomotiveTools[k, l].name == aTool.name)
                            {
                                AutomotiveTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "49")
            {
                for (int k = 4; k < 5; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < AutomotiveTools.GetLength(1); l++)
                    {
                        if (AutomotiveTools[k, l] != null)
                        {
                            if (AutomotiveTools[k, l].name == aTool.name)
                            {
                                AutomotiveTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
            else if (aTool.toolType == "50")
            {
                for (int k = 5; k < 6; k++) //only want to iterate through one type not all types in category
                    for (int l = 0; l < AutomotiveTools.GetLength(1); l++)
                    {
                        if (AutomotiveTools[k, l] != null)
                        {
                            if (AutomotiveTools[k, l].name == aTool.name)
                            {
                                AutomotiveTools[k, l] = null;
                                return;
                            }
                        }
                    }
            }
        }
        public void delete(Tool aTool, int quantity)
        {
            for (int i = 0; i < quantity; i++)
            {
                for (int k = 0; k < Tools.Count; k++)
                {
                    if (Tools[i].name.ToString() == aTool.name)
                    {
                        Tools.RemoveAt(i);
                        goto goto1; //match is found only want to remove first occurance 3 times.
                    }                   
                }
                goto1: ;
               //might just remove all tool objects not just that specific named tool
            }           
        }

        public bool search(Tool aTool) 
        {
            int typeAsInt = int.Parse(aTool.toolType);

            if (typeAsInt >= 1 && typeAsInt <= 5)
            {
                for (int k = 0; k < GardeningTools.GetLength(0); k++)
                    for (int l = 0; l < GardeningTools.GetLength(1); l++)
                    {
                        if (GardeningTools[k,l] != null) // do avoid null reference exception. eg if array pos is not null (then its an object) check the name of tool
                        {
                            if (GardeningTools[k, l].name == aTool.name)
                            {
                                return true;
                            }
                        }                      
                    }
            }
            else if (typeAsInt >= 6 && typeAsInt <= 11)
            {
                for (int k = 0; k < FlooringTools.GetLength(0); k++)
                    for (int l = 0; l < FlooringTools.GetLength(1); l++)
                    {
                        if (FlooringTools[k, l] != null) // do avoid null reference exception. eg if array pos is not null (then its an object) check the name of tool
                        {
                            if (FlooringTools[k, l].name == aTool.name)
                            {
                                return true;
                            }
                        }
                    }
            }
            else if (typeAsInt >= 12 && typeAsInt <= 16)
            {
                //int index = Array.IndexOf(GardeningTools, aTool.name);
                for (int k = 0; k < FencingTools.GetLength(0); k++)
                    for (int l = 0; l < FencingTools.GetLength(1); l++)
                    {
                        if (FencingTools[k, l] != null) // do avoid null reference exception. eg if array pos is not null (then its an object) check the name of tool
                        {
                            if (FencingTools[k, l].name == aTool.name)
                            {
                                return true;
                            }
                        }
                    }
            }
            else if (typeAsInt >= 17 && typeAsInt <= 22)
            {
                //int index = Array.IndexOf(GardeningTools, aTool.name);
                for (int k = 0; k < MeasureTools.GetLength(0); k++)
                    for (int l = 0; l < MeasureTools.GetLength(1); l++)
                    {
                        if (MeasureTools[k, l] != null) // do avoid null reference exception. eg if array pos is not null (then its an object) check the name of tool
                        {
                            if (MeasureTools[k, l].name == aTool.name)
                            {
                                return true;
                            }
                        }
                    }
            }
            else if (typeAsInt >= 23 && typeAsInt <= 28)
            {
                //int index = Array.IndexOf(GardeningTools, aTool.name);
                for (int k = 0; k < CleaningTools.GetLength(0); k++)
                    for (int l = 0; l < CleaningTools.GetLength(1); l++)
                    {
                        if (CleaningTools[k, l] != null) // do avoid null reference exception. eg if array pos is not null (then its an object) check the name of tool
                        {
                            if (CleaningTools[k, l].name == aTool.name)
                            {
                                return true;
                            }
                        }
                    }
            }
            else if (typeAsInt >= 29 && typeAsInt <= 34)
            {
                //int index = Array.IndexOf(GardeningTools, aTool.name);
                for (int k = 0; k < PaintingTools.GetLength(0); k++)
                    for (int l = 0; l < PaintingTools.GetLength(1); l++)
                    {
                        if (PaintingTools[k, l] != null) // do avoid null reference exception. eg if array pos is not null (then its an object) check the name of tool
                        {
                            if (PaintingTools[k, l].name == aTool.name)
                            {
                                return true;
                            }
                        }
                    }
            }
            else if (typeAsInt >= 35 && typeAsInt <= 39)
            {
                //int index = Array.IndexOf(GardeningTools, aTool.name);
                for (int k = 0; k < ElectronicTools.GetLength(0); k++)
                    for (int l = 0; l < ElectronicTools.GetLength(1); l++)
                    {
                        if (ElectronicTools[k, l] != null) // do avoid null reference exception. eg if array pos is not null (then its an object) check the name of tool
                        {
                            if (ElectronicTools[k, l].name == aTool.name)
                            {
                                return true;
                            }
                        }
                    }
            }
            else if (typeAsInt >= 40 && typeAsInt <= 44)
            {
                //int index = Array.IndexOf(GardeningTools, aTool.name);
                for (int k = 0; k < ElectricityTools.GetLength(0); k++)
                    for (int l = 0; l < ElectricityTools.GetLength(1); l++)
                    {
                        if (ElectricityTools[k, l] != null) // do avoid null reference exception. eg if array pos is not null (then its an object) check the name of tool
                        {
                            if (ElectricityTools[k, l].name == aTool.name)
                            {
                                return true;
                            }
                        }
                    }
            }
            else if (typeAsInt >= 45 && typeAsInt <= 50)
            {
                //int index = Array.IndexOf(GardeningTools, aTool.name);
                for (int k = 0; k < AutomotiveTools.GetLength(0); k++)
                    for (int l = 0; l < AutomotiveTools.GetLength(1); l++)
                    {
                        if (AutomotiveTools[k, l] != null) // do avoid null reference exception. eg if array pos is not null (then its an object) check the name of tool
                        {
                            if (AutomotiveTools[k, l].name == aTool.name)
                            {
                                return true;
                            }
                        }
                    }
            }
            return false;
        }

        internal int GetQuantity(string name)
        {
            int count = 0;
            for (int i = 0; i < Tools.Count; i++)
            {
                if (Tools[i].name == name)
                {
                    count++;
                }
            }
            return count;
        }


        public Tool[] toArray()
        {
            Tool[] returnArray = Tools.ToArray();
            return returnArray;
        }

        static void HeapBottomUp(Tool[] data)
        {
            int n = data.Length;
            for (int i = (n - 1) / 2; i >= 0; i--)
            {
                int k = i;
                Tool v = data[i];
                bool heap = false;
                while ((!heap) && ((2 * k + 1) <= (n - 1)))
                {
                    int j = 2 * k + 1;  //the left child of k
                    if (j < (n - 1))   //k has two children
                        if (data[j].NoBorrowings < data[j + 1].NoBorrowings)
                            j = j + 1;  //j is the larger child of k
                    if (v.NoBorrowings >= data[j].NoBorrowings)
                        heap = true;
                    else
                    {
                        data[k] = data[j];
                        k = j;
                    }
                }
                data[k] = v;
            }
        }

        // sort the elements in an array 
        public void HeapSort(Tool[] data)
        {
            //Use the HeapBottomUp procedure to convert the array, data, into a heap
            HeapBottomUp(data);


            //repeatly remove the maximum key from the heap and then rebuild the heap
            for (int i = 0; i <= data.Length - 2; i++)
            {
                MaxKeyDelete(data, data.Length - i);
            }
            Console.WriteLine(data[0].Name);
            Console.WriteLine(data[1].Name);
            Console.WriteLine(data[2].Name);
        }

        //delete the maximum key and rebuild the heap
        static void MaxKeyDelete(Tool[] data, int size)
        {
            //1. Exchange the root’s key with the last key K of the heap;
            Tool temp = data[0];
            data[0] = data[size - 1];
            data[size - 1] = temp;

            //2. Decrease the heap’s size by 1;
            int n = size - 1;

            //3. “Heapify” the complete binary tree.
            bool heap = false;
            int k = 0;
            Tool v = data[0];
            while ((!heap) && ((2 * k + 1) <= (n - 1)))
            {
                int j = 2 * k + 1; //the left child of k
                if (j < (n - 1))   //k has two children
                    if (data[j].NoBorrowings < data[j + 1].NoBorrowings)
                        j = j + 1;  //j is the larger child of k
                if (v.NoBorrowings >= data[j].NoBorrowings)
                    heap = true;
                else
                {
                    data[k] = data[j];
                    k = j;
                }
            }
            data[k] = v;
        }

    }
}
