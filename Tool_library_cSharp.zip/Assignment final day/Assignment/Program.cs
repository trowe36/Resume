﻿using System;

namespace Assignment
{
    class Program : MainClass
    {
        static void Main(string[] args)
        {
            //bool exitProgram = false;
            MainClass.InitialiseCounters();
            MainClass.MenuMain();
            // should you be able to delete a member if they have tools borrowing?
            //fix: borrowcount incrememnts all members when one member borrows. all tools borrowed with same name are returned if only want to return one...
            //fix: when tool is returned. doesnt properly decrement toolsborrowed counter. also when deleting tool name from string tools[] only assigns emtpy string
            // so program beleves they are still renting. fix this 
            // 
        }
    }
}
