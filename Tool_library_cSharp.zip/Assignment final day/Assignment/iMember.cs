﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment
{
    //The specification of Member ADT
    interface iMember
    {
        
        string FirstName  //get and set the first name of this member
        {
            get;
            set;
        }
        string LastName //get and set the last name of this member
        {
            get; // look at get and set variables. this gives away instance variables you should have in the class. 
            set;
        }

        string ContactNumber //get and set the contact number of this member
        {
            get;
            set;
        }

        string PIN //get and set the password of this member
        {
            get;
            set;
        }

        string[] Tools //get a list of tools that this memebr is currently holding // member can have tool collection. eg the tools theyre holding. this could be member collection o
            //use tool collection as private variable in member class because members have a tool collection. the three they can use. 
            //tool collection in member class. with string array. iterate through binary search tree and add values into string array etc. 36min wk7
        {
            get;// this ok cos when u use method like add tool. all you do is update string array.  
        }

        public void addTool(iTool aTool); //add a given tool to the list of tools that this member is currently holding

        void deleteTool(iTool aTool); //delete a given tool from the list of tools that this member is currently holding

        string ToString(); //return a string containing the first name, lastname, and contact phone number of this memeber (was string override but chagned it)
    }
}
