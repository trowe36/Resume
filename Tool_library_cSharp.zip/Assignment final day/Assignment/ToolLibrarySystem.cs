﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment
{
    class ToolLibrarySystem : iToolLibrarySystem
    {
        Member member = new Member();
        MemberCollection memberCollection;
        ToolCollection toolCollection = new ToolCollection();

        public ToolLibrarySystem(MemberCollection memberCollection)
        {
            this.memberCollection = memberCollection;
        }
        
        public void add(Tool aTool)  //call toolcollection. add to 9[,] category arrays or store the arrays in this class both may work.
        {
            add(aTool, 1);
        }

        public void add(Tool aTool, int quantity) // call to toolcollection.add but create override method with quantity params // called from staff
        {
            //aTool.AvailableQuantity = 1;
            //maybe add loop for first add
            for (int i = 0; i < quantity; i++)
            {
                toolCollection.add(aTool); // add to [,] category arrays (sorts by type)
            }         
            toolCollection.add(aTool, quantity); // add to simple list of tool objects (adds per quantity)
        }

        public void add(Member aMember) //call to member collection.add. using member object. 
        {
            memberCollection.add(aMember);           
        }

        public void borrowTool(Member aMember, Tool aTool)//                                                                                                             
        {
                Console.WriteLine("we have " + aTool.name + "in the system.");
               
                if (aMember.ToolsBorrowed >= 3)
                {
                    Console.WriteLine("you have reached your borrow limit");
                }
                else
                {
                    Console.WriteLine(aMember.firstName + " " + aMember.lastName + " has borrowed: " + aTool.name);
                    aMember.addTool(aTool);// add tool to member
                    aTool.addBorrower(aMember);
                    delete(aTool); // deletes one tool from database11                                                  //
            }           
        }



        public void delete(Tool aTool) //call to toolcollection. deletes from 9[,] arrays
        {           
            delete(aTool, 1); // default will delete one tool
        }

        public void delete(Tool aTool, int quantity) // for each quantity interation call delete function (if implemented properly will delete one each iteration
        {
            toolCollection.delete(aTool);// delete one from array
            toolCollection.delete(aTool, quantity); // delete per quantity from list 
        }

        public void delete(Member aMember) // call to delete function in membercollection.-> call to tool.deleteborrower -> delete off borrow list. return tools back to collection
        {
            memberCollection.delete(aMember);           
        }

        public void displayBorrowingTools(Member aMember)
        {
            int count = 1;// have numbers next to borrowed tools
            foreach (string item in aMember.Tools)
            {
                if (item != null) //when tools are returned the position in Tools is set to null
                {
                    Console.WriteLine(count.ToString() + ". " + item);
                    count++;
                }                  
            }                       
        }

        public void displayTools(string aToolType) 
        {           
            Tool[] array = toolCollection.toArray();
            //print tools. dont display tools twice
            for (int i = 0; i < array.GetLength(0); i++)
            {               
                if (array[i].toolType == aToolType) //every tool in the collection that has the type chosen. display that type.
                {
                    int secondOccurance = CheckIfSecondOccurance(array, array[i]);
                    //get quantity
                    int quantityOfTool = toolCollection.GetQuantity(array[i].name);
                    if (i < secondOccurance)//only print if first occurance
                    {
                        Console.WriteLine("Tool Name: " + array[i].name + "\t Total Quantity Available (not on loan): " + quantityOfTool);                      
                    }                   
                }
            }
        }

        private int CheckIfSecondOccurance(Tool[] array, Tool tool)
        {
            int count = 0;
            for (int i = 0; i < array.GetLength(0); i++)
            {
                if (array[i].Name == tool.Name)
                {
                    count++;
                }
                if (count == 2)
                {
                    return i; 
                }
            }
            return 100; //dummy return statement. check implementation
        }

        public void displayTopThree()
        {
            Tool[] array = toolCollection.toArray();
            toolCollection.HeapSort(array);
            Console.ReadKey();
        }

        public string[] listTools(Member aMember)
        {
            string[] listOfTools = new string[3];
            for (int i = 0; i < aMember.ToolsBorrowed; i++)
            {
                listOfTools[i] = aMember.tools[i];          //copy a member tools to return array
            }
            return listOfTools;
        }

        public void returnTool(Member aMember, Tool aTool) // add the tool back to tool[] and tool[,]. delete tool from members borrowcollection [2]
        {
            if (aMember.MemberHasTool(aMember,aTool))
            {
                aMember.deleteTool(aTool);
                add(aTool);
                aTool.deleteBorrower(aMember);
            }
            else
            {
                Console.WriteLine("Tool could not be returned as the member isn't currently borrowing it");
            }                      
        }
    }
}
