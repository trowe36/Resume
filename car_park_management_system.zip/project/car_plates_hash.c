// Inroduction to hash tables in C

#include <inttypes.h> // for portable integer declarations
#include <stdbool.h>  // for bool type
#include <stdio.h>    // for printf()
#include <stdlib.h>   // for malloc(), free(), NULL
#include <string.h>   // for strcmp()

// An item2 inserted into a hash table.
// As hash collisions can occur, multiple item2s can exist in one bucket.
// Therefore, each bucket is a linked list of items that hashes to that bucket.
typedef struct item2 item2_t;
struct item2
{
    char *key[6]; //plate is key 
    item2_t *next;
};



void item2_print2(item2_t *i)
{
    printf("plate=%s", i->key);
}

// A hash table mapping a string to an integer.
typedef struct htab_plates htab_t_plates;
struct htab_plates
{
    item2_t **buckets;
    size_t size;
};

// Initialise a new hash table with n buckets.
// pre: true
// post: (return == false AND allocation of table failed)
//       OR (all buckets are null pointers)
bool htab_init2(htab_t_plates *h, size_t n)
{
    h->size = n;
    h->buckets = (item2_t **)calloc(n, sizeof(item2_t *));
    return h->buckets != 0;
}

// The Bernstein hash function.
// A very fast hash function that works well in practice.
size_t djb_hash2(char *s)
{
    size_t hash = 5381;
    int c;
    while ((c = *s++) != '\0')
    {
        // hash = hash * 33 + c
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

// Calculate the offset for the bucket for key in hash table.
size_t htab_index2(htab_t_plates *h, char *key)
{
    return djb_hash2(key) % h->size;
}

// Find pointer to head of list for key in hash table.
item2_t *htab_bucket2(htab_t_plates *h, char *key)
{
    return h->buckets[htab_index2(h, key)];
}

// Find an item2 for key in hash table.
// pre: true
// post: (return == NULL AND item2 not found)
//       OR (strcmp(return->key, key) == 0)
item2_t *htab_find2(htab_t_plates *h, char *key)
{
    for (item2_t *i = htab_bucket2(h, key); i != NULL; i = i->next)
    {
        if (strcmp(i->key, key) == 0)
        { // found the key
            return i;
        }
    }
    return NULL;
}

// Add a key with value to the hash table.
// pre: htab_find2(h, key) == NULL
// post: (return == false AND allocation of new item2 failed)
//       OR (htab_find2(h, key) != NULL)
bool htab_add2(htab_t_plates *h, char *key, int value)
{
    // allocate new item2
    item2_t *newhead = (item2_t *)malloc(sizeof(item2_t));
    if (newhead == NULL)
    {
        return false;
    }
    strcpy(newhead->key, key);
   //newhead->value = value;

    // hash key and place item2 in appropriate bucket
    size_t bucket = htab_index2(h, key);
    newhead->next = h->buckets[bucket];
    h->buckets[bucket] = newhead;
    return true;
}

char* htab_random2(htab_t_plates *h){
    //get total buckets. get random number
    size_t table_size = h->size;
    //printf("test table size %zu\n", table_size);
    int random_num;
    bool isNull = true;
    while(isNull){
        random_num = rand() % table_size;
        //printf("random num test %d \n", random_num);
        if(h->buckets[random_num] != NULL){
            isNull = false;
            //printf("not null bucket is %d\n", random_num);
        }
    }
    //count itmes (linked list) in randomly chosen buckets
    int bucket_items = 0;
    for (item2_t *j = h->buckets[random_num]; j != NULL; j = j->next)
    {
        bucket_items++;
    }
    //get random item in random bucket
    int bucket_item_random = rand() % bucket_items;
    int curr_bucket = 0;
    for (item2_t *j = h->buckets[random_num]; j != NULL; j = j->next)
    {
        if(curr_bucket == bucket_item_random){
        //    printf("printing chosen random item: \n");
        //     printf("random plate: %s\n", j->key);
            return j->key;
        }else{
            curr_bucket++;
        }   
    }
    // if bucket not empty check how many next buckets there are. iff next == null return that
    // bucket license. else count the next buckets and get random again
    return "UuSuck";
}

// Print the hash table.
// pre: true
// post: hash table is printed to screen
void htab_print2(htab_t_plates *h)
{
    printf("hash table with %d buckets\n", h->size);
    for (size_t i = 0; i < h->size; ++i)
    {
        printf("bucket %d: ", i);
        if (h->buckets[i] == NULL)
        {
            printf("empty\n");
        }
        else
        {
            for (item2_t *j = h->buckets[i]; j != NULL; j = j->next)
            {
                item2_print2(j);
                if (j->next != NULL)
                {
                    printf(" -> ");
                }
            }
            printf("\n");
        }
    }
}

// Delete an item2 with key from the hash table.
// pre: htab_find2(h, key) != NULL
// post: htab_find2(h, key) == NULL
void htab_delete2(htab_t_plates *h, char *key)
{
    item2_t *head = htab_bucket2(h, key);
    item2_t *current = head;
    item2_t *previous = NULL;
    while (current != NULL)
    {
        if (strcmp(current->key, key) == 0)
        {
            if (previous == NULL)
            { // first item2 in list
                h->buckets[htab_index2(h, key)] = current->next;
            }
            else
            {
                previous->next = current->next;
            }
            free(current);
            break;
        }
        previous = current;
        current = current->next;
    }
}

// Destroy an initialised hash table.
// pre: htab_init2(h)
// post: all memory for hash table is released
void htab_destroy2(htab_t_plates *h)
{
    // free linked lists
    for (size_t i = 0; i < h->size; ++i)
    {
        item2_t *bucket = h->buckets[i];
        while (bucket != NULL)
        {
            item2_t *next = bucket->next;
            free(bucket);
            bucket = next;
        }
    }

    // free buckets array
    free(h->buckets);
    h->buckets = NULL;
    h->size = 0;
}

// int main(int argc, char **argv)
// {
//     // create a hash table with 10 buckets
//     printf("creating hash table:\n");
//     size_t buckets = 10;
//     htab_t h;
//     if (!htab_init2(&h, buckets))
//     {
//         printf("failed to initialise hash table\n");
//         return EXIT_FAILURE;
//     }

//     // add item2s to hash table and preint
//     htab_add(&h, "hello", 1);
//     htab_add(&h, "hello", 1); // violate pre-condition to get two hello's in table
//     htab_add(&h, "world", 2);
//     htab_print2(&h);
//     printf("\n");

//     // find item2 in hash table
//     printf("find item2 in hash table:\n");
//     item2_print2(htab_find2(&h, "hello"));
//     printf("\n\n");

//     // delete item2s from hash table and print
//     printf("deleting item2s from hash table:\n");
//     htab_delete22(&h, "hello");
//     htab_delete22(&h, "world");
//     htab_print2(&h);
//     printf("\n");

//     // clean up hash table
//     htab_destroy2(&h);
// }
