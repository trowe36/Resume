#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <pthread.h>
#include "car_park_hash_table.c"
#include "operations.h"
#include "car_plates_hash.c"

#define NUMBER_PLATE_CONST "123XYZ"

// Boom Gate Constants
#define BOOM_GATE_UP_TIME_MS 10
#define BOOM_GATE_OPEN_TIME_MS 20
#define BOOM_GATE_DOWN_TIME_MS 10
// Pricing Constants
#define PRICE_PER_MS 5
#define BILLING_FILE_NAME "billing.txt"
#define APPEND_MODE "a"
#define WRITE_MODE "w"
#define BOOMGATE_OPEN_STATUS 1

#define SHARE_NAME "PARKING"

htab_t_plates plates_hash_table;
size_t h_buckets = 10;
htab_t h;

long long time_in_millis(void);

void init_parking_hash()
{

    if (!htab_init(&h, h_buckets))
    {
        printf("failed to initialise hash table\n");
        return EXIT_FAILURE;
    }
}

void open_boomgate(shared_memory_t* shm, int lvl){
        pthread_mutex_lock(&shm->data->entrance[lvl].boomgate.mut);
        strncpy(&shm->data->entrance[lvl].boomgate.status, "O", 1);
        pthread_cond_signal(&shm->data->entrance[lvl].boomgate.pct);
        pthread_mutex_unlock(&shm->data->entrance[lvl].boomgate.mut);
        printf("\nBOOMGATE OPEN");
}

void close_boomgate(shared_memory_t* shm, int lvl){
        pthread_mutex_lock(&shm->data->entrance[lvl].boomgate.mut);
        strncpy(&shm->data->entrance[lvl].boomgate.status, "C", 1);
        pthread_cond_signal(&shm->data->entrance[lvl].boomgate.pct);
        pthread_mutex_unlock(&shm->data->entrance[lvl].boomgate.mut);
        printf("\nBOOMGATE CLOSED");
}

void signal_display(shared_memory_t* shm, int lvl){
        pthread_mutex_lock(&shm->data->entrance[lvl].infosign.mut);
        strncpy(&shm->data->entrance[lvl].infosign.display, "0", 1);
        pthread_cond_signal(&shm->data->entrance[lvl].infosign.pct);
        pthread_mutex_unlock(&shm->data->entrance[lvl].infosign.mut);
}

void wait_for_lpr(shared_memory_t* shm, int lvl, char** lp_val){
       // printf("\nWAITING FOR LRP COND WAIT");
        pthread_mutex_lock(&shm->data->entrance[lvl].license_sensor.mut);  
        pthread_cond_wait(&shm->data->entrance[lvl].license_sensor.pct, &shm->data->entrance[lvl].license_sensor.mut);
        //printf("\nLicense plate reader: - %.6s -", shm->data->entrance[lvl].license_sensor.license_plate);
       // printf("\nUNMATCHING LICENSES\nLicense plate reader: - %.6s -", shm->data->entrance[lvl].license_sensor.license_plate);
        //printf("\nLicense plate reader size: - %d -", strlen(shm->data->entrance[lvl].license_sensor.license_plate));
        //test = shm->data->entrance[0].license_sensor.license_plate;
        //lp_val = malloc(sizeof(char) * 6);
        *lp_val = &shm->data->entrance[lvl].license_sensor.license_plate;
        pthread_mutex_unlock(&shm->data->entrance[lvl].license_sensor.mut);
        //return (&shm->data->entrance[lvl].license_sensor.license_plate);
        //printf("\nMOVING TO BOOMGATE");
}
void wait_exit_lpr(shared_memory_t* shm, int lvl, char** lp_val){
    pthread_mutex_lock(&shm->data->exits[lvl].license_sensor.mut);  
    pthread_cond_wait(&shm->data->exits[lvl].license_sensor.pct, &shm->data->exits[lvl].license_sensor.mut);
    //*lp_val = &shm->data->levels[lvl].license_sensor.license_plate;
    pthread_mutex_unlock(&shm->data->exits[lvl].license_sensor.mut);
}

void wait_level_lpr(shared_memory_t* shm, int lvl, char** lp_val){
    pthread_mutex_lock(&shm->data->levels[lvl].license_sensor.mut);  
    pthread_cond_wait(&shm->data->levels[lvl].license_sensor.pct, &shm->data->levels[lvl].license_sensor.mut);
    //*lp_val = &shm->data->levels[lvl].license_sensor.license_plate;
    pthread_mutex_unlock(&shm->data->levels[lvl].license_sensor.mut);
    return (&shm->data->entrance[lvl].license_sensor.license_plate);
    printf("\nMOVING TO BOOMGATE");
}


void* mng_exit_thread(shared_memory_t * shm, int lvl){
    printf("exit threads starting\n");
    char b[] = "testl";
    char* curr_lp = b;
    while(true){
        wait_exit_lpr(shm, lvl, &curr_lp);
        printf("\nexit lpr %s  read from exit lp sensor", curr_lp);
        htab_delete(&h, curr_lp);
    }
}

void *mng_level_thread(shared_memory_t* shm, int lvl ){
    printf("level thread starting but first taking a  nap\n");
    sleep(4);
    char b[] = "testl";
    char* curr_lp = b;
    while(true){
        wait_level_lpr(shm, lvl, &curr_lp);
        printf("\nparking car: %s  read from level lp sensor", curr_lp);
        //sleep(2);
        //ONCE VALUE IS RECEIVED IN LEVEL LPR PARK THAT CAR
        //park_car(shm, lpr, lvl)
    }
}

void park_car(shared_memory_t* shm, char* lpr, int lvl){
    long long tmp_car_entry_time = time_in_millis();
    htab_add(&h, lpr, lvl, tmp_car_entry_time); // table, key, lp_value;
}

void *mng_entry_thread(shared_memory_t *shm, int lvl)
{
    printf("mng entrance thread starting \n");
    // FOREVER LOOP, WAITING FOR LPR IN RELATED ENTRANCE. ONCE RECEIVE, ENTER CAR,
    while (true)
    {
        char ptr[6];
        sleep(1);
        //int lvl = 0;
        //GEt LP used in iteration 
        char b[] = "testl";
        char* curr_lp= b;
        wait_for_lpr(shm, lvl, &curr_lp);
        printf("\nlp val: %s", curr_lp); //use val to park car in hash_table
        sleep(1);
        char j[] = "X";
        char* curr_lvl= j;
        //TODO check in hash first - authenticate 
        
        sleep(1);
        // check plate is allowed
        bool exists = htab_find2(&plates_hash_table, curr_lp);
        char write_level[1];
        if (exists)
        {
            printf("allowed in park\n");
            // CALCULATE LEVEL TODO
            // itoa(lvl, write_level, 10);
            snprintf(write_level, 6, "%d", lvl);

            printf("test write level: %s\n", write_level);
            // strcpy(write_level, lvl);
            signal_display(shm, lvl);
            sleep(1);

            open_boomgate(shm, lvl);
            sleep(2);//car drives in

            close_boomgate(shm, lvl);
            //SHOULD RECALCULATE LEVEL BASED ON SIMULATORS DECISION HERE AND
            //USE IN WAIT LEVEL LPR
            sleep(1);

            //printf("parking car \n"); // after parking car, create automated function where child thread is slept, auto awoken and car exits . closing child thread bug keeping manager open.

            //------DONE ON NEW THREAD
            //SIMULATOR PUTS CAR IN LEVEL THREAD LPR 
            //wait_level_lpr(shm, lvl);


            // //wait for level lpr read -
            // char read_plate[6];
            // char* ptr_read_plate = read_plate;
            // pthread_mutex_lock(&shm->data->entrance1.license_sensor.mut);
            // pthread_cond_wait(&shm->data->entrance1.license_sensor.pct, &shm->data->entrance1.license_sensor.mut);
            // strncpy(read_plate, shm->data->entrance1.license_sensor.license_plate, 6);
            // pthread_cond_signal(&shm->data->entrance1.license_sensor.pct);
            // pthread_mutex_unlock(&shm->data->entrance1.license_sensor.mut);
            // printf("\ntest lvl lpr: car  %0.6s, arrived at eentrance11\n", read_plate);
            // //read level car has parked at into hash table
            // long long tmp_car_entry_time = time_in_millis();
            // htab_add(&h, &read_plate, 1, tmp_car_entry_time); // table, key, lp_value;
            // //
            // printf("printing hash table\n");
            // htab_print(&h);
        }
        else
        {
            printf("not allowed: \n");
            strcpy(write_level, "X");
            pthread_mutex_lock(&shm->data->entrance[lvl].infosign.mut);
            strncpy(shm->data->entrance[lvl].infosign.display, write_level, 1);

            pthread_cond_signal(&shm->data->entrance[lvl].infosign.pct);
            pthread_mutex_unlock(&shm->data->entrance[lvl].infosign.mut);
            // DO NOTHING - DONT OPEN GATE
        }
    }

    printf("mng entrance thread ending \n");
}

void manager_main(shared_memory_t *shm)
{
    printf("Size of parking shm = %d", sizeof(shared_data_t));
    printf("manager starting.\n");
    // load_plates_into_hash();
    // test_hash_table();
    shm->name = SHARE_NAME;
    printf("name assigned.\n");
    shm->fd = shm_open(shm->name, O_RDWR, 0666);
    if (shm->fd < 0)
    {
        perror("shm_open");
        shm->data = NULL;
        return false;
    }

    shm->data = mmap(0, sizeof(shared_data_t), PROT_WRITE | PROT_READ, MAP_SHARED, shm->fd, 0);
    if (shm->data == (char *)-1)
    {
        return false;
    }
    load_plates_into_hash();
    init_parking_hash();
    pthread_t entrance0;
    pthread_t level0;
       
    pthread_create(&level0, NULL, mng_level_thread, (shm, 0));
    pthread_create(&entrance0, NULL, mng_entry_thread(shm, 0), NULL); // start entry thread for entry 0;
    
    
    
    //
    //pthread_join(&entrance[0], NULL);
    printf("after thread creation\n");
    while(true);
   
   //fflush(stdout);
    
    // printf("%0.6s", shm->data->entrance1.license_sensor.license_plate);
    //  if (!(htab_find2(&plates_hash_table, ptr)))
    //  {

    //     printf("car allowed in carpark!");
    //     // TODO: find lvl that is not full

    //     // sign for simulator to read (lvl to enter at)
    //     char write_level[1] = "1";
    //     strncpy(shm->data->entrance1.infosign.display, write_level, 1);
    //     printf("\ninfo entrance displays: %s", shm->data->entrance1.infosign.display);
    //     // open boom gate/

    //     strncpy(shm->data->entrance1.boomgate.status, "R", 1);
    //     printf("\nboomgate state: %s", shm->data->entrance1.boomgate.status);
    //     //usleep(10*1000);
    //     strncpy(shm->data->entrance1.boomgate.status, "O", 1);
    //     printf("\nboomgate state: %s", shm->data->entrance1.boomgate.status);
    return 0;
}

// function to get time in millis (use to subtact and get total millis in carpark)
long long time_in_millis(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return ((long long)(tv.tv_sec) * 1000) + (tv.tv_usec / 1000);
}
void file_license(htab_t_plates h)
{
    // f open
    char *pathname = "plates.txt";

    FILE *file_reading = fopen(pathname, "r");

    // fgetsc functionq
    if (file_reading)
    {
        printf("file opened");
        char *line[7];
        while (fgets(line, 7, file_reading))
        {
            if (strlen(line) == 6)
            {
                htab_add2(&h, line, 1);
            };
        }
        htab_print2(&h);
    }
    else
    {
        perror(pathname);
    }
}

// function to read plates.txt into hash table
void load_plates_into_hash()
{
    printf("loading plates into hash");
    // htab_t_plates plates_hash_table;
    size_t plates_hash_buckets = 10;
    if (!htab_init2(&plates_hash_table, plates_hash_buckets))
    {
        printf("failed to initialise hash table\n");
        return EXIT_FAILURE;
    }
    file_license(plates_hash_table);

    char *test_plate_key = "111XXX";
    char *test_plate_key2 = "iiiXXX";
    bool exists = htab_find2(&plates_hash_table, test_plate_key);
    printf("test should be true: %d\n", exists);
    exists = htab_find2(&plates_hash_table, test_plate_key2);
    printf("test should be false: %d\n", exists);
    printf("plates loaded into hash\n");
}

// simulates adding in and deleting cars from parking. calculates $$ and stores in billing.txt
// DIFFERENT HASH TABLE TO THE ONE THAT HOLDS JUST PLATES!
void test_hash_table()
{
    char *test_lpr1 = "lpr_01";
    char *test_lpr2 = "lpr_02";
    char *test_lpr3 = "lpr_03";
    char *test_lpr4 = "lpr_04";
    char *test_lpr5 = "lpr_05";
    size_t buckets = 10;
    htab_t h;
    if (!htab_init(&h, buckets))
    {
        printf("failed to initialise hash table\n");
        return EXIT_FAILURE;
    }
    // entry timestamp
    long long tmp_car_entry_time = time_in_millis();
    //
    htab_add(&h, test_lpr1, 1, tmp_car_entry_time); // table, key, lp_value;
    // sleep(1); //car spends 2 seconds in park
    htab_delete(&h, test_lpr1);                     // automatically adds billing when "leaving parking"
    htab_add(&h, test_lpr2, 1, tmp_car_entry_time); // table, key, lp_value;
    // sleep(3); //car spends 2 seconds in park
    htab_delete(&h, test_lpr2); // automatically adds billing when "leaving parking"
    htab_add(&h, test_lpr3, 1, tmp_car_entry_time);

    printf("printing hash table\n");
    // htab_print(&h);
}

int main(int argc, char *argv[])
{
    shared_memory_t shm;
    // init_mutexes(&shm);
    manager_main(&shm);
    return 0;
}
