//here is main
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>

#include "operations.h"

#include "car_park_hash_table.c"
#include "simulator.c"
#include "manager.c"
#define MEM_SIZE 2919

int main(int argc, char *argv[]){
    pid_t childPid = -1;
    childPid = fork();
    if ( childPid < 0 ) { /* error occurred */
        fprintf( stderr, "Fork failed\n" );
        return 1;
    }
    else if ( childPid == 0 ) {
        // Sleep 1 second to give the controller time to create the shared memory 
        // object, then invoke worker_main.
        
            simulator_main();
             
    }
    else { /* parent process */
        // Invoke controller_main.
        sleep(1);
        waitpid(childPid, NULL, 0);
        manager_main();
    }
    return 0;
}