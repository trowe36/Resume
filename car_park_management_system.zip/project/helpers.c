#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include "helpers.h"

//function to get time in millis (use to subtact and get total millis in carpark)
long long time_in_millis(void){
    struct timeval tv; 
    gettimeofday(&tv,NULL);
    return((long long)(tv.tv_sec)*1000)+ (tv.tv_usec/1000);
}