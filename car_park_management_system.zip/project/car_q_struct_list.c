// Introduction to structs and linked lists in C

#include <stddef.h> // for NULL
#include <stdio.h>  // for printf()
#include <stdlib.h> // for EXIT_SUCCESS
#include <string.h> // for strcmp()
#include <stdbool.h>

#define NAME_LENGTH 256
#define PEOPLE 4

typedef struct car car_t;

struct car
{
    char license_plate[6];
    //for in_carpark list include entrance time and exit time. controlled by the manager. 
};

void car_print(car_t *p)
{
    printf("license plate=%s\n", 
    p->license_plate//, 
    //p->entrance, 
    //p->level
    );
}

typedef struct node node_t;

// a node in a linked list of people
struct node
{
    car_t *car;
    node_t *next;
};


// print all people in the list pointer to by head
// pre: true
// post: list of people printed to screen
void node_print(node_t *head)
{
    for (node_t *test = head; test != NULL; test = test->next)
    {
        car_print(test->car);
    }
}

// add a person to the list pointed to by head
// pre: head != NULL
// post (return == NULL AND failed to allocate memory for new linked list node)
//      OR (return == the new head of the list)
node_t *node_add(node_t *head, car_t *car)
{
    // printf("ADDING CAR INTO NODE LIST\n CURRENT LIST:\n");
    // node_print(head);
    // printf("\nADDING: \n");
    // printf("\nlicense in node_add: %s\n", car->license_plate);
    // car_print(car);
    // printf("\nADJUSTED LIST:\n");
    // create new node to add to list
    node_t *new = (node_t *)malloc(sizeof(node_t));
    if (new == NULL)
    {
        return NULL;
    }

    // insert new node
    new->car = car;
    if (!(new == NULL )) {new->next = head;}
    // printf("\n NEWLY MADE NODE: \n");
    // node_print(new);
    return new;
}

// find person by name in list pointed to by head
// pre: head != NULL
// post (return == NULL AND name not found)
//      OR (return == node with person named name)
node_t *node_find_name(node_t *head, char *license_num)
{
    for (; head != NULL; head = head->next)
    {
        if (strcmp(license_num, head->car->license_plate) == 0)
        {
            return head;
        }
    }
    return NULL;
}

// delete a person by name in list pointed to by head
// pre: head != NULL
// post: return == the new head of the list
node_t *node_delete(node_t *head, char *license_num)
{
    node_t *previous = NULL;
    node_t *current = head;
    while (current != NULL)
    {
        if (strcmp(license_num, current->car->license_plate) == 0)
        {
            node_t *newhead = head;
            if (previous == NULL) // first item in list
                newhead = current->next;
            else
                previous->next = current->next;
            free(current);
            return newhead;
        }
        previous = current;
        current = current->next;
    }

    // name not found
    return head;
}
car_t copy_car(node_t *head) {
    car_t *new = (car_t *)malloc(sizeof(car_t));
    strncpy(new->license_plate, head->car->license_plate, 6);
    //new->entrance = head->car->entrance;
    //new->level = head->car->level;
    return *new;
}

car_t node_pop(node_t *head)
{
    node_t *test = head;
    for (test = head; test->next != NULL; test = test->next);
    return copy_car(test);
}
bool node_isempty(node_t *head) {
    node_t *current = head;
    node_print(current);
    printf("\nISEMPTY RESULT: %d\n", (current == (node_t*)NULL));
    if (current == (node_t*)NULL /*| !(strlen(current->car) == 6)*/) {return true;}
    else {
        return false;
    }

}




// int main(int argc, char **argv)
// {
//     // create two people and print them
//     printf("two people:\n");
//     // aaron
//     person_t aaron = {"aaron", 52, 0};
//     aaron.height = 154;
//     person_print(&aaron);
//     // beth
//     person_t *beth = (person_t *)malloc(sizeof(person_t)); // allocate memory for beth on the free store
//     if (beth == NULL)
//     {
//         printf("memory allocation failure\n");
//         return EXIT_FAILURE;
//     }
//     beth->name = "beth";
//     beth->age = 67;
//     beth->height = 207;
//     person_print(beth);
//     printf("\n");

//     // create an array of 4 people and print them
//     person_t people[] = {aaron, *beth, {"charlie", 44, 188}, {"danika", 5, 72}};
//     free(beth);  // free memory allocated for beth, the pointer is now a dangling pointer
//     beth = NULL; // set pointer to NULL so it is no longer a dangling pointer
//     printf("an array of people:\n");
//     for (int i = 0; i < PEOPLE; ++i)
//     {
//         person_print(people + i);
//     }
//     printf("\n");

//     // create an array of pointers to people containg the same people as the array
//     printf("an array of pointers to people:\n");
//     person_t *ppeople[] = {&people[0], &people[1], &people[2], &people[3]};
//     for (int i = 0; i < PEOPLE; ++i)
//     {
//         person_print(ppeople[i]);
//     }
//     printf("\n");

//     // create a linked list containing the same people as the array
//     node_t *people_list = NULL;
//     for (int i = 0; i < PEOPLE; ++i)
//     {
//         node_t *newhead = node_add(people_list, &people[i]);
//         if (newhead == NULL)
//         {
//             printf("memory allocation failure\n");
//             return EXIT_FAILURE;
//         }
//         people_list = newhead;
//     }

//     // print the linked list of people
//     printf("a linked list of people:\n");
//     node_print(people_list);
//     printf("\n");

//     // find a person in the list
//     printf("searching for charlie:\n");
//     node_t *find = node_find_name(people_list, "charlie");
//     person_print(find->person);
//     printf("\n");

//     // remove the first person from the list
//     printf("removing danika:\n");
//     people_list = node_delete(people_list, "danika");
//     node_print(people_list);
//     printf("\n");

//     // remove the last person from the list
//     printf("removing aaron:\n");
//     people_list = node_delete(people_list, "aaron");
//     node_print(people_list);
//     printf("\n");

//     // remove the remaining people from the list
//     printf("removing beth and charlie:\n");
//     people_list = node_delete(people_list, "beth");
//     people_list = node_delete(people_list, "charlie");
//     node_print(people_list);
//     printf("\n");

//     return EXIT_SUCCESS;
// }
