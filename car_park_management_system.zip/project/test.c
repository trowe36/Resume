#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include "operations.h"
#include <string.h> // for strcmp()
void main() {
    shared_memory_t shm;
    create_shared_object(&shm);
    test(&shm);
    
}
char *rand_license(char *tmp)
{
    const char charset[] = "123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    printf("\n");
    for (size_t n = 0; n < 6; n++) {
            int key = rand() % (int) (sizeof charset - 1);
            tmp[n] = charset[key];
        }
    // printf("license string = %s\n", tmp);
    //tmp[7] = '\0';
    return tmp;
}

void open_boomgate(shared_memory_t* shm, int lvl){
        pthread_mutex_lock(&shm->data->entrance[lvl].boomgate.mut);
        strncpy(&shm->data->entrance[lvl].boomgate.status, "O", 1);
        pthread_cond_signal(&shm->data->entrance[lvl].boomgate.pct);
        pthread_mutex_unlock(&shm->data->entrance[lvl].boomgate.mut);
        printf("\nBOOMGATE OPEN");
}

void close_boomgate(shared_memory_t* shm, int lvl){
        pthread_mutex_lock(&shm->data->entrance[lvl].boomgate.mut);
        strncpy(&shm->data->entrance[lvl].boomgate.status, "C", 1);
        pthread_cond_signal(&shm->data->entrance[lvl].boomgate.pct);
        pthread_mutex_unlock(&shm->data->entrance[lvl].boomgate.mut);
        printf("\nBOOMGATE CLOSED");
}

void signal_display(shared_memory_t* shm, int lvl){
        pthread_mutex_lock(&shm->data->entrance[lvl].infosign.mut);
        strncpy(&shm->data->entrance[lvl].infosign.display, "2", 1);
        pthread_cond_signal(&shm->data->entrance[lvl].infosign.pct);
        pthread_mutex_unlock(&shm->data->entrance[lvl].infosign.mut);
}

void wait_for_lpr(shared_memory_t* shm, int lvl, char** lp_val){
        printf("\nWAITING FOR LRP COND WAIT");
        pthread_mutex_lock(&shm->data->entrance[lvl].license_sensor.mut);  
        //pthread_cond_wait(&shm->data->entrance[lvl].license_sensor.pct, &shm->data->entrance[lvl].license_sensor.mut);
        printf("\nLicense plate reader: - %.6s -", shm->data->entrance[lvl].license_sensor.license_plate);
        printf("\nUNMATCHING LICENSES\nLicense plate reader: - %.6s -", shm->data->entrance[lvl].license_sensor.license_plate);
        printf("\nLicense plate reader size: - %d -", strlen(shm->data->entrance[lvl].license_sensor.license_plate));
        //test = shm->data->entrance[0].license_sensor.license_plate;
        //lp_val = malloc(sizeof(char) * 6);
        *lp_val = &shm->data->entrance[lvl].license_sensor.license_plate;
        pthread_mutex_unlock(&shm->data->entrance[lvl].license_sensor.mut);
        //return (&shm->data->entrance[lvl].license_sensor.license_plate);
        //printf("\nMOVING TO BOOMGATE");
}

// void enter_and_park_car(int lvl, char* car_lp){
//     long long tmp_car_entry_time = time_in_millis();
//     htab_add(&h, &read_plate, 1, tmp_car_entry_time); // table, key, lp_value;
//     printf("printing hash table\n");
//     htab_print(&h);

//     // create thread and sleep it for random time
//     //wait thread and call - leave_park() eg hash delete
// }

void test(shared_memory_t *shm) {
    char *test = "";
    printf("\nLicense test %.6s", test);
    for (int i = 0; i < 5; i++) {
        printf("\nLicense plate reader %.6s", shm->data->entrance[i].license_sensor.license_plate);
    }
    //strcpy(&shm->data->entrance[1].license_sensor.license_plate = test, 6);
    //printf("\nLicense plate reader %.6s", &shm->data->entrance[0].license_sensor.license_plate);
    
    test = shm->data->entrance[0].license_sensor.license_plate;
    printf("\nLicense test %.6s", test);
    while(true) {
        sleep(1);
        int lvl = 0;
        //GEt LP used in iteration 
        char b[] = "testl";
        char* curr_lp= b;
        wait_for_lpr(shm, lvl, &curr_lp);
        printf("\nlp val: %s", curr_lp); //use val to park car in hash_table
        sleep(1);
        char j[] = "X";
        char* curr_lvl= j;
        //TODO check in hash first - authenticate 
        signal_display(shm, lvl);
        sleep(1);
        open_boomgate(shm, lvl);
        sleep(1);
        close_boomgate(shm, lvl);

        pthread_mutex_lock(&shm->data->levels[2].license_sensor.mut);  
        pthread_cond_wait(&shm->data->levels[2].license_sensor.pct, &shm->data->levels[2].license_sensor.mut);
        printf("\nLEVEL LICENSE PLATE READER: - %.6s -", shm->data->levels[2].license_sensor.license_plate);
        printf("\nLEVEL LPR TRIGGERED: - %.6s -", shm->data->levels[2].license_sensor.license_plate);
        printf("\nLicense plate reader size: - %d -", strlen(shm->data->levels[2].license_sensor.license_plate));
        sleep(2);
        //test = shm->data->entrance[0].license_sensor.license_plate;
        //lp_val = malloc(sizeof(char) * 6);
        pthread_mutex_unlock(&shm->data->levels[2].license_sensor.mut);




        printf("\nWAITING FOR LRP COND WAIT");
        pthread_mutex_lock(&shm->data->exits[lvl].license_sensor.mut);  
        pthread_cond_wait(&shm->data->exits[lvl].license_sensor.pct, &shm->data->exits[lvl].license_sensor.mut);
        printf("\nLicense plate reader: - %.6s -", shm->data->exits[lvl].license_sensor.license_plate);
        printf("\nUNMATCHING LICENSES\nLicense plate reader: - %.6s -", shm->data->exits[lvl].license_sensor.license_plate);
        printf("\nLicense plate reader size: - %d -", strlen(shm->data->exits[lvl].license_sensor.license_plate));
        //test = shm->data->entrance[0].license_sensor.license_plate;
        //lp_val = malloc(sizeof(char) * 6);
        pthread_mutex_unlock(&shm->data->exits[lvl].license_sensor.mut);

        pthread_mutex_lock(&shm->data->exits[lvl].boomgate.mut);
        strncpy(&shm->data->exits[lvl].boomgate.status, "O", 1);
        pthread_cond_signal(&shm->data->exits[lvl].boomgate.pct);
        pthread_mutex_unlock(&shm->data->exits[lvl].boomgate.mut);
        printf("\nBOOMGATE OPEN");
        //FIRST WAIT FOR LVL LPR THEN PARK CAR 

       // enter_and_park_car(int lvl, curr_lp);
       //next car as car is now parked. exit is handled

        /*if ((rand() % 2) == 1) {
            char tmp[6]; test = rand_license(&tmp); printf("\n%.6s", tmp);
            }*/
    }
    printf("ending forever loop wtf \n");
}
#define SHARE_NAME "PARKING"

void create_shared_object(shared_memory_t *shm)
{
    printf("Size of parking shm = %d", sizeof(shared_data_t));
    printf("manager starting.\n");
    // load_plates_into_hash();
    // test_hash_table();
    shm->name = SHARE_NAME;
    printf("name assigned.\n");
    shm->fd = shm_open(shm->name, O_RDWR, 0666);
    if (shm->fd < 0)
    {
        perror("shm_open");
        shm->data = NULL;
        return false;
    }

    shm->data = mmap(0, sizeof(shared_data_t), PROT_WRITE | PROT_READ, MAP_SHARED, shm->fd, 0);
    if (shm->data == (char *)-1)
    {
        return false;
    }
    
}