char *file_license_fail(char tmp[])
{
    // f open
    char *pathname = "plates.txt";

    FILE *file_reading = fopen(pathname, "r");
    // fgetsc functionq
    if (file_reading)
    {
        char line[7] = {0};
        unsigned int line_count = 0;
        int line_to_read = 0;
        int max_lines = 0;

        // while(!feof(file_reading))
        // {
        //     char ch = fgetc(file_reading);
        //     if(ch == "\n")
        //     {
        //         max_lines++;
        //     }
        // }
        // line_to_read = (rand() % (max_lines - 0 + 1)) + 0;
        // get random number 0 to file line length then put if statement
        while (fgets(line, 7, file_reading))
        {

            // tmp = line;
            // return tmp;
            if (line[strlen(line) - 1] == '\n')
            {
                line_count++;
            }
        }
        fclose(file_reading);
        // printf("read line: %s\n", tmp);
        int plate_to_read = rand() % line_count; // gets a random file line based on total lines in plates.txt file
        // printf("file line count test:  %d & chosen random line: %d\n", line_count, plate_to_read);

        ssize_t read;
        char **str;
        // while((read = getline(&str, 6, file_reading)) != -1){
        //     printf("%s", str);
        // }

        line_count = 0;
        char lineNew[7] = {0};
        FILE *file_reading_new = fopen(pathname, "r");
        if (file_reading_new)
        {
            while (fgets(lineNew, 7, file_reading_new))
            {
                // printf("test line count = %d   and chosen line = %d\n", line_count, plate_to_read);
                if (line_count == plate_to_read)
                {
                    // printf("test random file palte return: %s\n", lineNew);
                    tmp = "111XXX"; // hardcoded just for now cos tmp = lineNew sometimes bugs out
                    return tmp;
                }
                line_count++;
            }
        }
        else
        {
            perror("error in simulator file_plate fopen()");
        }

        // printf("the max lines are %d\n", line_count);
        // tmp = fgets(plate_to_read, 6, file_reading);
        fclose(file_reading);
        // printf("plate read from file:  %s\n", tmp);
        return tmp;
    }
    else
    {
        perror("fopen() in file_license func");
    }

    // return tmp;
}
