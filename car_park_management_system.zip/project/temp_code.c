void open_boomgate(shared_memory_t* shm, int lvl){
        pthread_mutex_lock(&shm->data->entrance[lvl].boomgate.mut);
        strncpy(&shm->data->entrance[lvl].boomgate.status, "O", 1);
        pthread_cond_signal(&shm->data->entrance[lvl].boomgate.pct);
        pthread_mutex_unlock(&shm->data->entrance[lvl].boomgate.mut);
        printf("\nBOOMGATE OPEN");
}
void close_boomgate(shared_memory_t* shm, int lvl){
        pthread_mutex_lock(&shm->data->entrance[lvl].boomgate.mut);
        strncpy(&shm->data->entrance[lvl].boomgate.status, "C", 1);
        pthread_cond_signal(&shm->data->entrance[lvl].boomgate.pct);
        pthread_mutex_unlock(&shm->data->entrance[lvl].boomgate.mut);
        printf("\nBOOMGATE CLOSED");
}
void signal_display(shared_memory_t* shm, int lvl){
        pthread_mutex_lock(&shm->data->entrance[lvl].infosign.mut);
        strncpy(&shm->data->entrance[lvl].infosign.display, "2", 1);
        pthread_cond_signal(&shm->data->entrance[lvl].infosign.pct);
        pthread_mutex_unlock(&shm->data->entrance[lvl].infosign.mut);
}
void wait_for_lpr(shared_memory_t* shm, int lvl){
        printf("\nWAITING FOR LRP COND WAIT");
        pthread_mutex_lock(&shm->data->entrance[lvl].license_sensor.mut);
        
        pthread_cond_wait(&shm->data->entrance[lvl].license_sensor.pct, &shm->data->entrance[lvl].license_sensor.mut);
        printf("\nLicense plate reader: - %.6s -", shm->data->entrance[lvl].license_sensor.license_plate);
        printf("\nUNMATCHING LICENSES\nLicense plate reader: - %.6s -", shm->data->entrance[lvl].license_sensor.license_plate);
        printf("\nLicense plate reader size: - %d -", strlen(shm->data->entrance[lvl].license_sensor.license_plate));
        //test = shm->data->entrance[0].license_sensor.license_plate;
        pthread_mutex_unlock(&shm->data->entrance[lvl].license_sensor.mut);
        printf("\nMOVING TO BOOMGATE");
}