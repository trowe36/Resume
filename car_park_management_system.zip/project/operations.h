#pragma once
#include <semaphore.h>
#include <stdio.h>   /* standard I/O routines                     */
#include <pthread.h> /* pthread functions and data structures     */
#include <stdlib.h>  /* rand() and srand() functions              */
#include <time.h>
#include <unistd.h>
//----------------------------------------------------------------------------------------------------------- COMPONENTS: 
typedef struct license_sensor { //96 bytes long
    pthread_mutex_t mut; //40 bytes 0-39
    pthread_cond_t pct; //48 bytes 40-87
    char license_plate[6];//5 chars long 6 bytes 88-93
    char padding[2];//2 bytes padding
} license_sensor_t;

typedef struct boom_gate { //96 bytes long
    pthread_mutex_t mut; //40 bytes 0-39
    pthread_cond_t pct; //48 bytes 40-87 
    char status[1]; //1 byte 88
    char padding[7]; //7 bytes padding
}boom_gate_t;

typedef struct info_sign {//96 bytes long
    pthread_mutex_t mut; //40 bytes 0-39
    pthread_cond_t pct; //48 bytes 40-87 
    char display[1]; //1 byte 88
    char padding[7]; //7 bytes padding
}info_sign_t;

//----------------------------------------------------------------------------------------------------------- STRUCTURES: 
typedef struct entrance { //each entrance 288 bytes large. 5 entrances 0-1439   288 = 96+96_96
    license_sensor_t license_sensor;  //each entry, 1 sensor, detects entering cars //96 bytes large
    boom_gate_t boomgate; //96
    info_sign_t infosign; //96
} entrance_t;

typedef struct exit { //each exit 192 bytes large. 5 exits 1440-2399  (96+96)
    license_sensor_t license_sensor;  //each exit, 1 sensor. detects exiting cars   //96
    boom_gate_t boomgate;  //96
} exit_t;

typedef struct level {//each level 104 bytes large. bytes 2400-2919
    license_sensor_t license_sensor;  //each lvl 1 sensor, detects lvl change 
    int16_t temp_sensor; //2 bytes sign 16 bit int for temp sensor 
    char alarm[1]; //alarm is one char. 1 byte
    char padding[5];
}level_t;

typedef struct shared_data {//should be 2919 bytes large. note entrances/exits are not part of levels, check memory structure ref.
    entrance_t entrance[5];
    exit_t exits[5];
    level_t levels[5];
} shared_data_t;

typedef struct shared_memory {
    /// The name of the shared memory object.
    const char *name;
    /// The file descriptor used to manage the shared memory object.
    int fd;
    shared_data_t* data;
} shared_memory_t;





