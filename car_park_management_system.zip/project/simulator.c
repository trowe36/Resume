#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include "car_q_struct_list.c"
#include "operations.h"
#include "car_plates_hash.c"
node_t* entrance_queue[5];
int* queue_length[5];
htab_t_plates plates_hash_table;
size_t BUCKETS = 10;
pthread_mutex_t entry_q_lock[5];

pthread_mutex_t lock_hash;
pthread_mutex_t lock_struct_list;
// pthread_mutex_t lock_file; - maybe dont lock file. just allow simulator 1 second to set up and read/close file before manager starts

#define SHARE_NAME "PARKING"

bool create_shared_object(shared_memory_t *shm)
{
    shm_unlink(SHARE_NAME);
    if (shm_unlink(SHARE_NAME) != 0)
    {
        perror("shm unlink failed");
    }
    // Assign share name to shm->name.
    shm->name = SHARE_NAME;
    shm->fd = shm_open(shm->name, O_CREAT | O_RDWR, 0666);
    if (shm->fd < 0)
    {
        perror("shm_open");
        shm->data = NULL;
        return false;
    }
    int ftruncResult = ftruncate(shm->fd, sizeof(shared_data_t));
    if (ftruncResult < 0)
    {
        perror("ftruncate");
        // strerror(errno);
        shm->data = NULL;
        return false;
    }
    shm->data = mmap(0, sizeof(shared_data_t), PROT_WRITE | PROT_READ, MAP_SHARED, shm->fd, 0);
    if ( shm->data == (char *)-1)
    {
        return false;
    }
    printf("shm->data\n");
    // If we reach this point we should return true.
    return true;
}

void init_mut(pthread_mutex_t* mut){
    pthread_mutexattr_t shared_mut_attr;
    pthread_mutexattr_init(&shared_mut_attr);//can add error check
    pthread_mutexattr_setpshared(&shared_mut_attr, PTHREAD_PROCESS_SHARED);
    pthread_mutex_init(mut, &shared_mut_attr);
}

void init_cond(pthread_cond_t* cond){
    pthread_condattr_t shared_cond_attr;
    pthread_condattr_init(&shared_cond_attr);
    pthread_condattr_setpshared(&shared_cond_attr, PTHREAD_PROCESS_SHARED);
    pthread_cond_init(cond, &shared_cond_attr);
}

int get_car_spawn_interval()
{
    int n;
    n = rand() % 100 + 1;
    return n;
}

// returns random license char[] int,int,int,char,char,char

char *rand_license(char *tmp)
{
    const char charset[] = "123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    //printf("\n");
    for (size_t n = 0; n < 6; n++) {
            int key = rand() % (int) (sizeof charset - 1);
            tmp[n] = charset[key];
        }
    // printf("license string = %s\n", tmp);
    tmp[7] = '\0';
    return tmp;
}

char *get_license()
{
    int random_num = rand() % 2; // random num 0 or 1;
    char* return_val = malloc(7);
    if (random_num == 1)
    {
        rand_license(return_val);
        //printf("test: %s\n", return_val);
        // printf("test: %s\n", return_val);
    }
    else
    {
        return_val = htab_random2(&plates_hash_table);
    }
    //printf("%s --------------------------------------------------------------", return_val);
    return return_val;
}

node_t *spawn_car()
{
    int entry = rand() % 5; //JACOB NOTE: hardcoded level change to rand() // 0-4 inclusive entrances.
    int lvl = 0;   // random 0-4 inclusive (5 exits) tom - I don't think the simualtor decides level, the manager should when it allows the car in

    char* generated_license = get_license();
    //printf("------------------%s-----------------%d\n", generated_license, strlen(generated_license));
    if (generated_license == NULL)
    {
        perror("spawn_car()");
    }
    car_t* tmp_car;
    tmp_car = malloc(sizeof(car_t));
    tmp_car = (car_t*){generated_license};//, entry, lvl};
    //tmp_car->entrance = entry;
    //tmp_car->level = lvl;
    pthread_mutex_lock(&entry_q_lock[entry]);
    node_t *newhead = node_add(entrance_queue[entry], (car_t*){generated_license});//all downhill from here
    if (newhead == NULL)
    {
        printf("memory allocation failure spawn_car()\n");
        // return EXIT_FAILURE;
    }
    entrance_queue[entry] = newhead;
    pthread_mutex_unlock(&entry_q_lock[entry]);
    //queue_length[entry]++;
    //printf("NEW HEAD \n newhead = ");
    //node_print(newhead);
    //printf("\n");
    
    //printf("CAR ENTRY LIST ENTRANCE NO %d \n ADDING %.6s\n car entry list: \n", entry, tmp_car->license_plate);
    //node_print(newhead); //JACOB uncomment 
    //printf("\n");
    //car_count_test_var++;
    //node_print(entrance_queue[entry]);
    
    return newhead; // kk
}

void lock_mutex(pthread_mutex_t *lock)
{
    if (pthread_mutex_lock(&lock))
    {
        perror("pthread_mutex_lock");
    }
}

void unlock_mutex(pthread_mutex_t *lock)
{
    if (pthread_mutex_unlock(&lock))
    {
        perror("pthread_mutex_unlock");
    }
}

void lpr_read(shared_memory_t* shm, node_t *node_car)
{
    /* printf("node should have lp:  %s\n ", node_car->car->license_plate);
    printf("node lp size:  %d\n ", strlen(node_car->car->license_plate));
    // node_print(node_car); //--weird bug here idk, random vs getting from file affects ability to add to node
    */
   sleep(1);
    char test[6] = "111XXX"; 
    int lvl = rand() % 5;
    lock_mutex(&shm->data->entrance[1].license_sensor.mut);
    //printf("succ: mutex lock");
    strncpy(shm->data->entrance[1].license_sensor.license_plate, test, 6); //- seg faults
    pthread_cond_signal(&shm->data->entrance[1].license_sensor.pct); //signal waiting manager 
    unlock_mutex(&shm->data->entrance[1].license_sensor.mut);
    
    printf("license copied in: %s\n", shm->data->entrance[1].license_sensor.license_plate);
    
}

void file_license(htab_t_plates h)
{
    // f open
    char *pathname = "plates.txt";

    FILE *file_reading = fopen(pathname, "r");

    // fgetsc functionq
    if (file_reading)
    {
        printf("file opened");
        char *line[7];
        while (fgets(line, 7, file_reading))
        {
            if (strlen(line) == 6)
            {
                htab_add2(&h, line, 1);
            };
        }
        // htab_print2(&h);
    }
    else
    {
        perror(pathname);
    }
}

void load_plates_into_hash()
{
    printf("loading plates into hash");
    if (!htab_init2(&plates_hash_table, BUCKETS))
    {
        printf("failed to initialise hash table\n");
        return EXIT_FAILURE;
    }
    file_license(plates_hash_table);
}

void init_mutexes(shared_memory_t *shm)
{
    // infosign inits

    for (int i = 0; i < 5; i++) {
        printf("mutexes for entrance %d initialised\n", i);
        pthread_mutex_init(&entry_q_lock[i], NULL);
        init_mut(&shm->data->entrance[i].infosign.mut);
        init_cond(&shm->data->entrance[i].infosign.pct);
        init_mut(&shm->data->entrance[i].license_sensor.mut);
        init_cond(&shm->data->entrance[i].license_sensor.pct);
        init_mut(&shm->data->entrance[i].boomgate.mut);
        init_cond(&shm->data->entrance[i].boomgate.pct);
    }
    for (int i = 0; i < 5; i++) {
        printf("mutexes for level %d initialised\n", i);
        init_mut(&shm->data->levels[i].license_sensor.mut);
        init_cond(&shm->data->levels[i].license_sensor.pct);
    }
    for (int i = 0; i < 5; i++) {
        printf("mutexes for exit %d initialised\n", i);
        init_mut(&shm->data->exits[i].boomgate.mut);
        init_cond(&shm->data->exits[i].boomgate.pct);
        init_mut(&shm->data->exits[i].license_sensor.mut);
        init_cond(&shm->data->exits[i].license_sensor.pct);
    }
    //pthread_mutex_unlock(&shm->data->entrance[0].boomgate.mut);

    printf("passed\n");
}

void init_entry_list()
{
    for (int i = 0; i < 5; i++) {
    node_add(entrance_queue[i],NULL);
    queue_length[i] = 0;
    }
}
struct thread_data
{
    shared_memory_t* shm;
    char i;
};
typedef struct thread_data thread_data_t;

void *entrance_thread(void* data) { 
    thread_data_t* dat = (thread_data_t*) data;
    printf("entrance thread started\n");
    int i = (int)dat->i;
    if (!(dat->i = 0)) {int i = 0; }
    printf("%d,", i);
    shared_memory_t* shm = (shared_memory_t*) dat->shm;
    entrance_t *ent = &dat->shm->data->entrance[i];
    printf("can assign shm");
    //printf("CAR AT ENTRANCE 1!\n%.6s", &entrance_queue[i]->car->license_plate);
    node_t *queue = entrance_queue[i];
    sleep(2);
    while (true)
    {
        //node_print(entrance_queue[i]);
        if (!node_isempty(entrance_queue[i]))//(!(queue_length[i]) == 0)
        {
            pthread_mutex_lock(&entry_q_lock[i]);
            //node_t *queue = entrance_queue[i];
            printf("ENTRANCE %d QUEUE\n", i);
            //node_print(entrance_queue[i]);
            //printf("\n");
            car_t rmv = (node_pop(entrance_queue[i]));
            printf("REMOVED CAR: %.6s", rmv.license_plate);
            node_t *newhead = node_delete(entrance_queue[i], rmv.license_plate);
            printf("NEW LIST\n");
            node_print(newhead);
            printf("REMOVED:\n");
            car_print(&rmv);
            entrance_queue[i] = newhead;
            //queue = entrance_queue[i];
            printf("REMOVED CAR: %.6s", rmv.license_plate);
            //node_print(queue);
            printf("\n REMOVED CAR SUCCESFULLY\n\n");
            pthread_mutex_unlock(&entry_q_lock[i]);
            car_print(&rmv);
            
            //pthread_mutex_unlock(&entry_q_lock[i]);
            printf("\nCAR AT ENTRANCE %d!\n%.6s\n", i, rmv.license_plate);
            pthread_mutex_lock(&ent->license_sensor.mut);
            printf("successfully locked mutex");
            strncpy(&ent->license_sensor.license_plate, rmv.license_plate, 6);
            printf("string copied into manager lpr reader %.6s\n", &ent->license_sensor.license_plate);
            pthread_cond_signal(&ent->license_sensor.pct);
            printf("pcod signalled\n");
            pthread_mutex_unlock(&ent->license_sensor.mut);


            printf("waiting for infosign manager broadcast\n");
            char sign_stat[2];

            pthread_mutex_lock(&ent->infosign.mut);
            pthread_cond_wait(&ent->infosign.pct, &ent->infosign.mut); // unloock mutex,  wait for infosign sig cond, then lock mutex
            printf("cond_t infosign broadcast received from infosign\n");
            strncpy(sign_stat, ent->infosign.display, 1);
            printf("level instruction: %s\n", ent->infosign.display);
            printf("level instruction: %s\n", ent->infosign.display);
            pthread_cond_signal(&ent->infosign.pct);
            pthread_mutex_unlock(&ent->infosign.mut);

            printf("after\n");
            if ((strcmp(ent->infosign.display, "X")) == 0) //IF REJECTED BY SIGN
            { 

                printf("drive away \n");
            }
            else
            {
                printf("boom gate opening\n");
                char boomgate_stat[1];
                strncpy(boomgate_stat, &ent->boomgate.status, 1);
                printf("\n%s\n", &ent->boomgate.status);
                while (!(strncmp(boomgate_stat, "O", 1)== 0)) {//wait for boomgate status to be open
                printf("waiting for boomgate");
                    pthread_mutex_lock(&ent->boomgate.mut);
                    pthread_cond_wait(&ent->boomgate.pct, &ent->boomgate.mut); // unloock mutex,  wait for infosign sig cond, then lock mutex
                    printf("cond_t broadcast boomgate received\n");
                    strncpy(boomgate_stat, ent->boomgate.status, 1);
                    pthread_mutex_unlock(&ent->boomgate.mut);
                    printf("boomgate instruction: %.6s\n", ent->boomgate.status);
                }
                pthread_mutex_lock(&ent->license_sensor.mut);
                printf("removing LP from LPR\n");
                strncpy(&ent->license_sensor.license_plate, "      ", 6);
                pthread_cond_signal(&ent->license_sensor.pct);
                pthread_mutex_unlock(&ent->license_sensor.mut);
                sleep(2);
                int i;
                printf("\nGIVING CHILD unformatted %s", sign_stat);
                sscanf(sign_stat, "%d", &i);
                printf("\n Telling child to go to lvl: %d", i);
                int e = 0;//(rand() % 5);
                car_process(&shm, rmv, i, e);

                sleep(5); // change to 20ms - driving to park
            }
            
           sleep(1);
            //usleep(50 * 1000);
            // printf("THREAD ON");
        }
        else{sleep(1);}
        
    }
    printf("entry thread ended\n");
}

void update_lpr(license_sensor_t *lpr, char *license){ //test later
    pthread_mutex_lock(&lpr->mut);
    strncpy( &lpr->license_plate, license, 6);
    printf("string copied into manager lpr reader \n");
    pthread_cond_signal(&lpr->pct);
    printf("pcd signalled\n");
    pthread_mutex_unlock(&lpr->mut);
}


void car_process(shared_memory_t *shm, car_t car, int signstat, int ex) {
    pid_t childpid;
    
    childpid = fork();
    if (childpid == 0) {
        usleep(5000);
        int lvl = (int)signstat;
        printf("\nENTERING PARK LVL %d!\n%.6s\n", lvl, car.license_plate);
        pthread_mutex_lock(&shm->data->levels[signstat].license_sensor.mut);
        strncpy(&shm->data->levels[signstat].license_sensor.license_plate , car.license_plate, 6);
        printf("entered level \n");
        pthread_cond_signal(&shm->data->levels[signstat].license_sensor.pct);
        printf("LEVEL pcd signalled\n");
        if (pthread_mutex_unlock(&shm->data->levels[signstat].license_sensor.mut) != 0) {printf("FUCKING ERROR NOT UNLOCKING");};
        printf("LEVEL MUTEX UNLOCKED\n");
        
        pthread_mutex_lock(&shm->data->exits[ex].license_sensor.mut);
        strncpy(&shm->data->exits[ex].license_sensor.license_plate , car.license_plate, 6);
        printf("string copied into EXIT lpr reader \n");
        pthread_cond_signal(&shm->data->exits[ex].license_sensor.pct);
        printf("EXIT pcod signalled\n");
        pthread_mutex_unlock(&shm->data->exits[ex].license_sensor.mut);
        printf("EXIT MUTEX UNLOCKED");

        printf("boom gate opening\n");
        char *boomgate_stat[1];
        strncpy(boomgate_stat, &shm->data->exits[ex].boomgate.status, 1);
        while (!(strcmp(boomgate_stat, "O")== 0)) {//wait for boomgate status to be open
            pthread_mutex_lock(&shm->data->exits[ex].boomgate.mut);
            pthread_cond_wait(&shm->data->exits[ex].boomgate.pct, &shm->data->exits[ex].boomgate.mut); // unloock mutex,  wait for infosign sig cond, then lock mutex
            printf("cond_t broadcast boomgate received\n");
            strncpy(boomgate_stat, shm->data->exits[ex].boomgate.status, 1);
            pthread_mutex_unlock(&shm->data->exits[ex].boomgate.mut);
            printf("boomgate instruction: %.6s\n", shm->data->exits[ex].boomgate.status);
        }
        pthread_mutex_lock(&shm->data->exits[ex].license_sensor.mut);
        printf("removing LP from LPR\n");
        strncpy(&shm->data->exits[ex].license_sensor.license_plate, "      ", 6);
        pthread_cond_signal(&shm->data->exits[ex].license_sensor.pct);
        pthread_mutex_unlock(&shm->data->exits[ex].license_sensor.mut);

        bool died = false;
        for (int loop = 0; !died && loop < 5 /*For example */; ++loop)
        {
            int status;
            pid_t id;
            sleep(1);
            if (waitpid(childpid, &status, WNOHANG) == childpid) died = true;
        }
        
        if (!died) kill(childpid, SIGKILL);
        }
        //----------------------------------------------- above section taken from the following source 
        //https://stackoverflow.com/questions/13273836/how-to-kill-child-of-fork 
    }

    


void *car_generator(){ 
    printf("car generator thread started\n");
    //START 4 ENTRY THREADS 
    //for (int i = 0; i < 5; i++) {
    while(true){
        //printf("\nSPAWNING A CAR\n");
        // int waitTime = get_car_spawn_interval();
        // usleep(waitTime * 1000);
        spawn_car();
        printf("SPAWNED ANOTHER CAR\n");
        int i = ((rand() % 100 + 1) * 1000);
        usleep(i); //slow sim down for debugging 
        
        ///usleep(150000);
    }
        // GET_CAR_SPAWN_INTERVAL()
        // WAIT THAT RANDOM TIME THEN ADD TO Q
    while (true){};

}

//generate temperature for carpark within safe ranges
void *temp_simulator_thread(shared_memory_t* shm, int i) { 
    printf("temp simulator thread created\n");
    while(true){
        int ran_time = rand() % 5 + 1; 
        usleep(ran_time * 1000);
        //printf("wait time: %d \n", ran_time);
        int update_val = (rand() % (57-50 + 1)) + 50;
        int random_lvl = rand() % 5;
        shm->data->levels[random_lvl].temp_sensor = update_val;
    }
}

//siimulate fire by >90% of temperature reads being >= 58 deggrees
void simulate_fire1(shared_memory_t* shm){
    shm->data->levels[0].temp_sensor = 58;
    while(true){}
}

//simulate fire by rate of rise. Values don't go over 58 but still triggers the alarm
void simulate_fire2(shared_memory_t* shm){ 
    while(true){
        shm->data->levels[0].temp_sensor = (rand() % (56-30 + 1)) + 30;
    }
}

void simulator_main()
{
    shared_memory_t shm;
    init_entry_list();
    create_shared_object(&shm);
    printf("\nshm");
    init_mutexes(&shm);
    printf("\nmut init");
    //simulate_fire2(&shm);
    pthread_t fire_sim_thread;
    //pthread_create(&fire_sim_thread, NULL, temp_simulator_thread, &shm);
    load_plates_into_hash();
    
    printf("\nhash tabe");
    sleep(5);//start manager
    pthread_t curr_thread;
    pthread_t spawner_thread;
    
    //pthread_t entrance_1; //can change to [4] then for loop 
    pthread_create(&spawner_thread, NULL, car_generator, NULL);
    sleep(1); //give some time to fill q with cars
    for (int i = 0; i < 5; i++)
    {
        thread_data_t data;
        data.i = (char)i;
        data.shm = &shm;
        //-------------------------------------------------------------------------------------------------CALL ON NEW THREAD EACH TIME---------------------------
        pthread_create(&curr_thread, NULL, entrance_thread, (void*)&data);
        //----------------------------------------------------------------------------------------------------------------------------
    }
    printf("sim_main finished\n");
    while (true){}
    
}

int main(int argc, char *argv[])
{
    simulator_main();
    return 0;
}