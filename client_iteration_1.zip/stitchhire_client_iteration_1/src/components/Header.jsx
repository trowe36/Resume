import React from "react";
import "../App.css";
import Nav from "./Nav";

// the header
export default function Header() {
  return (
    <header>
      <Nav />
      <div className="spacing-div"></div>
    </header>
  );
}
