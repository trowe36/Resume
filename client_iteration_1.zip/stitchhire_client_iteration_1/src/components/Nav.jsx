import React from "react";
import { Link } from "react-router-dom";
import "../App.css";

// navigation links
export default function Nav() {
  return (
    <nav>
      <ul>
        <li>
          <Link to="/Home">Home</Link>
        </li>
        <li>
          <Link to="/Register">Register</Link>
        </li>
        <li>
          <Link to="/Login">Login</Link>
        </li>
        <li>
          <Link to = "/client-info"> Client Info</Link>
        </li>
        <li>
          <Link to = "/Workform">Work Form</Link>
        </li>
        <li>
          <Link to = "/Update-emp-info"> Update Worker Infomration</Link>
        </li>
        <li>
          <Link to ="/admin">Admin</Link>
        </li>
      </ul>
    </nav>
  );
}
