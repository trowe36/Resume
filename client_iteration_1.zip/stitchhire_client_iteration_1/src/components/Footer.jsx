import React from "react";
import "../App.css";

// the footer
export default function Footer() {
  return (
    <footer>
      <span>
        Stitch-hire project
        <br />
        Copyright &copy; 2022{" "}
      </span>
    </footer>
  );
}
