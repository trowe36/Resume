import React, { useEffect, useState } from 'react';
import DateTimePicker from 'react-datetime-picker';


export default function BasicDateTimePicker({stateChanger, year, month, day, ...rest}) {
  var timestamp = Date.parse(`${year}-${month}-${day}`)
  const [value, onChange] = useState(new Date(timestamp));

  useEffect (() => {
    stateChanger(value)  
  },[value])

  return (
    <div>
      <DateTimePicker
        onChange= {onChange}
        value={value}
      />
    </div>
  );
}