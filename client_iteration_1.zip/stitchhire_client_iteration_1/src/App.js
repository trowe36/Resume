import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// import our files:
import "./App.css";
import Login from "./pages/Login";
import Home from "./pages/Home";
import Register from "./pages/Register";
import Footer from "./components/Footer";
import Header from "./components/Header";
import Default from "./pages/Default"
import Workform from "./pages/Workform"
import EmpInfo from "./pages/EmpInfo";
import ClientInfo from "./pages/ClientInfo";
import Admin from "./pages/Admin";

export default function App() {
  return (
    <BrowserRouter>
      <div className="App">    
      <Header />
        <Routes>   
        <Route path="/" element={<Default />} />     
          <Route path="/home" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path = "/workform" element={<Workform />} />
          <Route path = "/client-info" element = {<ClientInfo />}/>
          <Route path = "/update-emp-info" element = {<EmpInfo />} /> 
          <Route path = "/admin" element = {<Admin />} />
        </Routes>
       
      </div>
    </BrowserRouter>
  );
}
