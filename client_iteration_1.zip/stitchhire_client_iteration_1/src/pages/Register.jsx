import React from "react";
import {useState} from "react"
import { Link } from "react-router-dom";
import CustomInput from "../components/CustomInput";
import Button from "../components/Button";
import "../App.css"
import FormLabel from "@material-ui/core/FormLabel";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { Radio } from "@material-ui/core";
import {FormControl} from "@material-ui/core";
import { setOriginalNode } from "typescript";
import { Navigate, useNavigate } from "react-router-dom";
import logo from "../images/logo.png"



export default function Register() {
  const [name, setName] = useState("");
  const [error, setError] = useState(null);
  const [password, setPassword] = useState("");
  const [registerError, setRegisterError] = useState("")
  const USER_EXISTS = "User already exists"
  const BAD_REQUEST = "Request body incomplete, both email and password are required"
  const USER_CREATED = "User created"
  const[iAmA, setIAmA] = useState('');
      //regex: http://jsfiddle.net/ghvj4gy9/
  const validateEmail = (email) => {
    return String(email)
      .toLowerCase()
      .match(
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      );
  };
  const navigate = useNavigate();
  function RegisterUser(){
    const url = 'http://localhost:3001/user/register'
    if(iAmA === ''){
      setRegisterError('Please specify worker/client')
    }else{
      if(validateEmail(name)){
        return fetch(url, {
          method: "POST",
          headers: {accept: "application/json", "Content-Type": "application/json"},
          body: JSON.stringify({email: name, password: password, type: iAmA})
        })
        .then(res => res.json ())
        .then(res => {
          if(res.message === USER_EXISTS){
            setRegisterError("User already exists")
            console.log("user exists")
          }
          if(res.message === BAD_REQUEST){
            setRegisterError("Both email and password are required")
            console.log("user exists")
          }        
          if(res.message === USER_CREATED){
            //localStorage.removeItem("token")
            // localStorage.setItem("token", res.token)
            // //localStorage.removeItem("email")
            //  localStorage.setItem("email", name)
                   
            navigate('/login')       
          }
        })
      }
      else{
        setRegisterError("email not valid")
        return console.log("email is not valid")
        
      }
    }
    
  }

  function goLogin(){
    navigate('/login')
  }

  const handleChange = e => {
    console.log(JSON.stringify(e.target.id))
    if(e.target.id == "name"){
      setName(e.currentTarget.value)
    }
    else if(e.target.id == "password"){
      setPassword(e.currentTarget.value)
    }
    // else if(e.target.id == "controlled-radio-buttons-group")
    // //setState({ [e.currentTarget.id]: e.currentTarget.value });
    // setIAmA(e.currentTarget.value)
  };

  const handleRadioChange = e => {
    setIAmA(e.currentTarget.value)
  }

  return (
    <div className="registerForm">
      <img src = {logo} alt ="stitchhire-logo" className="logo" />
      <form className="form">
        <CustomInput
          labelText="Email"
          value = {name}
          id="name"
          formControlProps={{
            fullWidth: true
          }}
          // onChange={(event) => {
          //            const newName = event.target.value;
          //            setName(newName);
          //            console.log(name);
          //          }}
          handleChange={handleChange}
          type="text"
        />
        <CustomInput
          labelText="Password"
          id="password"
          formControlProps={{
            fullWidth: true
          }}
        //   onChange={(event) => {
        //     const newPassword = event.target.value;
        //     setPassword(newPassword);
        //     console.log(password);
        //  }}
        handleChange={handleChange}
          type="password"
        />
        <Button type="button" color="primary" className="form__custom-button" onClick ={RegisterUser}>
          Register
        </Button>
<FormControl id = "hello"> 
        <FormLabel id="demo-controlled-radio-buttons-group">I am a: </FormLabel>
        <RadioGroup
          aria-labelledby="controlled-radio-buttons-group"
          id = "h"
          name="controlled-radio-buttons-group"
          value={iAmA}
          onChange={handleRadioChange}
        >
          <FormControlLabel value="worker" control={<Radio />} label="Worker" />
          <FormControlLabel value="client" control={<Radio />} label="Client" />
        </RadioGroup>
        </FormControl>
        
      </form>    
      <span className="errorSpan">{registerError}</span>
      <Button type="button" onClick={goLogin}>Login Instead</Button>  
    </div>
  );

  }