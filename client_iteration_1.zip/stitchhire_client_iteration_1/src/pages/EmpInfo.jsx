import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import ScheduleSelector from 'react-schedule-selector'
import { useState } from "react";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";
import RadioGroup from "@material-ui/core/RadioGroup";
import Radio from "@material-ui/core/Radio";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import Slider from "@material-ui/core/Slider";
import Button from "@material-ui/core/Button";
import BasicDateTimePicker from "../components/BasicDateTimePicker";
import InputLabel from '@mui/material/InputLabel';
import FormGroup from '@mui/material/FormGroup';
import { Navigate, useNavigate } from "react-router-dom";
import { makeStyles} from "@material-ui/styles"
import FormHelperText from '@mui/material/FormHelperText';
import Checkbox from '@mui/material/Checkbox';
import { updateLocale } from "moment";
import logo from "../images/logo.png"
import {ThemeProvider, createTheme } from '@mui/system';


const defaultValues = {
  firstName: "",
  lastName: "",
  postCode: "",
  phoneNumber: "",
  suburb: "",
  DOB: "",
  maxHours: 1,
};
const defaultAvailabilityVals = {
  weekendShift: false,
  dayShift: false,
  nightShift: false
}

function AvailabilitySkills(){
  const[mainSubButColor, setMainSubButColor] = useState("error")
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(localStorage.getItem("token"))
    sendToDB()
    //updateProfile()
    setMainSubButColor("success")
  };

  const[availValues, setAvailValues] = useState({
    nightShift: false,
    dayShift: false,
    weekendShift: false,
  });
  
  const [statedSkills, setStatedSkills] = useState({
    cockAttendant: 2,
    barista: 0,
    management: 0,
    frontHouse: 5,
    backHouse: 5,   
    chef: 0,
    bartender: 0,
    //add bartender as woker type 
  });
  let moveEffect = 0;
  
  useEffect(
    () => {
    fetchSkillsInfo().then((info) => {
      setStatedSkills(info);
      setAvailValues(info);
    })
  }, [moveEffect])

  const handleAvailabilityChange = (event) => {
    setAvailValues({
      ...availValues,
      [event.target.name]: event.target.checked,
    });
  };

  const handleSkillsChange = (event) => {
    setStatedSkills({
      ...statedSkills,
      [event.target.name]: event.target.value,
    });
  };
  const {barista, management, frontHouse, backHouse, chef, cockAttendant, bartender} = statedSkills;
  function fetchSkillsInfo() {
    let currUser = localStorage.getItem("email");
    let token = localStorage.getItem("token")

     return fetch(`http://localhost:3001/user/${currUser}/profile-skills`, {
      method: "GET",
      headers: { 
        accept: "application/json", 
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`}
    }).then((res) => res.json())
  }
  async function sendToDB(){
    console.log(statedSkills)
    console.log(availValues)
    let currUser = localStorage.getItem("email");
    let token = localStorage.getItem("token")
      //send skills to DB
      await fetch(`http://localhost:3001/user/${currUser}/profile-skills`, {
        method: "PUT",
        headers: { 
          accept: "application/json", 
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`},
        body: JSON.stringify({ 
      cockAttendant: statedSkills.cockAttendant, barista: statedSkills.barista, management:statedSkills.management, 
    frontHouse: statedSkills.frontHouse, backHouse: statedSkills.backHouse, chef: statedSkills.chef, bartender: statedSkills.bartender, 
  dayShift: availValues.dayShift, nightShift : availValues.nightShift, weekendShift: availValues.weekendShift })
      }).then((res) => console.log("res msg for skills = " + res.message));
  }
  const theme = createTheme({
      text: {
        primary: '#173A5E',
        secondary: '#46505A',
      }
  });
  return (
    <div className="employeeInfoCard">
      <Grid container alignItems="center" justify="center" direction="column">
        <Grid item>
          <FormControl>
            <FormLabel sx={{color: 'black', fontSize: 25}}><b>I would like to be notified for the following shifts:</b></FormLabel>
            <FormGroup className="empInfoFormGroup">
              <FormControlLabel
                control={
                  <Checkbox checked={availValues.dayShift} onChange={handleAvailabilityChange} name="dayShift" />
                }
                label="Day Shifts"
              />
              <FormControlLabel
                control={
                  <Checkbox checked={availValues.nightShift} onChange={handleAvailabilityChange} name="nightShift" />
                }
                label="Night Shifts"
              />
              <FormControlLabel
                control={
                  <Checkbox checked={availValues.weekendShift} onChange={handleAvailabilityChange} name="weekendShift" />
                }
                label="Weekend Shifts"
              />
            </FormGroup>
          </FormControl>
          <div className="rankingsDescriptionBox">
          <ul className="rankingDescriptionList">
            <h3>For each skill, please rank as follows: </h3>
            <li><b>0 -</b> I have no experience in this hospitality field</li>
            <li><b>1 -</b> I have worked over one shift in this position</li>
            <li><b>2 -</b> I have some experience</li>
            <li><b>3 -</b> I have some experience and I am confident being rostered for this position</li>
            <li><b>4 -</b> I have more than one year experience in this position</li>
            <li><b>5 -</b> I can confidentally handle all tasks associated with this position with minimal supervision</li>
          </ul>
          </div>
          
        </Grid>
      </Grid>
      <Grid container justifyContent="center" alignItems="center" spacing={5} className="skillSelector">
        <Grid item>
          <InputLabel sx={{color: 'black'}} id="emp-skills-select">Front of House</InputLabel>
          <Select
            labelId="frontHouse"
            id="frontHouse"
            defaultValue={5}
            value={frontHouse}
            name="frontHouse"
            onChange={handleSkillsChange}
            
          >
            <MenuItem value={0}>0</MenuItem>
            <MenuItem value={1}>1</MenuItem>
            <MenuItem value={2}>2</MenuItem>
            <MenuItem value={3}>3</MenuItem>
            <MenuItem value={4}>4</MenuItem>
            <MenuItem value={5}>5</MenuItem>
          </Select>
        </Grid>
        <Grid item>
          <InputLabel sx={{color: 'black'}} id="emp-skills-select">Back of House</InputLabel>
          <Select
            labelId="backHouse"
            id="backHouse"
            defaultValue={5}
            value={backHouse}
            name="backHouse"
            onChange={handleSkillsChange}
          >
            <MenuItem value={0}>0</MenuItem>
            <MenuItem value={1}>1</MenuItem>
            <MenuItem value={2}>2</MenuItem>
            <MenuItem value={3}>3</MenuItem>
            <MenuItem value={4}>4</MenuItem>
            <MenuItem value={5}>5</MenuItem>
          </Select>
        </Grid>
        <Grid item>
          <InputLabel sx={{color: 'black'}} id="emp-skills-select">Chef</InputLabel>
          <Select
            labelId="chef"
            id="chef"
            defaultValue={5}
            value={chef}
            name="chef"
            onChange={handleSkillsChange}
          >
            <MenuItem value={0}>0</MenuItem>
            <MenuItem value={1}>1</MenuItem>
            <MenuItem value={2}>2</MenuItem>
            <MenuItem value={3}>3</MenuItem>
            <MenuItem value={4}>4</MenuItem>
            <MenuItem value={5}>5</MenuItem>
          </Select>
        </Grid>
        <Grid item>
          <InputLabel sx={{color: 'black'}} id="emp-skills-select">Barista</InputLabel>
          <Select
            id="barista"
            defaultValue={5}
            value={barista}
            name="barista"
            onChange={handleSkillsChange}
          >
            <MenuItem value={0}>0</MenuItem>
            <MenuItem value={1}>1</MenuItem>
            <MenuItem value={2}>2</MenuItem>
            <MenuItem value={3}>3</MenuItem>
            <MenuItem value={4}>4</MenuItem>
            <MenuItem value={5}>5</MenuItem>
          </Select>
        </Grid>
        <Grid item>
          <InputLabel sx={{color: 'black'}} id="emp-skills-select">Cocktail Attendant</InputLabel>
          <Select
            id="cockAttendant"
            defaultValue={5}
            value={cockAttendant}
            name="cockAttendant"
            onChange={handleSkillsChange}
          >
            <MenuItem value={0}>0</MenuItem>
            <MenuItem value={1}>1</MenuItem>
            <MenuItem value={2}>2</MenuItem>
            <MenuItem value={3}>3</MenuItem>
            <MenuItem value={4}>4</MenuItem>
            <MenuItem value={5}>5</MenuItem>
          </Select>
        </Grid>
        <Grid item>
          <InputLabel sx={{color: 'black'}} id="emp-skills-select">Bartender</InputLabel>
          <Select
            labelId="bartender"
            id="bartender"
            defaultValue={5}
            value={bartender}
            name="bartender"
            onChange={handleSkillsChange}
          >
            <MenuItem value={0}>0</MenuItem>
            <MenuItem value={1}>1</MenuItem>
            <MenuItem value={2}>2</MenuItem>
            <MenuItem value={3}>3</MenuItem>
            <MenuItem value={4}>4</MenuItem>
            <MenuItem value={5}>5</MenuItem>
          </Select>
        </Grid>
        <Grid item>
          <InputLabel sx={{color: 'black'}} id="emp-skills-select">Management/Supervisor</InputLabel>
          <Select
            id="managment"
            defaultValue={0}
            value={management}
            name="management"
            onChange={handleSkillsChange}
          >
            <MenuItem value={0}>0</MenuItem>
            <MenuItem value={1}>1</MenuItem>
            <MenuItem value={2}>2</MenuItem>
            <MenuItem value={3}>3</MenuItem>
            <MenuItem value={4}>4</MenuItem>
            <MenuItem value={5}>5</MenuItem>
          </Select>
        </Grid>
      </Grid>
      <Button variant="contained" color={mainSubButColor} type="button" onClick={handleSubmit}>
        Submit all information
      </Button>
      <ul className="posInfoList ">
        <h3>Skill Descriptions</h3>
        <li>Front House: </li>
        <li>Back House: </li>
        <li>Chef: </li>
        <li>Barista: </li>
        <li>Cocktail Attendant</li>
        <li>Bartender</li>
        <li>Management/Supervisor: (RMLV + Approved Managers License) </li>
      </ul>
    </div>
  )
}





export default function EmpInfo() {
  const url = 'http://localhost:3001/'
  const [showAvailability, setShowAvailability] = useState(false)


  function fetchProfileInfo() {
    let currUser = localStorage.getItem("email");
    let token = localStorage.getItem("token")

     return fetch(`http://localhost:3001/user/${currUser}/profile`, {
      method: "GET",
      headers: { 
        accept: "application/json", 
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`}
    }).then((res) => res.json())
  }


  const navigate = useNavigate();
  function fetchProfileType(){
    let currUser = localStorage.getItem("email");
    let token = localStorage.getItem("token")
    return fetch(`http://localhost:3001/user/${currUser}/profile-type`, {
      method: "GET",
      headers: { 
        accept: "application/json", 
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`}
    }).then(res => res.json ())
    .then(res => {
      if(res.type.toString() === 'client'){
        navigate("/client-info")
        console.log("navigate")
      }
      console.log(res.type)})
  }

  useEffect(
    () => {
      //fetchProfileType().then((info) => {console.log(info)})
    fetchProfileInfo().then((info) => setFormValues(info))
  }, [])


 

async function updateProfile(){
  let currUser = localStorage.getItem("email");
  let token = localStorage.getItem("token")
  await fetch(`http://localhost:3001/user/${currUser}/profile`, {
    method: "PUT",
    headers: { 
      accept: "application/json", 
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`},
    body: JSON.stringify({ 
      firstName: formValues.firstName, lastName: formValues.lastName, postCode: formValues.postCode, phoneNumber: formValues.phoneNumber,
    suburb: formValues.suburb, dob: formValues.DOB, maxHours: formValues.maxHours})
  }).then((res) => console.log("res msg for gen info = " + res.message));
}




  const [formValues, setFormValues] = useState(defaultValues);




  const[errorMsg, setErrorMsg] = useState('')

function inputsAreValid(){
  console.log(formValues.DOB.length + ' ' + formValues.DOB[2] + formValues.DOB[5])
  if(formValues.firstName == undefined || formValues.lastName ==undefined || formValues.phoneNumber == undefined || formValues.suburb == undefined || 
    formValues.postCode == undefined || formValues.DOB == undefined || formValues.maxHours == 0){
      setErrorMsg('Please ensure all information is completed prior to skill/availability selection')
      return false;
    }
    else if(formValues.firstName.length > 45 || formValues.lastName.length > 45 ||formValues.phoneNumber.length > 45 ||
      formValues.suburb.length > 45 ||formValues.postCode.length > 45 ||formValues.DOB.length > 45){
        setErrorMsg('Please ensure fields adhere to their 45 character limit')
        return false;
      }      
    else if(formValues.DOB.length !== 10 || formValues.DOB[2] !== '/' || formValues.DOB[5] !== '/'){
      setErrorMsg('Please ensure DOB is structure as dd/mm/yyyy')
    }else{
      return true;
    }
}

  function handleMoreButton(){
    console.log(formValues.firstName.length)
    if(inputsAreValid()){
      updateProfile();
      setShowAvailability(true);
      setErrorMsg('')
    }else{
        //setErrorMsg('please ensure inputs are valid')
    }
    
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
  };



  //const { mon, tue, wed, thur, fri, sat, sun } = daysWorkable;
  


  const useStyles = makeStyles(() => ({
    textField: {
      width: "60%",
      marginLeft: "auto",
      marginRight: "auto",
      paddingBottom: 0,
      marginTop: 10,
      marginBottom: 100,
      fontWeight: 500,
      backgroundColor: '#f8f8f8',
    },
    textField2: {
      width: "100%",
      paddingBottom: 0,
      marginTop: 10,
      marginBottom: 100,
      fontWeight: 500,
      backgroundColor: '#f8f8f8',
    },
    input: {
      color: "black", 
    }}))
    const classes = useStyles();


//let count = 0;
  
    return (   
      <div className="updateEmpInfo">
        <img src = {logo} alt ="stitchhire-logo" className="logo" />
<form>
      <Grid container alignItems="center" justify="center" direction="column">
        <Grid item>
          <TextField
            id="firstName"
            name="firstName"
            label="First Name"
            type="text"
            value={formValues.firstName}
            onChange={handleInputChange}
            margin="normal"
            InputProps={{
              className: classes.input
            }}
            className={classes.textField}
          />
          <TextField
            id="lastName"
            name="lastName"
            label="Last Name"
            type="text"
            value={formValues.lastName}
            onChange={handleInputChange}
            margin="normal"
            InputProps={{
              className: classes.input
            }}
            className={classes.textField}
          />
          <TextField
            id="phoneNumber"
            name="phoneNumber"
            label="Phone Number "
            type="text"
            value={formValues.phoneNumber}
            onChange={handleInputChange}
            margin="normal"
            InputProps={{
              className: classes.input
            }}
            className={classes.textField}
          />
        </Grid>    
        <Grid>
        <TextField
            id="suburb"
            name="suburb"
            label="Suburb"
            type="text"
            value={formValues.suburb}
            onChange={handleInputChange}
            margin="normal"
            InputProps={{
              className: classes.input
            }}
            className={classes.textField}
          />
        <TextField
            id="postCode"
            name="postCode"
            label="Post Code"
            type="text"
            value={formValues.postCode}
            onChange={handleInputChange}
            margin="normal"
            InputProps={{
              className: classes.input
            }}
            className={classes.textField}
          />
          <TextField
            id="DOB"
            name="DOB"
            label="DOB"
            type="text"
            value={formValues.DOB}
            onChange={handleInputChange}
            margin="normal"
            InputProps={{
              className: classes.input
            }}
            className={classes.textField}
          />
        </Grid>
        <Grid>
        <TextField
            id="maxHours"
            name="maxHours"
            label="Maximum Workable Hours /Week"
            type="number"
            value={formValues.maxHours}
            onChange={handleInputChange}
            margin="normal"
            InputProps={{
              className: classes.input
            }}
            className={classes.textField2}
          />
        </Grid>
        </Grid>
        </form>
        <Button onClick={() => handleMoreButton()}>NEXT</Button>
        {showAvailability ? <AvailabilitySkills />: null}
        <span className="errorSpan">{errorMsg}</span>
      </div>     
  );
  }

  