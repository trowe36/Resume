import React from "react";
import { useState, useEffect } from "react";
import Button from "@material-ui/core/Button";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";

export default function Admin() {
    const [rosterDate, setRosterDate] = useState('')

    const [todaysDate, setTodaysDate] = useState('')
    const[thisDuration, setThisDuration] = useState(6) //6 days extra including start day =7days whole week
    const handleSubmit = (event) => {
        event.preventDefault()
        sendToApi();
      };
      const fillRoster = (event) => {
        event.preventDefault()
        generateRoster();
      };
      const addEmployeesToRoster = (event) => {
        event.preventDefault()
        allocateWorkers()
      }

      const handleChange = (e) => {
        const { name, value } = e.target;
        e.preventDefault()
        setRosterDate(value)
        console.log(rosterDate)
      };

      const handleChangeTwo = (e) => {
        const { name, value } = e.target;
        e.preventDefault()        
        if(name === "todaysDate"){
            setTodaysDate(value)
        }
        if(name === "thisDuration"){
            setThisDuration(value)
        }
      };

      async function allocateWorkers() {
        await fetch(`http://localhost:3001/api/job-panel`, {
            method: "GET",
            headers: { 
              accept: "application/json", 
            "Content-Type": "application/json"}  
      })}

      async function allocate(){
        await fetch(`http://localhost:3001/api/allocate-workers`, {
            method: "GET",
            headers: { 
              accept: "application/json", 
            "Content-Type": "application/json"}}).then((res) => console.log(res.json()))      
      }
      

      async function generateRoster(){
        await fetch(`http://localhost:3001/api/generate-roster`, {
            method: "GET",
            headers: { 
              accept: "application/json", 
            "Content-Type": "application/json"}}).then((res) => console.log(res.json()))
      }

      async function sendToApi(){
        // let ros = rosterDate.toString().substring(0,2)
        // let tod = todaysDate.toString().substring(0,2)
        await  fetch(`http://localhost:3001/api/update-roster`, {
            method: "PUT",
            headers: { 
              accept: "application/json", 
            "Content-Type": "application/json"},
            body: JSON.stringify({rosterStart : rosterDate, today : todaysDate, duration : thisDuration})
          }).then((res) => console.log(res.json()))
      }

    return (
      <div>
        <h1>admin page</h1>
        <form onSubmit={handleSubmit}>
            <Grid>
            <Grid item>
            <TextField
              id="rosterDate"
              name="rosterDate"
              label="roster start Date as 'dd/mm/yyyy' "
              type="text"
              value={rosterDate}
              onChange={handleChange}
            />

            <TextField
              id="todaysDate"
              name="todaysDate"
              label="todaysDate' "
              type="text"
              value={todaysDate}
              onChange={handleChangeTwo}
            />
            <TextField
              id="thisDuration"
              name="thisDuration"
              label="Roster Duration "
              type="number"
              value={thisDuration}
              onChange={handleChangeTwo}
            />

          </Grid>
          <Button variant="contained" type="submit"> submit </Button>
            </Grid>           
          </form>
          <Button variant="contained" type="button" onClick={fillRoster}> Fill Roster with Jobs</Button>
          <Button variant="contained" type="button" onClick={addEmployeesToRoster}> Create JOB PANELS </Button>
          <Button variant="contained" type="button" onClick={allocate}> ALLOCATE </Button>


          

      </div>
    );
  }