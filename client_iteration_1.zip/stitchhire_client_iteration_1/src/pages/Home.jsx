import React, { useState } from 'react';
import DateTimePicker from 'react-datetime-picker';

export default function Home() {
  return (
    <div>
      <h1>Hello from HOMEPAGE</h1>
    </div>
  );
}