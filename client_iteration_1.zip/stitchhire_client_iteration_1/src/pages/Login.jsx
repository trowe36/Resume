import React from "react";
import {useState} from "react"
import CustomInput from "../components/CustomInput";
import Button from "../components/Button";
import "../App.css"
import FormLabel from "@material-ui/core/FormLabel";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { GlobalStyles, Radio } from "@material-ui/core";
import {FormControl} from "@material-ui/core";
import { setOriginalNode } from "typescript";
import { Navigate, useNavigate } from "react-router-dom";
import { blue } from "@material-ui/core/colors";
import { sizeHeight } from "@material-ui/system";
import logo from "../images/logo.png"
//import GlobalStyles from '@mui/material/GlobalStyles';
export default function Login() {
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const[iAmA, setIAmA] = useState("worker");
  const navigate = useNavigate();
  const INCOMPLETE = "Request body incomplete, both email and password are required"
  const INCORRECT = "Incorrect email or password" 
  const VALID = "Bearer"
  const loginState = {
    email: "",
    password: ""
  }
  const validateEmail = (email) => {
    return String(email)
      .toLowerCase()
      .match(
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      );
  };

  function fetchURL(){
    console.log("fetching url")
    const url = 'http://localhost:3001/user/login'
    
      let token = localStorage.getItem("token")
      console.log(token)
      if(token !== undefined && token !== null){
        setLoginError("You are already logged in")
      }
      else{
        console.log("values in body: " + name + password)
        return fetch(url, {
          method: "POST",
          headers: {accept: "application/json", "Content-Type": "application/json"},
          body: JSON.stringify({email: name, password: password})
        })
        .then(res => res.json ())
        .then(res => {
          console.log(res)
          if(res.message == INCOMPLETE){
            setLoginError(INCOMPLETE)
            console.log(INCOMPLETE)
          }
          if(res.message == INCORRECT){
            setLoginError(INCORRECT)
            console.log(INCORRECT)
          }
          if(res.token_type === VALID){
            localStorage.setItem("token", res.token)
            localStorage.setItem("email", name)
            if(res.type === "worker"){
              window.location.replace("/update-emp-info");
            }else if (res.type =="client"){
              navigate("/client-info"); //TODO change
            }else{
              console.log("error fetching user type (client/worker)")
            }
          }       
        })
      }
  }
  function goRegister(){
    navigate("/register")
  }
    

  function logout(){
    let token = localStorage.getItem("token")
    if(token == undefined)
    {
      setLoginError("you are not logged in");
    }
    else{
      console.log("Removing item from local storage" + localStorage.getItem("token"))
      localStorage.removeItem("token")
      setLoginError("Logged Out")
    }

 }
    const handleChange = e => {
      console.log(JSON.stringify(e.target.id))
      if(e.target.id == "name"){
        setName(e.currentTarget.value)
      }
      else if(e.target.id == "password"){
        setPassword(e.currentTarget.value)
      }
    };

    const handleRadioChange = e => {
      setIAmA(e.currentTarget.value)
    }

    return (
      <div className="loginForm">
        <img src = {logo} alt ="stitchhire-logo" className="logo" />
        <form className="form">
          <CustomInput
          className ="emailInput"
            labelText="Email"
            value = {name}
            id="name"
            //<GlobalStyles styles ={{emailInput: {color: 'grey'}}} />
            formControlProps={{
              fullWidth: true,
            }}
            handleChange={handleChange}
            type="text"
          />
          <CustomInput
          className="passInput"
            labelText="Password"
            id="password"
            formControlProps={{
              fullWidth: true
            }}
          handleChange={handleChange}
            type="password"
          />

          <Button type="button" color="primary" className="form__custom-button" onClick ={fetchURL}>
            Log in
          </Button>
          <Button type="button" onClick={logout}> logout</Button>
          <Button type="button" onClick={goRegister}>Register</Button>  
        </form>
      </div>
    );

  }