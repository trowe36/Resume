import React, { useState, useEffect } from "react";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";
import RadioGroup from "@material-ui/core/RadioGroup";
import Radio from "@material-ui/core/Radio";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import Slider from "@material-ui/core/Slider";
import Button from "@material-ui/core/Button";
import BasicDateTimePicker from "../components/BasicDateTimePicker";
import { Navigate, useNavigate } from "react-router-dom";
import { validateDateTime } from "@material-ui/lab/internal/pickers/date-time-utils";
import { makeStyles} from "@material-ui/styles"
import logo from "../images/logo.png"
import { FormControlUnstyledContext } from "@material-ui/core";

const defaultValues = {
  company: "",
  companyContactNumber: "",
  contactName : "",
  contactNumber: "",
  specialNotes: "",
  meetingLocation: "",
  date: "",
  dressCode: ""
};
const defaultWorkerValues = {
  workerSkill: "",
  workerType: "",
  requiredWorkers: 0,
};
let formDivCounter = 0;

export default function Workform(){  
  const[cantProceed, setCantProceed] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const dateValues = {
    daydd: '',
    monthmm: '',
    yearyyyy: ''
  }
  const[myDate, setMyDate] = useState(dateValues)

  const workerState = {
    1: {
      workerSkill: "",
      workerType: "",
      requiredWorkers: 0,
      timeFromX: "",
      timeToY: ""
    },
    2: {
      workerSkill: "",
      workerType: "",
      requiredWorkers: 0,
      timeFromX: "",
      timeToY: ""
    },
    3: {
      workerSkill: "",
      workerType: "",
      requiredWorkers: 0,
      timeFromX: "",
      timeToY: ""
    },
    4: {
      workerSkill: "",
      workerType: "",
      requiredWorkers: 0,
      timeFromX: "",
      timeToY: ""
    },
    5: {
      workerSkill: "",
      workerType: "",
      requiredWorkers: 0,
      timeFromX: "",
      timeToY: ""
    }
  }
  const[mainState, setMainState] = useState(workerState)


  function validDate(data) {
    if (data.length === 10) {
      if (data[2] === '/' || data[5] === '/') {
        var jobDate = new Date()
        var jobdd = data[0] + data[1]
        var jobmm = data[3] + data[4]
        var jobyyyy = data[6] + data[7] + data[8] + data[9]
        jobDate = jobdd + '/' + jobmm + '/' + jobyyyy
        var today = new Date();
        var dd = today.getDate().toString().padStart(2, '0');
        var mm = (today.getMonth() + 1).toString().padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear().toString();
        const job = new Date(jobyyyy, jobmm, jobdd)
        const newToday = new Date(yyyy, mm, dd)
        newToday.setDate(today.getDate() + 8)
        job.setMonth(job.getMonth() - 1) //correct index from user input to what computer reads eg starts at 0 index
        if (newToday.getDate() > job.getDate()) {
          //check date in pass else success
          const tt = new Date(yyyy, mm, dd)
          if (job.getDate() < tt.getDate()) {
            setError("job date cannot be in past")
            return false
          } else {
            setError("not within a week")
            return false;
          }
        } else {
          if (job.getDate() < newToday.getDate()) {
            setError("job date cannot be in past")
            return false
          } else {
            return true;
          }
        }
      } else {
        setError("ensure date is structured as dd/mm/yyyy")
        return false;
      }
    } else {
      setError("ensure date is structured as dd/mm/yyyy")
      return false;
    }
  }

  function cardDetailsOk(skill, workType, numWorkers, from ,to){
   // console.log(skill+ '  ' + '  ' + workType + '  ' + numWorkers + to + from)
    if(numWorkers <= 0){
      setError('Required Workers Cannot be 0')
      return false
    }
    else if(skill ==="" || workType === ""){
      setError('Please ensure worker type and worker skill have been selected')
      return false
    }
    from.setHours(from.getHours() + 3)
    console.log(from.getHours())
    console.log(to.getHours())
    console.log('145')
    if(parseInt(from.getHours()) > parseInt(to.getHours())){ 
      setError('Shifts 3 to 12 hours in length permitted ')
      from.setHours(from.getHours() - 3)
      return false
    }
    else if(parseInt(from.getHours()) === parseInt(to.getHours())){
      if(parseInt(from.getMinutes()) > parseInt(to.getMinutes())){
        setError('Shifts 3 to 12 hours in length permitted ')
        from.setHours(from.getHours() - 3)
        return false
      }else if(parseInt(from.getMinutes()) == parseInt(to.getMinutes())){
        from.setHours(from.getHours() - 3)
        return true;
      }
    }
    else if(parseInt(from.getHours()) < parseInt(to.getHours())){
      //make hours to 12. check again like above for 12 hours TODO
      //TODO add validation for jobs spanning two dates 
      from.setHours(from.getHours() - 3)
      return true;
    }
    // if(parseInt((from.getHours()) %12) >= parseInt(to.getHours())){  
    //   console.log('146')   
    //   if(parseInt((from.getHours() % 12)) === parseInt(to.getHours())){
    //     console.log('148')  
    //     if(parseInt(from.getMinutes()) < parseInt(to.getMinutes())){
    //       console.log('150')  
    //       from.setHours(from.getHours() - 3)
    //       return true;
    //     }
    //     else if(parseInt(from.getMinutes()) > parseInt(to.getMinutes())){
    //       setError('Shifts 3 to 12 hours in length permitted ')
    //       console.log("156")
    //       from.setHours(from.getHours() - 3)
    //       return false;
    //     }
    //     else if(parseInt((from.getMinutes())) === parseInt((to.getMinutes()))){
    //       console.log('160')  
          
    //       from.setHours(from.getHours() - 3)
    //       return true;
    //     }
    //   }
    //   else if(parseInt((from.getHours() % 12)) > parseInt(to.getHours())){
    //     from.setHours(from.getHours() - 3)
    //     setError('Shifts 3 to 12 hours in length permitted ')
    //     console.log("168")
    //     return false;
    //   }
    // }
    // if(parseInt((from.getHours()) > 11)){
    //   if( 12 % parseInt((from.getHours())) < parseInt(to.getHours())){
    //     console.log('176')
    //     return true;
    //   }
    // }
    // else if( parseInt((from.getHours())) % 12 < parseInt(to.getHours())){
    //   console.log("175")
    //   from.setHours(from.getHours() - 3)
    //   return true;
    // }
    // from.setHours(from.getHours() - 3)
  }

  const createDivs = () =>{
    console.log(formValues)
    if (formValues.company == '' || formValues.companyContactNumber == '' || formValues.contactName == '' ||
      formValues.contactNumber == '') {
      setError('Please ensure all information is completed prior to posting a job')
      return false;
    }
    else if (formValues.company.length > 45 || formValues.companyContactNumber.length > 45 || formValues.contactName.length > 45 ||
      formValues.contactNumber.length > 45) {
      setError('Please ensure fields adhere to their 45 character limit')
      return false;
    }
    if (formValues.date == "") {
      setError("cant proceed no date")
    }
    else {
      if (validDate(formValues.date)) {
        myDate.daydd = formValues.date[0] + formValues.date[1]
        myDate.monthmm = formValues.date[3] + formValues.date[4]
        myDate.yearyyyy = formValues.date[6] + formValues.date[7] + formValues.date[8] + formValues.date[9]
        //console.log(myDate.daydd)
        if (formDivCounter == 0) { setCantProceed(true) }
        formDivCounter++;
        if (formDivCounter >= 6) {
          //do nothing only allow 5 divs
          setError('Only 5 Work Cards permitted')
        } else {
          //setCantProceed(true)
          setExtraDivs(extraDivs.concat(<RequireWorkers />))
        }
      } else {// date not valid
        //console.log("the date is not valid. eg dd/mm/yyyy or 8 days away")
        //do nothing
      }
    }
  };

  const [formValues, setFormValues] = useState(defaultValues);
  const [clicks, setClicks] = useState(0);
  const[extraDivs, setExtraDivs] = useState([]);
  const[mainSubButColor, setMainSubButColor] = useState("error")
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    //update default values if updated
    updateGenInfo();
    //for each worker card. send to API endpoint. handles createtable. 
    console.log(formValues);
    console.log(mainState)

    if(!cantProceed){ //can proceed. eg info saved
      setTotalWorkers()
      submitWholeForm();
      console.log("error msg = " + error.value)
      if(error === ''){
        setMainSubButColor("success")
        console.log("error msg = " + error.value)
      }else{
        setMainSubButColor("error")
      }
    }else{
      setError('Error Submitting, Please Check all Fields')
    }
    console.log(cantProceed)
    
  };

  //useeffect to retreive client info. (server -GET)
  useEffect(
    () => {
      fetchProfileType()
      fetchClientInfo().then((info) => {
        var obj = info;
        formValues.company = Object.values(obj)[0];
        formValues.companyContactNumber = Object.values(obj)[1];
        formValues.contactName = Object.values(obj)[2];
        formValues.contactNumber = Object.values(obj)[3];
        setFormValues({...formValues})
      }
      )
    }, [])

  let workersTotal = 0
  function setTotalWorkers() {
    Object.entries(mainState).forEach(([key, value]) => {
      workersTotal += parseInt(Object.values(value)[2])
    })
  }

  const navigate = useNavigate();
  function fetchProfileType(){
    let currUser = localStorage.getItem("email");
    let token = localStorage.getItem("token")
    return fetch(`http://localhost:3001/user/${currUser}/profile-type`, {
      method: "GET",
      headers: { 
        accept: "application/json", 
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`}
    }).then(res => res.json ())
    .then(res => {
      if(res.type.toString() === 'worker'){
        navigate("/update-emp-info")
        //console.log("navigate")
      }
      //console.log(res.type)})
  })}

    async function submitWholeForm(){

      if (formValues.company == '' || formValues.companyContactNumber == '' || formValues.contactName == '' ||
        formValues.contactNumber == '') {
        setError('Please ensure all information is completed prior to posting a job')
      }
      else if (formValues.company.length > 45 || formValues.companyContactNumber.length > 45 || formValues.contactName.length > 45 ||
        formValues.contactNumber.length > 45) {
        setError('Please ensure fields adhere to their 45 character limit')
      }
      else if (formValues.dressCode.length > 255 || formValues.meetingLocation.length > 255) {
        setError('Please ensure dress code and meeting location are less than 255 characters')
      }
      else if(formValues.specialNotes.length > 500){
        setError('Special Notes must be less than 500 characters in length')
        return;
      }
      else if (formValues.date == "") {
        setError("cant proceed no date")
      }
      else if (validDate(formValues.date)) {
        setError('')
        setSuccess('Job Successfully Posted')
        let currUser = localStorage.getItem("email");
        let token = localStorage.getItem("token")
        await fetch(`http://localhost:3001/${currUser}/workform/`, {
          method: "PUT",
          headers: {
            accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({
            stateObj: mainState, date: formValues.date, dress: formValues.dressCode,
            notes: formValues.specialNotes, totalWorkers: workersTotal, meetingLocation: formValues.meetingLocation
          })
        }).then((res) => {
          console.log("res msg for put client info = " + res.json());
          workersTotal = 0;
        })
      }
    }

    async function updateGenInfo(){
      let currUser = localStorage.getItem("email");
      let token = localStorage.getItem("token")
        await fetch(`http://localhost:3001/user/${currUser}/profile-client`, {
          method: "PUT",
          headers: { 
            accept: "application/json", 
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`},
          body: JSON.stringify({ 
            companyName: formValues.company, companyNumber: formValues.companyContactNumber, contactName: formValues.contactName
          , contactNumber: formValues.contactNumber})
        }).then((res) => console.log("res msg for put client info = " + res.message));
    }

    function fetchClientInfo() {
      let currUser = localStorage.getItem("email");
      let token = localStorage.getItem("token")
  
       return fetch(`http://localhost:3001/user/${currUser}/profile-client`, {
        method: "GET",
        headers: { 
          accept: "application/json", 
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`}
      }).then((res) => res.json())
    }


  function RequireWorkers(){
    useEffect(
      () => {
      setCantProceed(true)
    }, [])

    const [workerValues, setWorkerValues] = useState(defaultWorkerValues);
    const[butColor, setButColor] = useState("error");
    const[timeFrom, setTimeFrom] = useState("");
    const[timeTo, setTimeTo] = useState("")
    const[timeFromAMPM, setTimeFromAMPM] = useState("")
    const[timeToAMPM, setTimeToAMPM] = useState("")

    const handleWorkersInputChange = (e) => {
      const { name, value } = e.target;
      setWorkerValues({
        ...workerValues,
        [name]: value,
      });
    };

    const handleAMPMChange = (e) => {
      const {name, value} = e.target;
      if(name === "timeToGroup"){
        setTimeToAMPM(value)

      }else if(name === "timeFromGroup"){
        setTimeFromAMPM(value)
      }
      //console.log(name + '  ' + value)
    }
    

    // function handleMainState(cat, key, val) {
    //   const category = {...mainState[cat]};
    //   //console.log("cat line 158:  " + Object.value(category))
    //   //console.log()
    //   category[key] = val;
    //   setMainState({ [cat]: category });
    // }

    const checkAMPM = (e) => {
      if(timeFromAMPM === "timeFromAM"){
        console.log(timeFrom)
      }
      else if(timeFromAMPM === "timeFromPM"){
        console.log(timeFrom)
        setTimeFrom(timeFrom.setHours(timeFrom.getHours() + 12))
      }
      if(timeToAMPM === "timeToAM"){

      }
      else if(timeToAMPM === "timeToPM"){
        setTimeTo(timeTo.setHours(timeTo.getHours() + 12))
      }
    }

    function checkCardDetailsGood(){
      if(cardDetailsOk(workerValues.workerSkill, workerValues.workerType, 
        workerValues.requiredWorkers, timeFrom ,timeTo)){
          console.log('from: ' + timeFrom)
          console.log('To: ' + timeTo)
          mainState[formDivCounter].workerSkill = workerValues.workerSkill
          mainState[formDivCounter].workerType = workerValues.workerType
          mainState[formDivCounter].requiredWorkers = workerValues.requiredWorkers
          mainState[formDivCounter].timeFromX = timeFrom
          mainState[formDivCounter].timeToY = timeTo
          setButColor("success")   
          setCantProceed(false)
          setError('')
        }
        else{ 
          console.log("issue with workerValues")
          setCantProceed(true)
        } 
    }

    const saveDetails = (event) => {
      //https://stackoverflow.com/questions/51399688/adding-dynamic-states-in-reactjs 
      //console.log(workerValues.workerSkill)
      event.preventDefault();
      //if pm + 12 hours before validtion . so it works as normal 
      if(timeToAMPM === "" || timeFromAMPM === ""){
        setError("Please specify AM/PM for time to/time from")
      }
      checkAMPM()
      checkCardDetailsGood() //first check am/pm and add to 12 hour time before later date validation. eg callback
    };

    return (  
      <div className="workCardStyles">
        <form>
        <Grid item>
            <TextField
              id="requiredWorkers"
              name="requiredWorkers"
              label="required workers"
              type="number"
              value={workerValues.requiredWorkers}
              onChange={handleWorkersInputChange}
            />
          </Grid>
          <Grid item>
            <FormControl>
              <FormLabel className = "workerTypeHeading" sx={{color: 'black', fontSize: 18}}>Worker Type</FormLabel>
              <RadioGroup
                name="workerType"
                value={workerValues.workerType}
                onChange={handleWorkersInputChange}
              >
                <FormControlLabel
                  key="frontHouse"
                  value="frontHouse"
                  control={<Radio size="small" />}
                  label="Front of House"
                />
                <FormControlLabel
                  key="backHouse"
                  value="backHouse"
                  control={<Radio size="small" />}
                  label="Back of House"
                />
                <FormControlLabel
                  key="bartender"
                  value="bartender"
                  control={<Radio size="small" />}
                  label="Bartender"
                />
                <FormControlLabel
                  key="barista"
                  value="barista"
                  control={<Radio size="small" />}
                  label="Barista"
                />
                <FormControlLabel
                  key="cockAttendant"
                  value="cockAttendant"
                  control={<Radio size="small" />}
                  label="Cocktail Attendant"                 
                />
                <FormControlLabel
                  key="chef"
                  value="chef"
                  control={<Radio size="small" />}
                  label="Chef"
                />
                <FormControlLabel
                  key="management"
                  value="management"
                  control={<Radio size="small" />}
                  label="Management/Supervisor (RMLV + Approved Managers License)"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          <Grid item>
            <FormControl>
              <FormLabel className="workerSkillLabel" sx={{color: 'black', fontSize: 18}}>Worker Skill Level</FormLabel>
              <RadioGroup
                name="workerSkill"
                value={workerValues.workerSkill}
                onChange={handleWorkersInputChange}
                row
              >
                <FormControlLabel
                  key="premium"
                  value="premium"
                  control={<Radio size="small" />}
                  label="premium"
                  />
                <FormControlLabel
                  key="standard"
                  value="standard"
                  control={<Radio size="small" />}
                  label="standard"
                  
                />
                <FormControlLabel
                  key="juniorOld"
                  value="juniorOld"
                  control={<Radio size="small" />}
                  label="Under 18 Junior"
                />
                <FormControlLabel
                  key="juniorYoung"
                  value="juniorYoung"
                  control={<Radio size="small" />}
                  label="Under 16 Junior"
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          <div className="space">
          <FormLabel sx={{color: 'black', fontSize: 18}}>Select Shift Time (3-12 Hours)</FormLabel>
            <div className="timeFromSelector">
              <BasicDateTimePicker year={myDate.yearyyyy} month={myDate.monthmm} day={myDate.daydd} stateChanger = {setTimeFrom}/>
              <RadioGroup
              value = {timeFromAMPM}
                name="timeFromGroup"
                row
                onChange={handleAMPMChange}
              >
                <FormControlLabel
                  key="timeFromAM"
                  value="timeFromAM"
                  control={<Radio size="small" />}
                  label="am"
                />
                <FormControlLabel
                  key="timeFromPM"
                  value="timeFromPM"
                  control={<Radio size="small" />}
                  label="pm"
                />
              </RadioGroup>
              </div>
            <div className="timeToSelector">
              <BasicDateTimePicker year={myDate.yearyyyy} month={myDate.monthmm} day={myDate.daydd} stateChanger = {setTimeTo}/>
              <RadioGroup
              value = {timeToAMPM}
                name="timeToGroup"
                row
                onChange={handleAMPMChange}
              >
                <FormControlLabel
                  key="timeToAM"
                  value="timeToAM"
                  control={<Radio size="small" />}
                  label="am"
                />
                <FormControlLabel
                  key="timeToPM"
                  value="timeToPM"
                  control={<Radio size="small" />}
                  label="pm"
                />
              </RadioGroup>
              </div>
          </div>

          
          <Button variant="contained" color= {butColor} type="button" onClick={saveDetails}>
          Save information
        </Button>
        </form>       
      </div>
    )
  }

  const useStyles = makeStyles(() => ({
    textField: {
      width: "60%",
      marginLeft: "auto",
      marginRight: "auto",
      paddingBottom: 0,
      marginTop: 10,
      marginBottom: 100,
      fontWeight: 500,
      backgroundColor: '#f8f8f8',
    },
    textField2: {
      width: "47%",
       marginLeft: 'auto',
       marginRight: 'auto',
      paddingBottom: 0,
      marginTop: 100,
      marginBottom: 10,
      fontWeight: 500,
      backgroundColor: '#f8f8f8',
    },
    textField3: {
      width: "60%",
       marginLeft: 'auto',
       marginRight: 'auto',
      paddingBottom: 50,
      marginTop: 100,
      marginBottom: 0,
      fontWeight: 500,
      backgroundColor: '#f8f8f8',
    },
    input: {
      color: "black",

    }
  }));
  const classes = useStyles();
  return ( 
    <div className="workFormStyles">
      <img src = {logo} alt ="stitchhire-logo" className="logo" />
<form onSubmit={handleSubmit}>
      <Grid container alignItems="center" justify="center" direction="column">
        <Grid item>
          <TextField
            id="company-input"
            name="company"
            margin="normal"
            label="company"
            type="text"
            value={formValues.company}
            onChange={handleInputChange}
            InputProps={{
              className: classes.input
            }}
            className={classes.textField}
          />
          <TextField
            id="companyContactNumber"
            name="companyContactNumber"
            label="Company Number"
            type="text"
            value={formValues.companyContactNumber}
            onChange={handleInputChange}
            margin="normal"
            InputProps={{
              className: classes.input
            }}
            className={classes.textField}
          />
          <TextField
            id="company-contact-name"
            name="contactName"
            label="Company Contact Name"
            type="text"
            value={formValues.contactName}
            onChange={handleInputChange}
            margin="normal"
            InputProps={{
              className: classes.input
            }}
            className={classes.textField}
          />
          <TextField
            id="company-contact-number"
            name="contactNumber"
            label="Company Contact Number"
            type="text"
            value={formValues.contactNumber}
            onChange={handleInputChange}
            margin="normal"
            InputProps={{
              className: classes.input
            }}
            className={classes.textField}
          />
          <TextField
            id="date"
            name="date"
            label="Job Date"
            type="text"
            value={formValues.date}
            onChange={handleInputChange}
            margin="normal"
            InputProps={{
              className: classes.input
            }}
            className={classes.textField}
          />
        </Grid>
        
        <ul>
          {extraDivs.map(divs => <li className="divLists">{divs}</li>)}
        </ul>

        <Button className="createDivsButton" disabled={cantProceed} variant="contained" color="primary" type="button" onClick={createDivs}>
         Select Workers
        </Button>
        <TextField
          id="meetingLocation"
          name ="meetingLocation"
          label = "Meeting Location"
          type= "text"
          value={formValues.meetingLocation}
          onChange={handleInputChange}
          margin="normal"
          InputProps={{
            className: classes.input
          }}
          className={classes.textField2}
        />
        <TextField
          id="dressCode"
          name ="dressCode"
          label = "Dress Code"
          type= "text"
          value={formValues.dressCode}
          onChange={handleInputChange}
          margin="normal"
          InputProps={{
            className: classes.input
          }}
          className={classes.textField2}
        />
        <TextField
          id="specialNotes"
          name ="specialNotes"
          label = "Please enter any special considerations relative to your job request (100 characters)"
          multiline

          maxRows={4}
          value={formValues.specialNotes}
          onChange={handleInputChange}
          margin="normal"
          InputProps={{
            className: classes.input
          }}
          className={classes.textField3}
        />    
        <Button variant="contained" color={mainSubButColor} type="submit">
         Submit all information
        </Button>
      </Grid>
      <span className="errorSpan">{error}</span>
      <span className="successSpan">{success}</span>
    </form>   
    </div>  
      
  );
};
