import React from "react";
import { Link } from "react-router-dom";
import ScheduleSelector from 'react-schedule-selector'
import { useState, useEffect } from "react";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { borderColor, fontWeight } from "@material-ui/system";
import { Navigate, useNavigate } from "react-router-dom";
import { makeStyles} from "@material-ui/styles"
import logo from "../images/logo.png"
const defaultValues = {
    companyName: "",
    companyNumber: "",
    contactName: "",
    contactNumber : ""
  };

export default function ClientInfo() {

  const [formValues, setFormValues] = useState(defaultValues);
  const [mainSubButColor, setMainSubButColor] = useState("error")
  const[canContinueColor, setCanContinueColor] = useState("error")
  const[error, setError] = useState('')


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    //setMainSubButColor("success")
    checkInputs()//check inputs. only send to db if no input error 
    if(error ==''){//then no error in input. send to db
      sendToDB();
    }
    
    
    //setCanContinueColor("success")
  };

  function goToJobPost(){
    console.log(formValues)
    if(formValues.companyName == "" || formValues.companyNumber == "" || formValues.contactName == "" || formValues.contactNumber == ""){
      setError('details are incomplete!')
      
    }else{
      sendToDB()
      navigate("/workform");
    }

  }

  function checkInputs() {
    console.log("checking inputs + " + formValues.companyName)
    if (formValues.companyName == "" || formValues.companyNumber == "" || formValues.contactName == "" || formValues.contactNumber == "") {
      setError('Ensure all fields are complete prior to job posting')
      setMainSubButColor("error")
      setCanContinueColor("error")
    }
    else if (formValues.companyName.length > 45 || formValues.companyNumber.length > 45 || formValues.contactName.length > 45 ||
      formValues.contactNumber.length > 45) {
      setError('Please ensure fields adhere to their 45 character limit')
      setMainSubButColor("error")
      setCanContinueColor("error")
      return false;
    }
    else {
      setError('')
      setMainSubButColor("success")
      setCanContinueColor("success")
    }
  }
  //useeffect to retreive client info. (server -GET)
  useEffect(
    () => {
      fetchClientInfo().then((info) => {
        if(info.error == true){          
          checkInputs()
        }else {setFormValues(info) }
      })
      
    }, [])

  //submit method that sends the data to the database (server PUT)
  async function sendToDB() {
    let currUser = localStorage.getItem("email");
    let token = localStorage.getItem("token")
    await fetch(`http://localhost:3001/user/${currUser}/profile-client`, {
      method: "PUT",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({
        companyName: formValues.companyName, companyNumber: formValues.companyNumber, contactName: formValues.contactName
        , contactNumber: formValues.contactNumber
      })
    }).then((res) => console.log("res msg for gen info = " + res.message));
  }

  function fetchClientInfo() {
    let currUser = localStorage.getItem("email");
    let token = localStorage.getItem("token")

    return fetch(`http://localhost:3001/user/${currUser}/profile-client`, {
      method: "GET",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      }
    }).then((res) => res.json())
  }

  const useStyles = makeStyles(() => ({
    textField: {
      width: "70%",
      marginLeft: "auto",
      marginRight: "auto",
      paddingBottom: 0,
      marginBottom: 0,
      fontWeight: 500,
      backgroundColor: '#f8f8f8',
      display: 'inline-block',

      // backgroundColor: "#b5f5c4",
      // marginBottom: "100px",
      // width: "100%",
      // borderColor: "red",
      // marginTop: "10px",
    },
    input: {
      color: "black",
    }
  }));

  const classes = useStyles();
  const navigate = useNavigate();
  return (
    <div className="fill-client-info-div">
      <img src={logo} alt="stitchhire-logo" className="stitchhire-logo-client-info" />
      <form onSubmit={handleSubmit}>      
        <h1>Complete Details Prior to Posting a Job
        </h1>
        <Grid container alignItems="center" justify="center" direction="column" className="form-container"         >
          <Grid item className="form-box" >
            <TextField
              id="companyName"
              name="companyName"
              label="Company Name"
              type="text"
              //class = "border-2 border-rose-600"
              value={formValues.companyName}
              onChange={handleInputChange}
              margin="normal"
              InputProps={{
                className: classes.input
              }}
              className={classes.textField}
            />
            <TextField
              margin="normal"
              InputProps={{
                className: classes.input
              }}
              className={classes.textField}
              id="companyNumber"
              name="companyNumber"
              label="Company Number"
              type="text"
              value={formValues.companyNumber}
              onChange={handleInputChange}
            />
            <TextField
              id="contactName"
              name="contactName"
              label="Company Contact Name"
              type="text"
              value={formValues.contactName}
              onChange={handleInputChange}
              margin="normal"
              InputProps={{
                className: classes.input
              }}
              className={classes.textField}
            />
            <TextField
              id="contactNumber"
              name="contactNumber"
              label="Company Contact Number"
              type="text"
              value={formValues.contactNumber}
              onChange={handleInputChange}
              margin="normal"
              InputProps={{
                className: classes.input
              }}
              className={classes.textField}
            />
          </Grid>
          <span>{error}</span>
        </Grid>
        <Button className="button" variant="contained" color={mainSubButColor} type="submit" onSubmit={handleSubmit}>
          Submit information
        </Button>
        <Button className="button" variant="contained" color={canContinueColor} type="button" onClick={goToJobPost}>
          Post Job
        </Button>
      </form>
    </div>
    
          
    );
  }