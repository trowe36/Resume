CREATE DATABASE  IF NOT EXISTS `stitchhire` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `stitchhire`;
-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: stitchhire
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clients_table`
--

DROP TABLE IF EXISTS `clients_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients_table` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyName` varchar(45) NOT NULL,
  `companyNumber` varchar(45) NOT NULL,
  `contactName` varchar(45) NOT NULL,
  `contactNumber` varchar(45) NOT NULL,
  `userIDclient` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `id_idx` (`userIDclient`),
  KEY `userIDclient` (`userIDclient`),
  CONSTRAINT `userIDclient` FOREIGN KEY (`userIDclient`) REFERENCES `clients_table` (`userIDclient`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients_table`
--

LOCK TABLES `clients_table` WRITE;
/*!40000 ALTER TABLE `clients_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `clients_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs_table`
--

DROP TABLE IF EXISTS `jobs_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs_table` (
  `id` int NOT NULL AUTO_INCREMENT,
  `totalWorkers` int NOT NULL,
  `workerAssignStatus` int NOT NULL,
  `jobDate` varchar(45) NOT NULL,
  `meetingLocation` varchar(255) DEFAULT NULL,
  `specialConsideration` varchar(500) DEFAULT NULL,
  `attire` varchar(255) DEFAULT NULL,
  `client_id_FK` int NOT NULL,
  `user_id_FK` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `client_id_FK` (`client_id_FK`) /*!80000 INVISIBLE */,
  KEY `user_id_FK` (`user_id_FK`) /*!80000 INVISIBLE */
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs_table`
--

LOCK TABLES `jobs_table` WRITE;
/*!40000 ALTER TABLE `jobs_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_skills_availability`
--

DROP TABLE IF EXISTS `worker_skills_availability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worker_skills_availability` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `frontHouse` int NOT NULL DEFAULT '5',
  `backHouse` int NOT NULL DEFAULT '5',
  `cockAttendant` int NOT NULL DEFAULT '2',
  `barista` int NOT NULL DEFAULT '0',
  `chef` int NOT NULL DEFAULT '0',
  `bartender` int NOT NULL DEFAULT '0',
  `management` int NOT NULL DEFAULT '0',
  `dayShift` tinyint DEFAULT NULL,
  `nightShift` tinyint DEFAULT NULL,
  `weekendShift` tinyint DEFAULT NULL,
  `mon` tinyint NOT NULL,
  `tue` tinyint NOT NULL,
  `wed` tinyint NOT NULL,
  `thur` tinyint NOT NULL,
  `fri` tinyint NOT NULL,
  `sat` tinyint NOT NULL,
  `sun` tinyint NOT NULL,
  `allocatedHours` int NOT NULL,
  `userTableID` int NOT NULL,
  `workerTableID` int NOT NULL,
  PRIMARY KEY (`id`,`workerTableID`),
  UNIQUE KEY `userID_UNIQUE` (`userTableID`) /*!80000 INVISIBLE */,
  UNIQUE KEY `workerTableID_UNIQUE` (`workerTableID`),
  KEY `userTableID_idx` (`userTableID`),
  KEY `workerTableID` (`workerTableID`),
  CONSTRAINT `userTableID` FOREIGN KEY (`userTableID`) REFERENCES `worker_skills_availability` (`userTableID`),
  CONSTRAINT `workerTableID` FOREIGN KEY (`workerTableID`) REFERENCES `worker_skills_availability` (`workerTableID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_skills_availability`
--

LOCK TABLES `worker_skills_availability` WRITE;
/*!40000 ALTER TABLE `worker_skills_availability` DISABLE KEYS */;
/*!40000 ALTER TABLE `worker_skills_availability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_table`
--

DROP TABLE IF EXISTS `worker_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worker_table` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) NOT NULL,
  `phoneNumber` varchar(45) NOT NULL,
  `suburb` varchar(45) NOT NULL,
  `postCode` varchar(45) NOT NULL,
  `DOB` varchar(45) NOT NULL,
  `maxHours` int DEFAULT NULL,
  `userID` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `userID_UNIQUE` (`userID`),
  KEY `userID_idx` (`userID`),
  CONSTRAINT `userID` FOREIGN KEY (`userID`) REFERENCES `worker_table` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_table`
--

LOCK TABLES `worker_table` WRITE;
/*!40000 ALTER TABLE `worker_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `worker_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-17 18:20:46
