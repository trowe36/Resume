---
title: Major Project Life: Part 1
author: Thomas Rowen - n9968075
date: 26/09/2020
---

## Build Instructions

Step 1: Open visual studio version 2019
Step 2: Select open a project or solution
Step 3: Navigate to solution file (.sln) inside folder at location Life\Life\CAB201_2020S2_ProjectPartA_nXXXXXXXX(6)\CAB201_2020S2_ProjectPartA_nXXXXXXXX\Life
Step 4: Once solution is open, within the solution explorer window. Right click on Solution 'Life' and select build
Step 5: Within the output window, select the dll file path and copy it to clipboard
Step 6: Open command prompt or windows powershell and navigate to the dll file locate use command: cd <path to dll>
Step 7: Once within the directory which contains the dll file, run the command: dotnet life.dll arg1 arg2 arg3

## Usage 

Program location (solution): \Life\Life\CAB201_2020S2_ProjectPartA_nXXXXXXXX(6)\CAB201_2020S2_ProjectPartA_nXXXXXXXX\Life

Run Instructions: 

To run the program the command dotnet life.dll should be run with arguments as shown above. These arguments are the settings the program will use at runtime and
must follow a certain structure. This structure is "--option argument", where the option is the setting and the argument is the value that setting should be set as. 
There must be a space between each option, each argument and a space between options and their arguments.  
Dimensions setting requires two arguments, most settings have some form of validation (specified below)

The command arguments this programs accepts are (in no particular oder): 

--dimensions <rows> <columns>         
Validation: Both values must be provided and must be positive integers between 4 and 48 (inclusive). 
Defaults: 16 rows and 16 columns
Explaination: Specifies the number of rows and columns in the game

--periodic         
Validation: N/A 
Defaults: periodic is set to off(false)
    
--random         
Validation: The value must be a float between 0 and 1
Defaults: Default probability 0.5 (50%)
Explaination: Controls the probability of a cell being alive 

--seed <filename>         
Validation: must be a valid absolute or relative path with .seed extension 
Defaults: no input file used (use randomisation)
Explaination: Seed file is read by the program and controls the initial configuration of alive cells

--generations <number of generations>      
Validation: Value must be positive non-zero integer
Defaults: The game will run for 50 generations
Explaination: Controls how many time the program will iterate cell formation. 

--max-update <updates per second>
Validation: The value must be a float between 1 and 30 (inclusive)
Default: 5 updates per second
Explaination: Controls how often the program will update configuration of alive cells on the grid. 

--step 
Validation: N/A
Defaults: The program will not run in step mode
Explaination: If the user specifies step mode as active, the program will not use the max update feature where the program updates automatically. Instead, the program
will wait for the user to push space before advancing to the next generation of alive cells. 




## Notes 
1. Due to design issues, if the user specifies large dimensions (eg 40 x 40) the program may operate at a slow rate. This is because the depth of the alive cells array is 
specified by multiplying row by column so that all cells can be alive at one time
2. Ensure between program run sessions that the console output window is correctly closed. Problems have been experienced where the displaysettings() method does not 
correctly display settings between run sessions as the previous session's console window has not being closed correctly before the next run of the program.
3. If settings are not displayed correctly please enlarge the console output screen.