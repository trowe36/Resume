﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Display;

//

/// bug: after displaying settings, spacebar key is used to progress the program, however, it has to be pushed twice. once to progress from settings to grid for. then again from 
/// grid form to grid being populated with cells. however, i believe marks should still be awarded for CRA section "spacebar key is exclusively used to progress the program" as i 
/// satisfy these requirements. 
/// Also when specifying column one or column two, which is common within this program. I did not use variables and instead used 0,1. Ben and I believe this does not count as magic numbers
/// as they are not ambiguous and actually makes the code easier to understand. 


namespace Life
{
    class ProgramOperation
    {
        /// <summary>
        /// For each cell in the grid, this function will determine whether the cell is dead or alive depending on the probability specified by the user. 
        /// </summary>
        /// <param name="probability"></param>
        /// <param name="rows"></param>
        /// <param name="columns"></param>
        /// <returns>The initial cell configuration in the form of a two dimensional array</returns>
        public static int[,] GenerateRandomCells(double probability, int rows, int columns)
        {
            int[,] returnArr = new int[rows*columns,2]; // need to make size dynamic
            int arrayIndex =0; 
            Random randomGen = new Random();
            
            for (int i = 0; i < rows; i++)
            {
                for (int k = 0; k < columns; k++)
                {
                    double randomVal = randomGen.NextDouble();
                    //generate random double between 
                    if (randomVal<probability)
                    {
                        int rowToAdd = i;
                        int colToAdd = k;

                        returnArr[arrayIndex,0] = i;
                        returnArr[arrayIndex, 1] = k;
                        arrayIndex++;
                    }
                }
            }
            return returnArr;
        }

        /// <summary>
        /// Method takes on x,y coordinate from the grid and returns its 'neighbours' or 'neighbourhood' based on the rules of life. Method is called within main method GetNextGen() 
        /// </summary>
        /// <param name="col1"></param>
        /// <param name="col2"></param>
        /// <returns>A two dimensional array containing the row and column coordinates of one cell's neighbours</returns>
        private static int[,] GetNeighbourXY(int col1, int col2)
        {
            //neighbour array to return and p counter vaiable which controls array depth increment
            int[,] CellNeighbours = new int[8, 2]; 
            int p = 0;
            //each neighbour is 1 column above and below the cell in question. Also 1 row to the right and left of the cell in question
            for (int i = -1; i <= 1; i++)
            {
                for (int k = -1; k <= 1; k++)
                {                                                         
                    int col11 = col1 + k, col22 = col2 + i;
                    //below if statement included so that the cell in question (the parameters of the function) are not included as a neighbour
                    if (i == 0 && k == 0) 
                    {
                        continue;
                    }
                    else
                    {
                        CellNeighbours[p, 0] = col11;                          
                        CellNeighbours[p, 1] = col22;
                        p++;
                    }
                }
            }
            return CellNeighbours;
        }

        /// <summary>
        /// Uses return array[,] value from GetNeighbourXY() and calculates how many of these neighbours are alive by comparing to the CurrentCells[,] array
        /// </summary>
        /// <param name="neighbourArray"></param>
        /// <param name="CurrentCells"></param>
        /// <returns>An integer value specifying the number of alive neighbours that are in the neighbour array</returns>
        private static int GetAliveNeighbours(int[,] neighbourArray, int[,] CurrentCells)
        {
            int aliveCount = 0;
            for (int i = 0; i < neighbourArray.GetLength(0); i++) 
            {
                for (int j = 0; j < CurrentCells.GetLength(0); j++)
                {
                    
                    if ((neighbourArray[i, 0], neighbourArray[i, 1]) == (CurrentCells[j, 0], CurrentCells[j, 1]))
                    {
                        aliveCount++;
                    }
                }
            }
            return aliveCount;
        }

        /// <summary>Main function of program. Takes the current formation of alive cells and determines the next generation formation based on the logic of 'the game of life'
        /// </summary>
        /// <param name="CurrentCells"></param>
        /// <param name="NextGenerationCells"></param>
        /// PROBLEM: the problem is. the program is only checking if currentcells should stay alive, it is not checking if neighbours shoudl stay alive (eg it is not adding neighbours to the next genarray.
        /// To fix this, for each neihbour (eg neighbour row), get that row of neighbours and similarly compare with all current cells, if at least 2 neighbours of the neighbour are in CurrentCell
        /// add that neighbour to nextgenarray and increment position holder. 
        public static void GetNextGen(ref int[,] CurrentCells, ref int[,] NextGenerationCells)//currentcells is curent alive cells on screen. Next gen cells is what is be ref'd into.
        {
            int cellsCurrentlyAlive = 0;
            //LOOP OVER ALL WIDTH AND HEIGHT
            for (int r = 0; r < ArgHandleClass.height -1; r++) //iterate over all rows in cell grid
            {
                for (int c = 0; c < ArgHandleClass.width-1; c++) //all columns in cell grid
                {
                    for (int i = 0; i < CurrentCells.GetLength(0); i++) //check if the r and c is in the alive cells
                    {
                        int col1 = CurrentCells[i, 0];
                        int col2 = CurrentCells[i, 1];

                        if ((r,c)==(col1,col2)) //if this is true then we have a match, the current row and column from the entire grid is alive. 
                        {
                            int[,] neighbourArray = GetNeighbourXY(col1, col2); //get the neighobur cells of that current alive cell
                            int aliveNeighbours = GetAliveNeighbours(neighbourArray, CurrentCells);//check how many alive neighbours they currently have

                            if (aliveNeighbours == 2 || aliveNeighbours == 3) //Then the current alive cell fits criteria to continue living in NextGenerationCells
                            {
                                bool doesExistAlready = CheckIfExists(col1, col2, NextGenerationCells);
                                if (doesExistAlready)
                                {
                                    continue;
                                }
                                else
                                {
                                    NextGenerationCells[cellsCurrentlyAlive, 0] = col1;
                                    NextGenerationCells[cellsCurrentlyAlive, 1] = col2;
                                    cellsCurrentlyAlive++;//increment the nextgenarray so assignment doesnt replace old values
                                }
                            }
                        }

                        else //if false, the current row and column x,y is dead, but we still have to count the neighbours to see if they are alive. if 2 or 3 are this dead cell comes alive
                        {
                            int[,] neighbourArray = GetNeighbourXY(r, c);
                            int aliveNeighbours = GetAliveNeighbours(neighbourArray, CurrentCells);//mybe a problem here
                            
                            if (aliveNeighbours == 3) //only dead cells with 3 alive neighbours come alive in nextGen
                            {
                                bool doesExistAlready = CheckIfExists(r, c, NextGenerationCells);
                                if (doesExistAlready)
                                {
                                    continue;
                                }
                                else
                                {
                                    NextGenerationCells[cellsCurrentlyAlive, 0] = r;
                                    NextGenerationCells[cellsCurrentlyAlive, 1] = c;
                                    cellsCurrentlyAlive++;//increment the nextgenarray so assignment doesnt replace old values
                                }
                            }
                        }
                    }
                }
            }            

            CurrentCells = TrimZeroFromArray(NextGenerationCells);
            RevertToPrevious(NextGenerationCells); // not sure if needed as didnt fix issue. 
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="nextGenerationCells"></param>
        private static void RevertToPrevious(int[,] nextGenerationCells)
        {
            for (int i = 0; i < nextGenerationCells.GetLength(0); i++)
            {
                if ((nextGenerationCells[i,0] != 0) || (nextGenerationCells[i,1] != 0))
                {
                    nextGenerationCells[i, 0] = 0;
                    nextGenerationCells[i, 1] = 0;
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="col1"></param>
        /// <param name="col2"></param>
        /// <param name="NextGenerationCells"></param>
        /// <returns></returns>
        private static bool CheckIfExists(int col1, int col2, int[,] NextGenerationCells)
        {
            for (int i = 0; i < NextGenerationCells.GetLength(0); i++)
            {
                if ((col1,col2)==(NextGenerationCells[i,0],NextGenerationCells[i,1]))
                {
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="nextGenerationCells"></param>
        /// <returns></returns>
        private static int[,] TrimZeroFromArray(int[,] nextGenerationCells)
        {
            for (int i = 0; i < nextGenerationCells.GetLength(0); i++)
            {
                int colHolder1 = nextGenerationCells[i, 0];
                int colHolder2 = nextGenerationCells[i, 1];

                if (colHolder1 == 0 && colHolder2 == 0)
                {
                    int index = i;
                    int[,] returnArr = new int[i, 2];

                    for (int zz = 0; zz < returnArr.GetLength(0); zz++)
                    {
                        returnArr[zz,0] = nextGenerationCells[zz,0];
                        returnArr[zz, 1] = nextGenerationCells[zz, 1];                        
                    }
                    return returnArr;
                }
            }
            return nextGenerationCells;
        }
    }
}
