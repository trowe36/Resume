﻿using System;
using System.Diagnostics;
using Display;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;

namespace Life
{
    /// <summary>
    /// 
    /// </summary>
    class ArgHandleClass
    {
        //
        public static int height = 16;
        public static int width = 16;
        public static bool periodic = false;
        public static double probability = 0.5;
        public static int generations = 50;
        public static string fileName = "";
        public static int lineCount;
        public string seedPath;
        public static bool stepEnabled = false;
        public static double updateRate = 5;
        //public static int[,] cellArray;
        public string[] path;
        public static string[] errorMessages = new string[10];
        public static string[] successMessages = new string[10];
        public static int numberParamsMissing = 7; //decrement this every time a flag/correct param is found (remember number for any given option)
        //public string[] feilPath;
        public int[,] cells { get; set; }

        //message count variables use within methods throughout the class
        int errorMessageCount = 0;
        int successMessageCount = 0;

        //set these to false once they are interpreted at command line: assign missing commands to string array at handlArg function termination       
        public static bool seedDataMissing = true, inputFileMissing = true, randomFactorMissing = true, periodicMissing = true,
            rowsAndColumnsMissing = true, generationsMissing = true, maxUpRateMissing = true, stepModeMissing = true, dimensionsMissing = true;




        public ArgHandleClass(string[] feilPath)
        {
            path = feilPath;
        }
        public string[] Path
        {
            get { return path; }
            set { path = value; }
        }



        //public static int[,] ReturnCellArray()
        //{
        //    return cellArray;
        //}
        public static double GetProb()
        {
            return probability;
        }
        public static int GetHeight()
        {
            return height;
        }
        public static int GetWidth()
        {
            return width;
        }
        public static int GetGenerations()
        {
            return generations;
        }
        // K is used to control row increment in format seed method
        //public static void AssignStepMode()
        //{
        //    stepMode = true;
        //}
        public static string GetFileName()
        {
            if (seedDataMissing)
            {
                string seedMissingError = "No seed file provided, using default randomisation";
                return seedMissingError;
            }
            else
            {
                return fileName;
            }

        }
        //C:\Users\n9968075\Documents\Life\Life\CAB201_2020S2_ProjectPartA_nXXXXXXXX(6)\CAB201_2020S2_ProjectPartA_nXXXXXXXX\Life\Life\ArgHandleClass.cs
        public void ProcessArgs(string[] args)
        {
            //parse arguments
            int idx = 0;
            int posCounter = 0;



            while (idx < args.Length)
            {
                //used to find arguments after flags
                string valueIn = args[idx];
                //check step mode. if step mode is active. user will wait to push space bar before next generation is shown
                if (valueIn == "--step")
                {
                    stepEnabled = true;
                    //AssignStepMode();
                    stepModeMissing = false;
                }
                //check dimensions
                if (valueIn == "--dimensions")
                {
                    dimensionsMissing = false;
                    posCounter = idx + 1;
                    height = int.Parse(args[posCounter]);
                    posCounter++;
                    width = int.Parse(args[posCounter]);                                                               //IF PARSE STRING THEN DIMENSION MISSING?

                    //validation below
                    if (width <= 3 || height <= 3)
                    {
                        errorMessages[errorMessageCount] = "\tThe dimensions provided were not greater than or equal to 4";
                        errorMessageCount++;
                    }
                    else
                    {
                        successMessages[successMessageCount] = "\tWidth and height dimensions satisfy the lower bound";
                        successMessageCount++;
                    }
                    if (width >= 49 || height >= 49)
                    {
                        errorMessages[errorMessageCount] = "\t-The dimensions provided were not less than or equal to 49";
                        errorMessageCount++;
                    }
                    else
                    {
                        successMessages[successMessageCount] = "\tWidth and height dimensions satisfy the upper bound";
                        successMessageCount++;
                    }
                }
                if (valueIn == "--periodic")
                {
                    periodicMissing = false;
                    //posCounter++;
                    periodic = true;
                }

                if (valueIn == "--random")
                {
                    randomFactorMissing = false;
                    posCounter = idx + 1;
                    bool canParse = double.TryParse(args[posCounter], out double result);
                    if ((result <= 1) && (result >= 0))
                    {
                        //posCounter++;
                        probability = result;
                        successMessages[successMessageCount] = "\tThe random factor provided was a float between 0 and 1 (inclusive)";
                        successMessageCount++;
                    }
                    else
                    {
                        errorMessages[errorMessageCount] = "\tThe random factor provided was not a float between 0 and 1 (inclusive)";
                        errorMessageCount++;
                    }
                }

                if (valueIn == "--seed")
                {

                    posCounter = 0;
                    posCounter = idx + 1;
                    fileName += args[posCounter];
                    //args[posCounter];
                    //normally input filename into formatseed function but just hardcoded for now
                    seedPath = fileName;
                    //GO TO value in seed.
                    //posCounter++;
                    if (File.Exists(fileName))
                    {
                        seedDataMissing = false;
                        //check if has a .seed extension. 
                    }
                    else
                    {
                        seedDataMissing = true;

                    }
                }

                if (valueIn == "--generations")
                {
                    generationsMissing = false;
                    posCounter = idx + 1;

                    bool canParse = int.TryParse(args[posCounter], out int result);
                    if (canParse)
                    {
                        if (result > 0)
                        {
                            generations = result;
                            successMessages[successMessageCount] = "\tThe generations provided was a positive non-zero integer";
                            successMessageCount++;
                        }
                        else
                        {
                            errorMessages[errorMessageCount] = "\tThe generation number provided was not a positive non-zero integer";
                            errorMessageCount++;
                        }
                    }
                    else
                    {
                        errorMessages[errorMessageCount] = "\tThe generation number provided was not an integer";
                        errorMessageCount++;
                    }
                }

                if (valueIn == "--max-update")
                {
                    maxUpRateMissing = false;
                    posCounter = idx + 1;
                    bool canParse = double.TryParse(args[posCounter], out double result);
                    if (canParse)
                    {
                        if ((result >= 0) && (result <= 30))
                        {
                            updateRate = result;
                            successMessages[successMessageCount] = "\tThe maximum update rate provided was a float between 0 and 30 (inclusive)";
                            successMessageCount++;
                        }
                        else
                        {
                            errorMessages[errorMessageCount] = "\tThe maximum update rate provided was not a float between 0 and 30 (inclusive)";
                            errorMessageCount++;
                        }
                    }
                }
                idx++;
            }
            //save seed as int array eg int[,]
            /*                     
             */
        }
        public int[,] FormatSeed(string path)
        {
            int rowHolder = 0;
            int j = 0;
            TextReader readFile = new StreamReader(fileName);
            readFile.ReadLine();//This code to remove first version line of the seed file. so that only data remains

            //FIX LKINE INDENT HERE
            //count the lines in the file (hard coded but normally passed), then construct array of that size eg file lines - first line
            lineCount = File.ReadAllLines(fileName).Length; //change: was originally declared here
            int[,] arr = new int[lineCount - 1, 2];            // -1 to take out first line 
            string lines = readFile.ReadToEnd();
            int[] seedAsSingleArray = new int[lineCount * 2 -2]; //multiplied by two to allow both col1 and col2 rows to be stored

            string newLines = lines.Replace("\n", "").Replace("\r", " ");

            string currentChar = "";

            foreach (char item in newLines)
            {                
                if (item != ' ')
                {
                    currentChar += item;
                }
                else
                {
                    seedAsSingleArray[j] = int.Parse(currentChar);
                    currentChar = "";
                    j++;
                }
            }


            bool isCol1 = true;
            foreach (int item in seedAsSingleArray)
            {                
                if (isCol1 == true)
                {
                    arr[rowHolder, 0] = item;
                    isCol1 = false;                    
                }
                else if (isCol1 != true)
                {
                    arr[rowHolder, 1] = item;
                    isCol1 = true;
                    rowHolder++;
                }
            }
            readFile.Close();
            readFile = null;
            CheckSeedInDimensions(arr, height, width);
            return arr;
        }

        private void CheckSeedInDimensions(int[,] arr, int height, int width)
        {
            int arrayRowMax = 0;
            int arrayColMax = 0;
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                if (arr[i,0] > arrayRowMax)
                {
                    arrayRowMax = arr[i, 0];
                }
                if (arr[i,1] > arrayColMax)
                {
                    arrayColMax = arr[i, 1];
                }
            }
            //after finding max value check if in bounds of specified dimensions
            if (arrayRowMax >= height)
            {
                arrayRowMax++;
                errorMessages[errorMessageCount] = "\tThere are alive cells that exist outside the bounds of the universe, please increase row size to "+ arrayRowMax;
                errorMessageCount++;
            }
            if (arrayColMax >= width)
            {
                arrayColMax++;
                errorMessages[errorMessageCount] = "\tThere are alive cells that exist outside the bounds of the universe, please increase column size to "+ arrayColMax;
                errorMessageCount++;
            }
        }
    }
}
