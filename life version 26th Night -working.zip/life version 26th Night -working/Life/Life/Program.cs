﻿using System;
using System.Diagnostics;
using Display;
using System.IO;

namespace Life
{
//

    class Program
    {
        public static bool stepMode = false;
        public static bool periodic = false;
        public static double probability = 0.5;
        public static int generations = 50;
        string DELIM = "";

        //This methods receives the seed file from cmd args and formats it into an array the program can use later
        public static void FormatSeed(string path)
        {
            //thiss array control the starting state of program
            int[,] seedArray = new int[,] { };
            //int j = 0; //counting variable 
            //string[] lines = File.ReadAllLines(path);//read all lines in seed ready to transfer to an array so program can use later on
            //int rowVal, colVal;
            TextReader readFile = new StreamReader(path);
            readFile.ReadLine();//This code to remove first version line of the seed file. so that only data remains
            int ii= 0; // These contorl where values are placed in array
            int jj = 0;

            //the below while statement is me attempting to create an array from the seed file to use later as input for the program. 
            while (true)
            {
                string line = readFile.ReadLine();
                if (line != null)
                {
                    //remove space from words
                    line = line.Replace(" ", "");
                    int lineAsInt = int.Parse(line);
                    int a = lineAsInt / 10;
                    int b = lineAsInt % 10;
                    int[,] rowToAdd = new int[a, b];
                    seedArray[ii, jj] = seedArray[a, b];

                    ii++;
                    jj++; 

                    //Console.WriteLine($"{0}, {1}", a , b);

                    //add to array index
                    //read next line                   
                    //seedArray[,] = int.TryParse(line.Split(""));
                }
                else
                {
                    break;
                }
            }
            readFile.Close();
            readFile = null;

            //foreach (var item in lines)
            //{
            //    Console.WriteLine(item);
            //}
        }
        //method to assign step mode
        public static void AssignStepMode()
        {
            stepMode = true;
        }


        public static void ProcessArgs(string[] args)
        {

            //parse arguments
            int idx = 0;
            int posCounter = 0;
            int generations = 50;
            float updateRate = 5;
            while (idx<args.Length)
            {
                //used to find arguments after flags
                string valueIn = args[idx];               
                //check step mode. if step mode is active. user will wait to push space bar before next generation is shown
                if (valueIn == "--step")
                {                  
                    AssignStepMode();
                }
                //check dimensions
                if (valueIn == "--dimensions")
                {
                    posCounter = idx + 1;                   
                    int r = int.Parse(args[posCounter]);
                    posCounter++;
                    int w = int.Parse(args[posCounter]);
                    posCounter = 0; //reset counter to not mess with other if statement value retention
                }
                if (valueIn == "--periodic")
                {
                    //posCounter++;
                    periodic = true;
                }

                if (valueIn == "--random")
                {
                    posCounter = idx + 1 ;
                    bool canParse = double.TryParse(args[posCounter], out double result);
                    if ((result <= 1) && (result >= 0))
                    {
                        //posCounter++;
                        probability = result;
                    }                   
                }

                if (valueIn == "--seed")
                {
                    Console.WriteLine("into method");
                    posCounter = 0;
                    posCounter = idx + 1;
                    string fileName = args[posCounter];
                    //normally input filename into formatseed function but just hardcoded for now
                    FormatSeed(@"C:\\Users\n9968075\\Desktop\\2020 QUT\\sem 2\\CAB201\\Life\\CAB201_2020S2_ProjectPartA_nXXXXXXXX(6)\\Seeds\figure-eight_14x14.seed");
                    //posCounter++;
                }

                if (valueIn == "--generations")
                {
                    posCounter = idx + 1;
                    bool canParse = int.TryParse(args[posCounter], out int result);
                    if (canParse)
                    {
                        if (result > 0)
                        {
                            generations = result;
                        }
                    }
                }

                if (valueIn == "--max-update")
                {
                    posCounter = idx + 1;
                    bool canParse = float.TryParse(args[posCounter], out float result);
                    if (canParse)
                    {
                        if ((result >= 0)  && (result <= 30))
                        {
                            updateRate = result;
                        }
                    }
                }
                idx++;
            }

            //save seed as int array eg int[,]
            /*
             
             
             */
        }


        static void Main(string[] args)
        {

            Program.ProcessArgs(args);
            // The following is just an example of how to use the Display.Grid class
            // Think of it as a "Hello World" program for using this small API
            // If it works correctly, it should display a little smiley face cell
            // by cell. The program will end after you press any key.

            // Feel free to remove or modify it when you are comfortable with it.

            // Specify grid dimensions and active cells...

            int rows = 7, columns = 9;
            //method instead: getSeedData
            int[,] cells = {
                { 5, 3 },
                { 4, 3 },
                { 5, 5 },
                { 4, 5 },
                { 2, 1 },
                { 1, 2 },
                { 1, 3 },
                { 1, 4 },
                { 1, 5 },
                { 1, 6 },
                { 2, 7 }
            };

            // Construct grid...
            Grid grid = new Grid(rows, columns);

            // Wait for user to press a key...
            Console.WriteLine("Press any key to start...");
            Console.ReadKey();

            // Initialize the grid window (this will resize the window and buffer)
            grid.InitializeWindow();

            // Set the footnote (appears in the bottom left of the screen).
            grid.SetFootnote("Smiley");

            Stopwatch watch = new Stopwatch();

            // For each of the cells...
            for (int i = 0; i < cells.GetLength(0); i++)
            {
                watch.Restart();
                
                // Update grid with a new cell... USE VARIABLES FROM SEED FILE HERE
                grid.UpdateCell(cells[i, 0], cells[i, 1], CellState.Full);

                // Render updates to the console window...this is the whehere the cells are updated
                grid.Render();
                
                while (watch.ElapsedMilliseconds < 200) ;
            }

            // Set complete marker as true
            grid.IsComplete = true;

            // Render updates to the console window (grid should now display COMPLETE)...
            grid.Render();

            // Wait for user to press a key...
            Console.ReadKey();

            // Revert grid window size and buffer to normal
            grid.RevertWindow();
        }
    }
}
