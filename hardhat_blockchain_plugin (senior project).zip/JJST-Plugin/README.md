

# JJST - LABRYS HARDHAT PLUGIN

This project was developed for easing the process of development of smart contracts using hardhat. Existing functions in the Hardhat environment are encapsulated within new functions. These functions to have simpler inputs as their parameters.

The plugin can be installed with a simple npm command. Copy and paste the following command to install:


## Installation

    npm i jjst-hardhat-plugin


## REPOSITORY TREE 

<img src= "./RepositoryTree.jpg">


## FUNCTIONS


| SetNonce              | nonce, account                      | hardhat_setNonce                                 |
|-----------------------|-------------------------------------|--------------------------------------------------|
| setNextBlockTimestamp | date, time                          | evm_setNextBlockTimestamp                        |
| HardhatMine           | numberOfBlocks, interval            | hardhat_mine                                     |
| IncreaseTime          | days,hours,minutes,seconds          | evm_increaseTime                                 |
| ImpersonateAccount    | hexAccAddress                       | hardhat_impersonateAccount                       |
| SetAccBalance         | hexAccAddress , amount              | hardhat_setBalance                               |
| SendTransaction       | to_address,from_address, type,debug | hardhat_impersonateAccount & hardhat_setBalance  |
| MineTo                | date , interval                     | hardhat_mine                                     |
| SetCoinBase           | hexAccAddress                       | hardhat_setCoinbase                              |
| SetMinGasPrice        | gasPrice                            | hardhat_setNextBlockBaseFeePerGas                |
| SetGasLimit           | gasLimit                            | evm_setBlockGasLimit                             |
| Automine              | Func(set/get),state                 | hardhat_getAutomine , hardhat_setAutomine        |
| evmMine               | date, time                          | evm_mine                                         |
| IntervalMining        | Interval                            | hardhat_setIntervalMining                        |


### 

## CREDITS


*Tom Rowen                   https://github.com/trowe36*

*Jacob Pitt                  https://github.com/jpitt46*

*Saloni Bhatia              https://github.com/saloni-bhatia*

*James Kilmartin            https://github.com/JamesKilmartin*

*LABRYS                     https://labrys.io/*
