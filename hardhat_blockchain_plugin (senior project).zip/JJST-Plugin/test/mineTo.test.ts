import { BigNumber } from "ethers";
const { expect, assert } = require("chai");
//const {describe,beforeEach,afterEach,it} = require("mocha");
import { testDateString } from "../src/util";

describe("MineTo function test", function () {
    let startBlockNum: number;
    let newBlockNum: number;
    let testDate = new Date();
    // Move current date five days ahead
    testDate.setDate(testDate.getDate()+5);

    beforeEach(async function () {
        await hre.network.provider.send("hardhat_reset");
        // Display information about the current block on the blockchain
        startBlockNum = await hre.network.provider.send("eth_blockNumber");
    });

    // Test incorrect date format (not ISO yyyy-mm-dd)
    describe("Bad Date Format", function () {
        it("Should fail as the date format is not ISO standard yyyy-mm-dd", async function () {
            await hre.newplugin.MineTo("01/01/2022");
            newBlockNum = await hre.network.provider.send("eth_blockNumber");
            await expect(newBlockNum).to.equal(startBlockNum);
        });
    });

    // Test date is in the past not in the future
    describe("Not Future Date", function () {
        it("Should fail as the date is in the past", async function () {
            await hre.newplugin.MineTo("2022-01-01");
            newBlockNum = await hre.network.provider.send("eth_blockNumber");
            await expect(newBlockNum).to.equal(startBlockNum);
        });
    });

    // Test negative integer mining interval
    describe("Non-integer mining interval", function () {
        it("Should fail as the mining interval is not a positive integer", async function () {
            const intervalValue = -100;
            // Set the mining date to 5 days in the future
            const miningDate = testDateString(testDate);
            await hre.newplugin.MineTo(miningDate, intervalValue);
            newBlockNum = await hre.network.provider.send("eth_blockNumber");
            await expect(newBlockNum).to.equal(startBlockNum);
        });
    });

    // Test mining interval is a string not an integer
    describe("String mining interval", function () {
        it("Should fail as the mining interval is a string", async function () {
            const intervalValue = "100";
            // Set the mining date to 5 days in the future
            const miningDate = testDateString(testDate);
            
            await hre.newplugin.MineTo(miningDate, intervalValue);
            newBlockNum = await hre.network.provider.send("eth_blockNumber");
            expect(newBlockNum).to.equal(startBlockNum);
        });
    });

    // Test correct date with default mining interval
    describe("Mine blocks with the default interval", function () {
        it("Should mine blocks with the default interval", async function () {
            // Set the mining date to 5 days in the future
            const miningDate = testDateString(testDate);
            await hre.newplugin.MineTo(miningDate);
            newBlockNum = await hre.network.provider.send("eth_blockNumber");
            expect(newBlockNum).to.not.equal(startBlockNum);
        });
    });

    // Test correct date with 2400 sec mining interval
    describe("Mine blocks with set interval", function () {
        it("Should mine blocks with 2400 sec interval", async function () {
            // Set the mining date to 5 days in the future
            const miningDate = testDateString(testDate);
            await hre.newplugin.MineTo(miningDate, 2400);
            newBlockNum = await hre.network.provider.send("eth_blockNumber");
            expect(newBlockNum).to.not.equal(startBlockNum);
        });
    });
});



