import { BigNumber } from "ethers";
import { assert, expect } from "chai";


describe("SetMinGasPrice function tests", function () {
    let initialGas:any;
    let newGas:any;

    this.beforeAll(async function () {
        const currentBlock = await hre.network.provider.send("eth_getBlockByNumber", ['latest', true]);
        initialGas = currentBlock.baseFeePerGas;
    });

    // Set base fee per gas to 100 Gwei
    it("Should set base fee per gas to 100 Gwei", async function () {
        const NEW_GAS_PRICE = 100;
        await hre.newplugin.SetMinGasPrice(NEW_GAS_PRICE);
        await hre.network.provider.send("evm_mine");
        const currentBlock = await hre.network.provider.send("eth_getBlockByNumber", ['latest', true]);
        newGas = parseInt(currentBlock.baseFeePerGas);
        assert.equal(NEW_GAS_PRICE, (newGas/1e9));
        expect(NEW_GAS_PRICE).not.equal(initialGas/1e9);
    });

    // Try to set base fee per gas to zero Gwei
    it("Should fail to set to zero", async function () {
        try {
            const NEW_GAS_PRICE = 0;
            await hre.newplugin.SetMinGasPrice(NEW_GAS_PRICE);
        } catch(error) {
            expect(error).to.be.equal('Gas price must be a value greater than zero');
        }
    });

    // Try to set base fee per gas to -10 Gwei
    it("Should fail to set to zero", async function () {
        try {
            const NEW_GAS_PRICE = -10;
            await hre.newplugin.SetMinGasPrice(NEW_GAS_PRICE);
        } catch(error) {
            expect(error).to.be.equal('Gas price must be a value greater than zero');
        }
    });

    // Try to set base fee per gas to a string value
    it("Should fail to set with a string value", async function () {
        try {
            const NEW_GAS_PRICE = '50,000';
            await hre.newplugin.SetMinGasPrice(NEW_GAS_PRICE);
        } catch(error) {
            expect(error).to.be.equal('Gas price must be a numerical value');
        }
    });

});

describe("SetGasLimit function tests", function () {
    let initialLimit: any;
    let newLimit: any;

    this.beforeAll(async function () {
        const currentBlock = await hre.network.provider.send("eth_getBlockByNumber", ['latest', true]);
        initialLimit = currentBlock.gasLimit;
    });

    // Set Gas Limit to 1 million Gwei
    it("Should set the gas limit to 1 million Gwei", async function () {
        const NEW_GAS_LIMIT = 1e6;
        await hre.newplugin.SetGasLimit(NEW_GAS_LIMIT);
        await hre.network.provider.send("evm_mine");
        const currentBlock = await hre.network.provider.send("eth_getBlockByNumber", ['latest', true]);
        newLimit = currentBlock.gasLimit;
        assert.equal(NEW_GAS_LIMIT, (newLimit/1e9));
        expect(NEW_GAS_LIMIT).to.not.equal(initialLimit/1e9);
    });

    // Set Gas Limit to 0 Gwei
    it("Should fail to set gas limit to zero", async function () {
        try {
            const NEW_GAS_LIMIT = 0;
            await hre.newplugin.SetGasLimit(NEW_GAS_LIMIT);
        } catch (error) {
            expect(error).to.be.equal('Gas limit must be a value greater than zero');
        }
    });

    // Set Gas Limit to -20 Gwei
    it("Should fail to set gas limit to zero", async function () {
        try {
            const NEW_GAS_LIMIT = -20;
            await hre.newplugin.SetGasLimit(NEW_GAS_LIMIT);
        } catch (error) {
            expect(error).to.be.equal('Gas limit must be a value greater than zero');
        }
    });

    // Set Gas Limit to a string value
    it("Should fail to set gas limit with a string value", async function () {
        try {
            const NEW_GAS_LIMIT = '50,000';
            await hre.newplugin.SetGasLimit(NEW_GAS_LIMIT);
        } catch (error) {
            expect(error).to.be.equal('Gas limit must be a numerical value');
        }
    });

    // Set Gas Limit to 40 million Gwei, above current limit on mainnet
    it("Should set the gas limit to 40 million Gwei", async function () {
        const NEW_GAS_LIMIT = 40e6;
        await hre.newplugin.SetGasLimit(NEW_GAS_LIMIT);
        await hre.network.provider.send("evm_mine");
        const currentBlock = await hre.network.provider.send("eth_getBlockByNumber", ['latest', true]);
        newLimit = currentBlock.gasLimit;
        assert.equal(NEW_GAS_LIMIT, (newLimit/1e9));
        expect(NEW_GAS_LIMIT).to.not.equal(initialLimit/1e9);
    });
});