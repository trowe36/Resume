import { expect, assert } from "chai";
import { describe, beforeEach, it } from "mocha";
import hre from "hardhat";
import { time, takeSnapshot, SnapshotRestorer } from "@nomicfoundation/hardhat-network-helpers";
import { Contract } from "ethers";
import { NumberLike } from "@nomicfoundation/hardhat-network-helpers/dist/src/types";
import { IncreaseTimeParams, TimeStampValues } from "../src/Types/types";

describe("Lock part 2 BlockTimestamp", async function () {
  let Lock;
  let lock: Contract;
  let unlockTime: number;
  let lockedAmount = 1_000_000_000;
  let currentDate: Date;
  let testDate: Date;
  beforeEach(async function () {
    await hre.network.provider.send("hardhat_reset");
    currentDate = new Date();
    testDate = new Date();
    testDate.setFullYear(testDate.getFullYear() + 1);
    unlockTime = testDate.getTime();
    // deploy a lock contract where funds can be withdrawn
    // one year in the future
    Lock = await hre.ethers.getContractFactory("Lock");
    lock = await Lock.deploy(unlockTime, { value: lockedAmount });
  });

  it("Should set the right unlockTime", async function () {
    // assert that the value is correct
    expect(await lock.unlockTime()).to.equal(unlockTime);
  });

  it("Should not unlock contract after setNextBlockTimestamp", async function () {
    // ...deploy the contract...
     // Set mining date to one year in the future minus 1 day
    let inputString: string = `${currentDate.getFullYear() + 1}-${currentDate.getMonth() + 1}-${currentDate.getDate() - 1}`;
    const config: TimeStampValues = {
      date: inputString,
      time: '12:00:00'
    }
    await hre.newplugin.setNextBlockTimestamp(config);
    await hre.network.provider.send("evm_mine");
    await expect(lock.withdraw()).to.be.revertedWith("You can't withdraw yet");
  });

  it("Should revert with the right error if called from another account", async function () {
    // ...deploy the contract...
    const [owner, otherAccount] = await ethers.getSigners();
    // we increase the time of the chain to pass the first check
    await time.increaseTo(unlockTime);
    // We use lock.connect() to send a transaction from another account
    await expect(lock.connect(otherAccount).withdraw()).to.be.revertedWith(
      "You aren't the owner"
    );
  });

  it("Should unlock contract after setNextBlockTimestamp", async function () {
    // ...deploy the contract...
    // Set mining date to one year in the future plus 1 day
    let inputString: string = `${currentDate.getFullYear() + 1}-${currentDate.getMonth() + 1}-${currentDate.getDate() + 1}`;
    const config: TimeStampValues = {
      date: inputString,
      time: '12:00:00'
    }
    await hre.newplugin.setNextBlockTimestamp(config);
    await hre.network.provider.send("evm_mine");
    const currentBlock = await hre.network.provider.send("eth_getBlockByNumber", ['latest', true]);
    // expect the timestamp on the current block to be greater than the unlock time
    expect(parseInt(await lock.unlockTime())).to.be.lessThan(parseInt(currentBlock.timestamp));
    await lock.withdraw();
  });

});
