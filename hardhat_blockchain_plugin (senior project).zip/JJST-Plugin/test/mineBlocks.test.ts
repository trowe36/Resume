
import { BigNumber } from "ethers";
import { HardHatMineParams } from "../src/Types/types";
const { expect, assert } = require("chai");
//const {describe,beforeEach,afterEach,it} = require("mocha");

describe("HardhatMine function test", function () {
    let startBlockNum: number;
    let newBlockNum: number;

    beforeEach(async function () {
        await hre.network.provider.send("hardhat_reset");
        // Display information about the current block on the blockchain
        startBlockNum = await hre.network.provider.send("eth_blockNumber");
    });

    // Test sucessful mining of 10 blocks
    describe("Mine 10 blocks successfully", function () {
        it("Should successfully mine 10 blocks", async function () {
            const txConfig: HardHatMineParams = { numberOfBlocks: 10, interval: 600};
            await hre.newplugin.HardhatMine(txConfig);
            newBlockNum = await hre.network.provider.send("eth_blockNumber");
            const numBlocks = newBlockNum - startBlockNum;
            expect(numBlocks).to.equal(10); 
        });
    });

    // Test unseccessful mining due to negative block number input
    describe("Negative block number input", function () {
        it("Should fail to mine blocks due to negative block number", async function () {
            const txConfig: HardHatMineParams = { numberOfBlocks: -10, interval: 600};
            await hre.newplugin.HardhatMine(txConfig);
            newBlockNum = await hre.network.provider.send("eth_blockNumber");
            await expect(newBlockNum).to.equal(startBlockNum);
        });
    });

    // Test unsuccessful mining due to negative interval input
    describe("Negative interval input", function () {
        it("Should fail to mine blocks due to negative interval", async function () {
            const txConfig: HardHatMineParams = { numberOfBlocks: 10, interval: -600};
            await hre.newplugin.HardhatMine(txConfig);
            newBlockNum = await hre.network.provider.send("eth_blockNumber");
            await expect(newBlockNum).to.equal(startBlockNum);
        });
    });
}) ;