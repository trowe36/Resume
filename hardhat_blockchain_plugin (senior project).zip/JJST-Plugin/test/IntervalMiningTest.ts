import {Interval_Mining}  from "../src/Types/types";
const {expect,assert} = require("chai");
import {AutomineParams}  from "../src/Types/types";

describe(" Interval Mining tests ",function()
{
    let current : any; 
    let func_current : any;
    
    describe("test 1 - get current state - no params for state ", function()
    {
    it("The new plugin function should display the same result as before ", async function (){
        const test1 : Interval_Mining = {interval: 5000};

        await hre.newplugin.Interval_Mining(test1);
        const test2 : AutomineParams = {func: "get"};
        func_current = await hre.newplugin.Automine(test2);
        expect(func_current).to.equal(false); 

    });
 });
});
 