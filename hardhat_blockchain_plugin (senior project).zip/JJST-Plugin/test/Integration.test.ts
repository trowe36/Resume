const { expect, assert } = require("chai");
import { AccParams,SendTransParams, HardHatMineParams } from "../src/Types/types";

describe("Integration testing", function () {
    let accounts:any;
    let alice:any;
    let bill:any;
    let chris:any;
    let BASE_GAS_PRICE = 100;
    const GAS_LIMIT = 21000;
    const ACCOUNT_BALANCE = 10000; //All accounts set to this amount

    this.beforeAll(async function () {
        await hre.network.provider.send("hardhat_reset");
        const accounts = await hre.ethers.getSigners();
        alice = accounts[3];
        bill = accounts[2];
        chris = accounts[1]
    });
    describe("Setting coinbase, gas prices, and mining blocks", function () {
        it("Set coin base, gas price, send transaction and a mine blocks", async function () {
            const alice_address = alice.address;
            const bill_address = bill.address;
            const chris_address = chris.address;
            const aliceParams = { hexAccAddress: alice_address };
            const billParams = { hexAccAddress: bill_address};
            const chrisParams = { hexAccAddress: chris_address};
            await hre.newplugin.SetCoinBase(aliceParams);
            await hre.newplugin.SetMinGasPrice(BASE_GAS_PRICE);
            await hre.newplugin.SetGasLimit(GAS_LIMIT);
            const txTransConfig: SendTransParams = {
                from: bill_address,
                to: chris_address,
                amount: 100,
                type: "eth",
                debug: false,
            };
            await hre.newplugin.SendTransaction(txTransConfig);
            await hre.network.provider.send("evm_mine");

            // Alice's balance will increase by the mining reward plus gas tip
            const gasTip = (1 * GAS_LIMIT)/1e9;
            const reward = 2;
            const transFee = ((BASE_GAS_PRICE + 1) * GAS_LIMIT)/1e9;
            let alice_balance = hre.ethers.utils.formatEther(await alice.getBalance());
            expect(alice_balance).to.equal((ACCOUNT_BALANCE + (2*reward) + gasTip).toFixed(6));

            // Chris's balance should increase by the transaction amount
            let chris_balance = hre.ethers.utils.formatEther(await chris.getBalance());
            expect(chris_balance).to.equal((ACCOUNT_BALANCE + txTransConfig.amount).toFixed(1));

            // Bill's balance should decrease by the transaction amount plus the transaction fee
            let bill_balance = hre.ethers.utils.formatEther(await bill.getBalance());
            expect(bill_balance).to.equal((ACCOUNT_BALANCE - txTransConfig.amount - transFee).toFixed(6)); 

            // Use new coinbase and double the base gas price
            await hre.newplugin.SetCoinBase(chrisParams);
            BASE_GAS_PRICE = 200;
            const transFee2 = ((BASE_GAS_PRICE + 1) * GAS_LIMIT)/1e9;
            await hre.newplugin.SetMinGasPrice(BASE_GAS_PRICE);
            const txTrans2Config: SendTransParams = {
                from: alice_address,
                to: bill_address,
                amount: 50,
                type: "eth",
                debug: false,
            };
            await hre.newplugin.SendTransaction(txTrans2Config);
            const txConfig: HardHatMineParams = { numberOfBlocks: 20, interval: 600};
            await hre.newplugin.HardhatMine(txConfig);

            alice_balance = hre.ethers.utils.formatEther(await alice.getBalance())
            expect(alice_balance).to.equal((ACCOUNT_BALANCE + (2*reward) + gasTip - txTrans2Config.amount - transFee2).toFixed(4));
            bill_balance = hre.ethers.utils.formatEther(await bill.getBalance());
        
            expect(bill_balance).to.equal((ACCOUNT_BALANCE - txTransConfig.amount - transFee + txTrans2Config.amount).toFixed(6));
            chris_balance = hre.ethers.utils.formatEther(await chris.getBalance());
            
            expect(chris_balance).to.equal((ACCOUNT_BALANCE + txTransConfig.amount + gasTip + (4*reward)).toFixed(6));
        });
    });
});