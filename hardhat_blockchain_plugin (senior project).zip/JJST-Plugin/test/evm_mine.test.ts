import { error } from "console";
import { IncreaseTimeParams } from "../src/Types/types";
const {expect,assert} = require("chai");
const {describe,beforeEach,it} = require("mocha");

describe( "EvmMine tests", function()
{
    let blockNumBefore : any; 
    let blockBefore : any; 
    let timestampBefore: any; 
    const valid_date = "2023-08-06"; // 08 - taken as september
    const valid_time = "10:30:30";
    const invalid_date = "20-08-6";
    const invalid_time = "a:80:30";
    const past_date = "2020-08-06";

    beforeEach(async function  () {
        await hre.network.provider.send("hardhat_reset");
        blockNumBefore = await hre.ethers.provider.getBlockNumber();
        blockBefore = await hre.ethers.provider.getBlock(blockNumBefore);
        timestampBefore = blockBefore.timestamp;
        
    });
    describe("Test 1 - Invalid date-time", function () 
    {
        it("The new plugin function should throw an error for invalid date",async function ()
        {
            try
            {
               await  hre.newplugin.evmMine({date:invalid_date,time:valid_time});
            }
            catch (error)
            {
                expect(error).to.be.equal("Invalid date/time format, only yyyy-mm-dd , h:m:s format is excepted.");

            }
        });
        it("The new plugin function should throw an error for invalid time",async function ()
        {
            try
            {
               await  hre.newplugin.evmMine({date:valid_date,time:invalid_time});
            }
            catch (error)
            {
                expect(error).to.be.equal("Invalid date/time format, only yyyy-mm-dd , h:m:s format is excepted.");

            }
        });
        // it("The new plugin function should throw an error for past date",async function ()
        // {
        //      try
        //     {
        //        await  hre.newplugin.evmMine({date:past_date,time:valid_time});
        //     }
        //      catch (error)
        //     {
             
        //         expect(error).to.be.equal("Timestamp 1599352230 is lower than or equal to previous block's timestamp 1662430962");

        //      }
        // }); Issue raised in SetNextBlock 
        it("The new plugin function increases the time and mines another box. ",async function ()
        {
            
               await  hre.newplugin.evmMine({date:valid_date,time:valid_time});
               const blockNumAfter = await hre.ethers.provider.getBlockNumber();
               const blockAfter = await hre.ethers.provider.getBlock(blockNumAfter);
               const timestampAfter = blockAfter.timestamp;
               expect(await hre.ethers.provider.getBlockNumber()).to.equal(1);
               expect(timestampAfter).to.equal(1691281830000); // The time is as per SetNextBlock code - has the same issues


            
        });
    });
});
