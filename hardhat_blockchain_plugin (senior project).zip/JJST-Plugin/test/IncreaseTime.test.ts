import { IncreaseTimeParams } from "../src/Types/types";
const {expect,assert} = require("chai");
const {describe,beforeEach,it} = require("mocha");

describe("Increase Time function test",function(){
    let timestampBefore: any;
    let blockNumBefore : any;
    let blockBefore : any;
    let blockNumAfter : any;
    let blockAfter : any;
    let timestampAfter : any;
  

    beforeEach (async function(){
       
        blockNumBefore = await hre.ethers.provider.getBlockNumber();
        blockBefore = await hre.ethers.provider.getBlock(blockNumBefore);
        timestampBefore = blockBefore.timestamp;
      
    });
 
    describe("Test the function with valid dates " , function() 
    {
        let prms: IncreaseTimeParams = { days: 1, hours: 2, minutes: 3, seconds: 4};
        it ( "The time stamp should be increased equal to 93785" ,async function () {
            await hre.newplugin.IncreaseTime(prms);
            
             blockNumAfter = await hre.ethers.provider.getBlockNumber();
             blockAfter = await hre.ethers.provider.getBlock(blockNumAfter);
             timestampAfter = blockAfter.timestamp;
            expect(timestampAfter - timestampBefore).to.equal(93785);
        });   
    });
      
});
        



   
