import { BigNumber, Signer } from "ethers";
import { AccParams } from "../src/Types/types";
const hre = require("hardhat");
const ethers = hre.ethers;
const { expect, assert } = require("chai");
//const {describe,beforeEach,it,beforeAll} = require("mocha");

describe("ImpersonateAccount function test", function () {
    let bill: any;
    let alice: any;

    this.beforeAll(async function () {
        [bill, alice] = await hre.ethers.getSigners();
    })

    // Impersonate account successfully
    it("Should successfully impersonate an account", async function () {
        // Set params for HardHat function
        const alice_address = alice.address;
        const aliceParams = { hexAccAddress: alice_address };
        await hre.newplugin.ImpersonateAccount(aliceParams);
        //assign the account as signer under the ethers extension
        const signer = await hre.ethers.getSigner(aliceParams.hexAccAddress);
        assert.equal(signer.address, alice_address);
        
    });

    it("Should sign a message", async function () {
        const alice_address = alice.address;
        const aliceParams = { hexAccAddress: alice_address };
        const signer = await hre.ethers.getSigner(aliceParams.hexAccAddress);
        const result = await signer.signMessage("hello");
        assert.equal(
        result,
        "0x76930d64d2e5eb4b3f4572ce806eda50e1e2329d51d9ca5a713a9befcb9d20883e3d4885c3c5eaf775fc8c9fcf4882a28b582b427bc0270565f3294d935549221b"
        );;
    });
});