import { AnyCnameRecord } from "dns";
import { BigNumber } from "ethers";
import { AccParams, SendTransParams } from "../src/Types/types";
const { expect, assert } = require("chai");
const hre = require("hardhat");
//const {describe,beforeEach,it} = require("mocha");

const EXPECTED_WEI_BALANCE = "100.0000000000000001"; //TODO could change this to bigNumber - Justin. check ether docs. 

async function InitializeBalances(
  billAddr: string,
  jennyAddr: string,
  aliceAddr: string
) {
  const configBill: AccParams = {
    hexAccAddress: billAddr,
    amount: 100,
    type: "ether",
  };
  const configJenny: AccParams = {
    hexAccAddress: jennyAddr,
    amount: 100,
    type: "ether",
  };
  const configAlice: AccParams = {
    hexAccAddress: aliceAddr,
    amount: 100,
    type: "ether",
  };

  await hre.newplugin.SetAccBalance(configBill);
  await hre.newplugin.SetAccBalance(configJenny);
  await hre.newplugin.SetAccBalance(configAlice);
}

describe("SendTransaction function test", function () {
  //let accounts: any;
  let billAddr: any;
  let jennyAddr: any;
  let aliceAddr: any;

  let bill: any, jenny: any, alice: any;

  beforeEach(async function () {
    const accounts = await hre.ethers.getSigners();
    (bill = accounts[0]), (jenny = accounts[1]), (alice = accounts[2]);
    (billAddr = bill.address),
      (jennyAddr = jenny.address),
      (aliceAddr = alice.address);
    await InitializeBalances(billAddr, jennyAddr, aliceAddr);
  });

  // Test successful account balance change of 1000 ETH
  describe("SendTransactions Main Test", function () {
    it("Send 1 eth from bill to alice", async function () {
      const txConfig: SendTransParams = {
        from: billAddr,
        to: aliceAddr,
        amount: 1,
        type: "eth",
        debug: false,
      };
      await hre.newplugin.SendTransaction(txConfig);
      expect(hre.ethers.utils.formatEther(await alice.getBalance())).to.equal(
        "101.0"
      );
    });

    it("Send 1 eth from jenny to alice", async function () {
      const txConfig: SendTransParams = {
        from: jennyAddr,
        to: aliceAddr,
        amount: 1,
        type: "eth",
        debug: false,
      };
      await hre.newplugin.SendTransaction(txConfig);
      expect(hre.ethers.utils.formatEther(await alice.getBalance())).to.equal(
        "101.0"
      );
      console.log(
        "has gas fee?  " +
          hre.ethers.utils.formatEther(await jenny.getBalance())
      );
    });
  });

  describe("Resetting balances to 100 eth..... Now testing wei SendTransaction", async function () {
    it("send 100 wei from bill to alice", async function () {
      const txConfig: SendTransParams = {
        from: billAddr,
        to: aliceAddr,
        amount: 100,
        type: "wei",
        debug: false,
      };
      
      await hre.newplugin.SendTransaction(txConfig);
      let finalBal = hre.ethers.utils
        .formatEther(await alice.getBalance())
        .toString();
      expect(finalBal).to.equal(EXPECTED_WEI_BALANCE);
    });

    it("send 100 wei from jenny to alice", async function () {
      const txConfig: SendTransParams = {
        from: jennyAddr,
        to: aliceAddr,
        amount: 100,
        type: "wei",
        debug: false,
      };
      await hre.newplugin.SendTransaction(txConfig);
      let finalBal = hre.ethers.utils
        .formatEther(await alice.getBalance())
        .toString();
      expect(finalBal).to.equal(EXPECTED_WEI_BALANCE);
    });
  });
});
