const { expect, assert } = require("chai");
import { setNextBlockTimestamp } from "../src/Types/types";
import { testDateString, DateTimeBuilder } from "../src/util";
import { TimeStampValues } from "../src/Types/types";

describe("SetNextBlockTimestamp function tests", function () {
    const todayDate = new Date();
    let testDate = new Date();
    const currentDate = testDateString(todayDate);

    // Test successful timestamp change
    it("Increase timestamp by one month", async function () {
        testDate.setMonth(testDate.getMonth()+1);
        testDate.setFullYear(testDate.getFullYear()+1);
        const timeStampDate = testDateString(testDate);
        const timeStampTime = '13:00:00';
        const timeStamp : TimeStampValues = {
            date: timeStampDate,
            time: timeStampTime
        };
        
        await hre.newplugin.setNextBlockTimestamp(timeStamp);
        await hre.network.provider.send("evm_mine");
        const blockNum = await hre.ethers.provider.getBlockNumber();
        const block = await hre.ethers.provider.getBlock(blockNum);
        assert.equal(DateTimeBuilder(timeStampDate,timeStampTime), block.timestamp);
    });
    it("Should fail with past date", async function () {
        try {
            const timeStamp : TimeStampValues = {
                date: '2020-01-01',
                time: '01:00:00'
            };
            await hre.newplugin.setNextBlockTimestamp(timeStamp);
        } catch(err) {
            expect(err).to.equal("Invalid date, please check date provided.");
        }
    });
    it("Should fail with nonsense date", async function () {
        try {
            const timeStamp : TimeStampValues = {
                date: 'NotaDate',
                time: '01:00:00'
            };
            await hre.newplugin.setNextBlockTimestamp(timeStamp);
        } catch (err) {
            expect(err).to.equal("Invalid date/time format, only yyyy-mm-dd , h:m:s format is excepted.");
        }
    });
    it("Should fail with nonsense time", async function () {
        try {
            const timeStamp : TimeStampValues = {
                date: '2030-12-12',
                time: 'NotaTime'
            };
            await hre.newplugin.setNextBlockTimestamp(timeStamp);
        } catch (err) {
            expect(err).to.equal("Invalid date/time format, only yyyy-mm-dd , h:m:s format is excepted.");
        }
    });
    it("Should fail with improper time (25 hour)", async function () {
        try {
            const timeStamp : TimeStampValues = {
                date: '2030-12-12',
                time: '25:00:00'
            };
            await hre.newplugin.setNextBlockTimestamp(timeStamp);
        } catch (err) {
            expect(err).to.equal("Invalid date/time format, only yyyy-mm-dd , h:m:s format is excepted.");
        }
    });
    it("Should fail with improper time (61 minute)", async function () {
        try {
            const timeStamp : TimeStampValues = {
                date: '2030-12-12',
                time: '12:61:00'
            };
            await hre.newplugin.setNextBlockTimestamp(timeStamp);
        } catch (err) {
            expect(err).to.equal("Invalid date/time format, only yyyy-mm-dd , h:m:s format is excepted.");
        }
    });
});