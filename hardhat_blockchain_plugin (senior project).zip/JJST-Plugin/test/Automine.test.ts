//import { boolean } from "hardhat/internal/core/params/argumentTypes";
//import { isCommunityResourcable } from "@ethersproject/providers";
import {AutomineParams}  from "../src/Types/types";
const {expect,assert} = require("chai");
//const {describe,beforeEach,it} = require("mocha");
/* test 1 - func:get , no state
should display the same as the current state 

// test 2 - func:set, state: true 
should set the current automine as true 

// test 3 - func:set, state: false 
should set the current automine as true 
*/

describe(" Automine tests ",function(){
    let current : any; 
    let func_current : any;
    beforeEach (async function  () {
     // set current state of aautomine 
     current = await hre.network.provider.request({
         method: "hardhat_getAutomine",
        });
    });
    
    describe("test 1 - get current state - no params for state ", function(){
    it("The new plugin function should display the same result as before ", async function (){
        const test1 : AutomineParams = {func: 'get'};
        func_current = await hre.newplugin.Automine(test1);
        expect(current).to.equal(func_current); });
    });
 
    describe("TEST 2 - set the current state, state param given true ",function(){
        beforeEach (async function  () {
            await hre.network.provider.send("evm_setAutomine", [false]);
            // set current state of aautomine 
            current = await hre.network.provider.request({
                method: "hardhat_getAutomine",
            });  
        });
     
        it("The new plugin function should SET the state as TRUE ", async function (){
            const test1 : AutomineParams = {func: 'set',state:true};
            func_current = await hre.newplugin.Automine(test1);
            expect(func_current).to.equal(true); 
        });
    });

    describe ("Test 3 - set the current state, state param given as FALSE ",async function (){
        beforeEach (async function  () {
            await hre.network.provider.send("evm_setAutomine", [true]);
            // set current state of aautomine 
        });  
    
        it("The new plugin function should SET the state as FALSE ", async function (){
            const test1 : AutomineParams = {func: "set",state : false};
            func_current = await hre.newplugin.Automine(test1);
            expect(func_current).to.equal(false); 
        });
            describe ("Test 4 - dont change the current state ,func = get  , state param 'false' ",async function (){
            beforeEach (async function  () {
                current= await hre.network.provider.send("evm_setAutomine", [true]);
                // set current state of aautomine 
               });  

                it("The new plugin function should not change the state as FALSE ", async function (){
                    const test1 : AutomineParams = {func: "get",state:false};
                    func_current = await hre.newplugin.Automine(test1);
                    expect(func_current).to.equal(current); 
                });
            });
    });
  
});

    
  






