import { expect, assert } from "chai";
import { describe, beforeEach, it } from "mocha";
import hre from "hardhat";
import { time } from "@nomicfoundation/hardhat-network-helpers";
import { Contract } from "ethers";
import { NumberLike } from "@nomicfoundation/hardhat-network-helpers/dist/src/types";
import { IncreaseTimeParams } from "../src/Types/types";

describe("Lock", function () {
  let Lock;
  let lock: Contract;
  let unlockTime: number;
  let lockedAmount = 1_000_000_000;
  let testDate: Date;
  beforeEach(async function () {
    const ONE_YEAR_IN_SECS = 365 * 24 * 60 * 60;
    unlockTime = (await time.latest()) + ONE_YEAR_IN_SECS;
    // deploy a lock contract where funds can be withdrawn
    // one year in the future
    Lock = await hre.ethers.getContractFactory("Lock");
    lock = await Lock.deploy(unlockTime, { value: lockedAmount });
    testDate = new Date();
  });

  it("Should set the right unlockTime", async function () {
    // assert that the value is correct
    expect(await lock.unlockTime()).to.equal(unlockTime);
  });

  it("Should revert with the right error if called too soon", async function () {
    // ...deploy the contract as before...
    await expect(lock.withdraw()).to.be.revertedWith("You can't withdraw yet");
  });

  it("Should plugin.increaseTime() then transfer to owner", async function () {
    // ...deploy the contract...
    let prms: IncreaseTimeParams = {
      days: 366,
      hours: 0,
      minutes: 0,
      seconds: 0,
    };
    await hre.newplugin.IncreaseTime(prms);
    // this will throw if the transaction reverts
    await lock.withdraw();
  });

  it("plugin.MineTo(unlock time - 1 day)", async function () {
    // ...deploy the contract...
    let inputString: string = `${testDate.getFullYear() + 1}-${testDate.getMonth() + 1}-${testDate.getDate() - 1}`;
    console.log("test date = " + inputString);
    //TODO: fix up hardcode s
    await hre.newplugin.MineTo("2023-09-12");
    //await hre.newplugin.MineTo()
    // this will throw if the transaction reverts
    await expect(lock.withdraw()).to.be.revertedWith("You can't withdraw yet");
  });

  it("plugin.MineTo(unlock time + 1 day)", async function () {
    // ...deploy the contract...
    let inputString: string = `${testDate.getFullYear() + 1}-${testDate.getMonth() + 1}-${testDate.getDate() + 1}`;
    console.log("test date = " + inputString);
    await hre.newplugin.MineTo("2023-09-14");
    //await hre.newplugin.MineTo()
    // this will throw if the transaction reverts
    await lock.withdraw();
  });

  it("Should revert with the right error if called from another account", async function () {
    // ...deploy the contract...
    const [owner, otherAccount] = await ethers.getSigners();
    // we increase the time of the chain to pass the first check
    await time.increaseTo(unlockTime);
    // We use lock.connect() to send a transaction from another account
    await expect(lock.connect(otherAccount).withdraw()).to.be.revertedWith(
      "You aren't the owner"
    );
  });
});
