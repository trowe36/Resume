import { AccParams } from "../src/Types/types";
const { expect, assert } = require("chai");
const hre = require("hardhat");
const ethers = hre.ethers;
//const {describe,beforeEach,it,beforeAll} = require("mocha");

describe("setCoinBase function tests", function () {
    let accounts:any;
    let alice:any;

    this.beforeAll(async function () {
        accounts = await hre.ethers.getSigners();
        alice = accounts[3];
    });

    // Successfully set coinbase to new account and mine a block
    it("Should set new coinbase address", async function () {
        const alice_address = alice.address;
        const aliceParams = { hexAccAddress: alice_address };
        await hre.newplugin.SetCoinBase(aliceParams);
        await hre.network.provider.send("evm_mine");
        const currentBlock = await hre.network.provider.send("eth_getBlockByNumber", ['latest', true]);
        assert.equal(alice.address.toLowerCase(), currentBlock.miner);
    });

});