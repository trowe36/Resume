import { AnyCnameRecord } from "dns";
import { BigNumber } from "ethers";
import { AccParams } from "../src/Types/types";
const { expect, assert} = require("chai");
//const {describe,beforeEach,it,beforeAll} = require("mocha");

describe("SetAccBalance function test", function () {
  //let accounts: any;
  let billAddr: any;
  let jennyAddr: any;
  let aliceAddr: any;

  let bill: any, jenny: any, alice: any;
  //let jennyAddr: any;
  this.beforeAll(async function () {
    const accounts = await hre.ethers.getSigners();

    (bill = accounts[0]), (jenny = accounts[1]), (alice = accounts[2]);

    billAddr = bill.address;
    jennyAddr = jenny.address;
    aliceAddr = alice.address;
  });

  // Test successful account balance change of 1000 ETH
  describe("Add 1000 ETH to Bill's account", function () {
    it("Successfully add 1000 ETH to an account", async function () {
      const txConfig: AccParams = {
        hexAccAddress: billAddr,
        amount: 1000,
        type: "ether",
      };
      await hre.newplugin.SetAccBalance(txConfig);
      expect(hre.ethers.utils.formatEther(await bill.getBalance())).to.equal(
        "1000.0"
      );
    });
  });

  // Test successful account balance change of 1000 wei
  describe("Add 1000 wei to Jenny's account", function () {
    it("Successfully add 1000 wei to an account", async function () {
      const txConfig: AccParams = {
        hexAccAddress: jennyAddr,
        amount: 1000,
        type: "wei",
      };
      await hre.newplugin.SetAccBalance(txConfig);
      expect(await jenny.getBalance()).to.equal(1000.0);
    });
  });

  // Test unsuccessful account balance change of -1000 wei
  describe("Add -1000 wei to an account", function () {
    it("Should fail to add -1000 wei to an account", async function () {
      // Set account to zero before trying to set balance to -1000 wei
      let txConfig0: AccParams = {
        hexAccAddress: aliceAddr,
        amount: 0,
        type: "wei",
      };
      await hre.newplugin.SetAccBalance(txConfig0);
      let txConfig: AccParams = {
        hexAccAddress: aliceAddr,
        amount: -1000,
        type: "wei",
      };
      await hre.newplugin.SetAccBalance(txConfig);
      expect(await alice.getBalance()).to.equal(0);
    });
  });

  //Test to setAccBalance of an address not existent in the network.

  //reset all balances back to original state (maybe)
});
