# LABRYS HARDHAT PLUGIN

This project was developed for easing the process of development of smart contracts using hardhat. Existing functions in the Hardhat environment are encapsulated within new functions. These functions are designed to have simpler inputs as their parameters.

## REPOSITORY TREE

## FUNCTIONS

| **Function**              | **Parameter** | **Hardhat existing function used** |
|---------------------------|---------------|------------------------------------|
| **SetNonce**              |               |                                    |
| **setNextBlockTimestamp** |               |                                    |
| **HardhatMine**           |               |                                    |
| **IncreaseTime**          |               |                                    |
| **ImpersonateAccount**    |               |                                    |
| **SetAccBalance**         |               |                                    |
| **SendTransaction**       |               |                                    |
| **MineTo**                |               |                                    |
| **SetCoinBase**           |               |                                    |
| **SetMinGasPrice**        |               |                                    |
| **SetGasLimit**           |               |                                    |
| **Automine**              |               |                                    |
| **evmMine**               |               |                                    |
| **IntervalMining**        |               |                                    |
|                           |               |                                    |
|                           |               |                                    |
|                           |               |                                    |

### CREDITS

[Tom Rowen](https://github.com/trowe36)

[Jacob Pitt](https://github.com/jpitt46)

[Saloni Bhatia](https://github.com/saloni-bhatia)

[James Kilmartin](https://github.com/JamesKilmartin)
