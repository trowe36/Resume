import "@nomiclabs/hardhat-ethers";
import 'hardhat-deploy';
//import 'hardhat-deploy-ethers';
import { extendEnvironment, task } from "hardhat/config";
import "@nomiclabs/hardhat-waffle";
import "hardhat/config";
import "./src/index";
import { lazyObject } from "hardhat/plugins"
import { HardhatUserConfig } from "hardhat/types";
import "./src/types/types";
import "@nomiclabs/hardhat-ethers" 
import "./src/NewPlugin"
import "./src/types/types"

 //You need to export an object to set up your config
// Go to https://hardhat.org/config/ to learn more

const config: HardhatUserConfig = {
    solidity: "0.7.3",
    namedAccounts: {
        deployer: 0,
        tokenOwner: 1,
      },
    defaultNetwork: "hardhat"}

export default config;


