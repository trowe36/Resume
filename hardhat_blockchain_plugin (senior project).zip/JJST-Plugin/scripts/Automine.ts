//import { boolean } from "hardhat/internal/core/params/argumentTypes";
import {AutomineParams}  from "../src/Types/types";

/* Default values for the paramms : 
func  - mandatory - no default values
state = true - optinal
when  called - without any state params - should get the current state 
when called with just set anad no params for set-  should set the state as true 
when called with both params - set accordingly 
*/

// check if Automine is turned on/off before toggle using an if statement and then check again usoing the 
async function Automine(){
    try {
         const current = await hre.network.provider.request({
            method: "hardhat_getAutomine",
        });
         console.log('current state ');
         console.log(current); 
         // get the result without any state param
         const no_state: AutomineParams = {func: "get"};
        const current1 = await hre.newplugin.Automine(no_state)
        console.log(current1);// just show the current value as before - should be same as "current" 
        // with func - set 
        const  state1: AutomineParams = {func:"set",state:false};
        const new_set = (await hre.newplugin.Automine(state1)); // should be true 
        console.log(`new_set. ${new_set}`);

        // with both params
    
            let change: AutomineParams = {func :"set",state:false};
            let new_func = await hre.newplugin.Automine(change);
            console.log("new func");
            console.log(new_func); // should be false 
        
            let change1: AutomineParams = {func :"set",state:true};
             new_func = await hre.newplugin.Automine(change1);
            console.log(new_func); // shoud be true
        
}
catch(error)
{
    console.log(error)
}
} Automine();
