import { HardhatArguments } from "hardhat/types";
import { HardHatMineParams } from "../src/Types/types";

/*
 Test the HardHatMine plugin function.

 * Input 
  (BigNumber)Blocks_To_Mine   =  Number of blocks to be mined 
  (BigNumber)Mine_interval    =   Seconds of interval between the blocks

 * Post-Conditions
 Number of blocks mined = 10000
 time elapsed           = 20000 seconds

 */
async function HardhatMine() {
    try {
        //Set const param values to test the function  ** SHOULD THESE BE IN BIGNUMBER TO CHECK NOUNDARY CASES ? **
        const Blocks_To_Mine = 10000;
        const Mine_Interval = 2;

        // mine a block for time comparision/testing interval works 
        await hre.ethers.provider.send('evm_mine');

        //print blockchain details before operation 
        const blockNumBefore = await hre.ethers.provider.getBlockNumber();
        const blockBefore = await hre.ethers.provider.getBlock(blockNumBefore);
        const timestampBefore = blockBefore.timestamp;
        console.log("time before increase:   " + timestampBefore)
        console.log(`Block Number before increase ${blockNumBefore}`)
        console.log("\n\n------------------------------------------------------------")
        console.log(`ADDING ${Blocks_To_Mine} BLOCKS AT ${Mine_Interval} SECOND INTERVAL`)
        console.log("------------------------------------------------------------\n\n")

        // Set params for the HardHatMine function 
        const prms: HardHatMineParams = { numberOfBlocks: Blocks_To_Mine, interval: Mine_Interval }

        // Call the HardHat function
        await hre.newplugin.HardhatMine(prms);

        //print blockchain details after operation 
        const blockNumAfter = await hre.ethers.provider.getBlockNumber();
        const blockAfter = await hre.ethers.provider.getBlock(blockNumAfter);
        const timestampAfter = blockAfter.timestamp;
        console.log(`Block Number after ${blockNumAfter}`)
        console.log("time after increase:  " + timestampAfter)
        console.log(`\n\n time difference ${timestampAfter - timestampBefore}  should equal:   ${Mine_Interval * Blocks_To_Mine}`)
        //issue
    }

    // Catch any error and display 
    catch (err) {
        console.error(err);
        process.exit(1)
    }
}
HardhatMine()