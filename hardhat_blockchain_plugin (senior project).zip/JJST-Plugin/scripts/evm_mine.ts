import { time } from "console";
import { HardhatArguments } from "hardhat/types";
import { TimeStampValues } from "../src/Types/types";
async function  evm_mine(){
try{
    const Date = "2023-08-06";
    const Time = "10:30:30";
    //print blockchain details before operation
    const blockNumBefore = await hre.ethers.provider.getBlockNumber();
    const blockBefore = await hre.ethers.provider.getBlock(blockNumBefore);
    const timestampBefore = blockBefore.timestamp;
    console.log("time before increase:   " + timestampBefore);
    console.log(`Block Number before increase ${blockNumBefore}`);
    
    console.log(
      "\n\n------------------------------------------------------------"
    );
    console.log(`Changing timestamp to ${Date} ${Time})`);
    console.log(
      "------------------------------------------------------------\n\n"
    );
   
    await hre.newplugin.evmMine({date:Date,time:Time});
    const blockNumAfter = await hre.ethers.provider.getBlockNumber();
    const blockAfter = await hre.ethers.provider.getBlock(blockNumAfter);
    const timestampAfter = blockAfter.timestamp;
    console.log(`Block Number after ${blockNumAfter}`);
      console.log("time after increase:  " + timestampAfter);
    //issue
  } 
  catch (err) {
    console.error(err);
    process.exit(1);
  }

}
evm_mine();