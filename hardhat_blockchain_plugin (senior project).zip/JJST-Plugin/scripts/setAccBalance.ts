import { AccParams } from "../src/Types/types";

async function SetBalance() {
    try {
        const accounts = await hre.ethers.getSigners();
        console.log("total account number:  " + accounts.length + "\n")
        console.log("(1) ------------------------ACC BALANCE BEFORE OPERATION--------------------------")
        //display account balances
        for (var i = 0; i < accounts.length; i++) {
            console.log(await accounts[i].address + ` account balance: ${hre.ethers.utils.formatEther(await accounts[i].getBalance())} Eth` +
            `  ${await accounts[i].getBalance()} Wei`);
        }

        console.log('\n(2)-----------------------Now SETTING 100 ETHEREUM TO ALL ACCOUNTS---------------------')
        for(var i = 0; i < accounts.length; i++){
            const x: AccParams = { hexAccAddress: accounts[i].address, amount: 100, type: "ether" }
            hre.newplugin.SetAccBalance(x);
        }
         
        console.log('\n(3)-----------------------Ethereum balances---------------------')
        for(var i = 0; i < accounts.length; i++){
            console.log(`ether balance:  ` + `${hre.ethers.utils.formatEther(await accounts[i].getBalance())} Eth`)
        }

        //console.log("wei balance:  " + await accounts[0].getBalance())

        console.log('\n(4)-----------------------SETTING EACH ACCOUNT TO 500 WEI-------------------------')
        for(var i = 0; i < accounts.length; i++){
            const x: AccParams = { hexAccAddress: accounts[i].address, amount: 500, type: "ether" }
            hre.newplugin.SetAccBalance(x)
        }
        console.log('\n(5)-----------------------VALUES OF ACCOUNTS AFTER WEI SET-------------------------')
        for (var i = 0; i < accounts.length; i++) {
            console.log(await accounts[i].address + ` account balance: ${await accounts[0].getBalance()} Wei`);
        }

        process.exit(0)
    } catch (err) {
        console.error(err);
        process.exit(1)
    }
    
}

SetBalance()


