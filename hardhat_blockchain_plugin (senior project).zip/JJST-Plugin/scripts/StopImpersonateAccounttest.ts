
/*
 Test the StopImpersonateAccount plugin function.
  
 * Input
 Address of the account to be impersonated. 

 * Post-Conditions
 Balance of Account 0  remains same
 Balance of Account 1  remains same

 */

async function StopImpersonatingTest() {
    // Get all accounts present 
    const accounts = await hre.ethers.getSigners();

    //Attain first two accounts and their balances for testing purposes 
    console.log("Getting first two accounts")

    const Alice = accounts[0];
    const Bill = accounts[1];

    const Alice_Add = Alice.address;
    const Bill_Add = Bill.address;

    const Alice_Balance = hre.ethers.utils.formatEther(await Alice.getBalance());
    const Bill_Balance = hre.ethers.utils.formatEther(await Bill.getBalance());

    console.log(`Account 1 \n Address : ${Alice_Add} \n Balance : ${Alice_Balance}`);
    console.log(`Account 2 \n Address : ${Bill_Add} \n Balance : ${Bill_Balance}`);

    // Impersonating Account 1 (Alice) using HardHat function
    console.log("Impersonating Account 1");
    // Set params for HardHat function
    const params = { hexAccAddress: Alice_Add };
    hre.newplugin.ImpersonateAccount(params);

    //assign the account as signer under the ethers extension
    const signer = await hre.ethers.getSigner(params.hexAccAddress)

    //log the transaction
    console.log("Transaction information" + {
        to: Bill_Add,
        value: hre.ethers.utils.parseEther("400")
    })
    //send the transaction from the signer 
    await signer.sendTransaction({
        to: Bill_Add,
        value: hre.ethers.utils.parseEther("400")
    })
    // new balance
    const New_Alice_Balance = hre.ethers.utils.formatEther(await Alice.getBalance());
    const New_Bill_Balance = hre.ethers.utils.formatEther(await Bill.getBalance());

    //display account balances
    console.log(`Account 1 \n Address : ${Alice_Add} \n Balance : ${ New_Alice_Balance}`);
    console.log(`Account 2 \n Address : ${Bill_Add} \n Balance : ${New_Bill_Balance} `);

    //stop the impersonation
    hre.newplugin.StopImpersonateAccount(params);
    console.log("===Stopping===");
    
    const New_A_Balance = hre.ethers.utils.formatEther(await Alice.getBalance());
    const New_B_Balance = hre.ethers.utils.formatEther(await Bill.getBalance());

    //display account balances - Should be the totally same as before the INITIAL transaction 
    console.log(`Account 1 \n Address : ${Alice_Add} \n Balance : ${New_A_Balance}`);
    console.log(`Account 2 \n Address : ${Bill_Add} \n Balance : ${New_B_Balance}` );
 
};

StopImpersonatingTest()

    .then(() => process.exit(0))

    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
