//While it's not possible to explicitly cancel a transaction, you can invalidate the transaction before it's mined. 
//The way this works is by broadcasting the same transaction using the same nonce, but with a higher gas fee. 
//The miners are incentivized to process transactions with higher fees. If they process the newer transaction, 
//then the old transaction becomes invalid and therefore rejected.


//NOTE: was told to drop this story as it is beyond skill level. Confirm if we should complete this story. confirmed... DONT DO
//DONT REMOVE COMMENTS PLS - TOM
async function DropTransaction(){
    try{
        //mine on block 

        //disable mining so transactions will be pending

        //send a few transactions that will remain pending until block is mined 

        //get list of pending transactions 
        const pendingBlock = await hre.network.provider.send("eth_getBlockByNumber", [
            "pending",
            false,
          ]);
        
          const txHash = "0xabc...";

        //drop the transaction from the pending list 
        await hre.network.provider.send("hardhat_dropTransaction", [txHash]);

        //re-obtain the list of pending transaction. should have relevent transaction dropped. 

    }
    catch (err) {
        console.error(err);
        process.exit(1)
    }  
}

DropTransaction()

