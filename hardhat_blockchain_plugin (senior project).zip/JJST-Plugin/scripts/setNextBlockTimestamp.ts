import { HardhatArguments } from "hardhat/types";
import { TimeStampValues } from "../src/Types/types";

async function setTimestamp() {
  try {
    //Set const param values for function
    const Date = "2030-10-15";
    const Time = "12:30:30";
    //print blockchain details before operation
    const blockNumBefore = await hre.ethers.provider.getBlockNumber();
    const blockBefore = await hre.ethers.provider.getBlock(blockNumBefore);
    const timestampBefore = blockBefore.timestamp;
    console.log("time before increase:   " + timestampBefore);
    console.log(`Block Number before increase ${blockNumBefore}`);
    
    console.log(
      "\n\n------------------------------------------------------------"
    );
    console.log(`Changing timestamp to ${Date} ${Time})`);
    console.log(
      "------------------------------------------------------------\n\n"
    );
    console.log(`setNextBlockTimestamp(${Date},${Time}`);
    await hre.newplugin.setNextBlockTimestamp({ date: Date, time: Time });

    //print blockchain details after operation
      await hre.ethers.provider.send("evm_mine");
    const blockNumAfter = await hre.ethers.provider.getBlockNumber();
    const blockAfter = await hre.ethers.provider.getBlock(blockNumAfter);
    const timestampAfter = blockAfter.timestamp;
    console.log(`Block Number after ${blockNumAfter}`);
      console.log("time after increase:  " + timestampAfter);
    //issue
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}
setTimestamp();
