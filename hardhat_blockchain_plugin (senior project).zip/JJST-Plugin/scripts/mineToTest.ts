import { BigNumber } from "ethers";
/*
 Test the MineTo plugin function.
 * Post-Conditions
   Latest block should be mined at the given date format.
 */
async function MineTo() {
    try {
        // Display information about the current block on the blockchain
        const startBlockNum = await hre.network.provider.send("eth_blockNumber");
        const startBlock = await hre.network.provider.send("eth_getBlockByNumber", [startBlockNum, true]);
        console.log("Starting block in the blockchain is " + startBlock.hash);
        console.log("With a block number of " + BigNumber.from(startBlockNum));

        // Mine to a future date with a set mining interval
        hre.newplugin.MineTo("2022-08-04");

        // Display information about the latest block on the blockchain
        const newBlockNum = await hre.network.provider.send("eth_blockNumber");
        const newBlock = await hre.network.provider.send("eth_getBlockByNumber", [newBlockNum, true]);
        console.log("Latest block in the blockchain is " + newBlock.hash);
        console.log("With a block number of " + BigNumber.from(newBlockNum));

    }
    catch (error) {
        console.error(error);
        process.exit(1);
    }
}
MineTo();