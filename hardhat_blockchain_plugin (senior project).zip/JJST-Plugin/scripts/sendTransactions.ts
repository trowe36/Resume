import { Console } from "console";
import { SendTransParams, AccParams } from "../src/Types/types";
const ethers = hre.ethers;

async function SendTransaction() {
    try {
        //await hre.network.provider.send("evm_setAutomine", [false]);
        const [bill, alice, bob, ross] = await ethers.getSigners();
        console.log("----------------------creating test accounts------------------------");
        const billAddr = bill.address 
        const aliceAddr = alice.address
        const bobAddr = bob.address
        const rossAddr = ross.address

        //display account balances
        console.log(`Bill: ${billAddr} account balance: ${ethers.utils.formatEther(await bill.getBalance())} Eth`)
        console.log(`In wei: ${await bill.getBalance()}`)
        console.log(`Alice: ${aliceAddr} account balance: ${ethers.utils.formatEther(await alice.getBalance())} Eth`)
        console.log(`In wei: ${await alice.getBalance()}`)
        console.log(`Bob: ${bobAddr} account balance: ${ethers.utils.formatEther(await bob.getBalance())} Eth`)
        console.log(`In wei: ${await bob.getBalance()}`)
        console.log(`Ross: ${rossAddr} account balance: ${ethers.utils.formatEther(await ross.getBalance())} Eth`)
        console.log(`In wei: ${await ross.getBalance()}`)

        //send 100 wei and display the result
        console.log("----------------------------------SENDING 100 wei FROM Bill to Alice debug false--------")
        //impersonate account
        //send transaction 
        const txConfig: SendTransParams = { from: billAddr, to: aliceAddr, amount: 100, type: "wei", debug: false}
        await hre.newplugin.SendTransaction(txConfig)
        console.log("RESULT ---------------")
        console.log(await billAddr + ` account balance: ${await bill.getBalance()} Wei   
        ${ethers.utils.formatEther(await bill.getBalance())} Eth`);
        console.log(await aliceAddr + ` account balance: ${await alice.getBalance()} Wei   
        ${ethers.utils.formatEther(await bill.getBalance())} Eth`);


        const setAccParams: AccParams = { hexAccAddress: bobAddr, amount: 101, type: "ether" }
        hre.newplugin.SetAccBalance(setAccParams)
        console.log("----------------------------------SENDING 100 ETH FROM Bob to Ross debug = true -----")
        const txConfigNext: SendTransParams = { from: bobAddr, to: rossAddr, amount: 100, type: "ether", debug: true}
        await hre.newplugin.SendTransaction(txConfigNext)
        console.log("RESULT ---------------")
        console.log(`Bob:  ` + await bobAddr + ` account balance: ${await bob.getBalance()} Wei   
        ${ethers.utils.formatEther(await bob.getBalance())} Eth`);
        console.log(`Ross ` + await rossAddr + ` account balance: ${await ross.getBalance()} Wei   
        ${ethers.utils.formatEther(await ross.getBalance())} Eth`);



        console.log("----------------------------------SETTING Bob acc to 0 eth and attempting transfer to alice -----")
        const tstParams: AccParams = { hexAccAddress: bobAddr, amount: 0, type: "ether" }
        hre.newplugin.SetAccBalance(tstParams)
        console.log(`bob balance:     ${ethers.utils.formatEther(await bob.getBalance())} Eth`)
        console.log("attempting transfer to alice, should show debug output")
        console.log("Result -----")


        console.log("----------------------------------sending zero/negative int amount to account -----")
        const config : SendTransParams = { from: bobAddr, to: aliceAddr, amount: 1, type: "ether", debug: true}
        await hre.newplugin.SendTransaction(config)

        //after testing use assert to ensure values of accounts are what they should be post transactions 

        //debug: check params exist, check ether not null, type is wei or ether. idk what else? 
        process.exit(0)
    }
    catch(err){
        console.error(err);
        process.exit(1)
    }
}

SendTransaction()