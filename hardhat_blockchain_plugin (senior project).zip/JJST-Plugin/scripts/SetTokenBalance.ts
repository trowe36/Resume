import { SetTokenBalanceParams } from "../src/Types/types"


async function SetTokenBalance() {
    try {
        /*
        const {getNamedAccounts} = hre;
        const {tokenOwner} = await getNamedAccounts()
        console.log((tokenOwner));
        const sig = await hre.ethers.getSigner(tokenOwner) //hungup
        let tokenBalance = hre.ethers.utils.formatEther(await sig.getBalance())
        let tokenBalance2 =await sig.getBalance();
        console.log(`acc balance should have all tokens ${tokenBalance} Eth`)    
        console.log(`acc balance should have all tokens ${tokenBalance2} not formatted`)    

        const index = await ethers.utils.solidityKeccak256(
            ["uint256", "uint256"],
            ["0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266", 0] // key, slot
        )
        //-----------------------------------------------------------------------------------
        const myContract = await deployments.get("Token");

        const Token = await ethers.getContractAt(
        myContract.abi,
        myContract.address
        );
        const owner = await ethers.provider.getStorageAt('0x70997970C51812dc3A010C7d01b50e0d17dc79C8', 2);
        console.log(owner)
        //const dataBal2 = await Token.balanceOf(owner);
        //console.log("total token balance " + dataBal2);
        //------------------------------------------------------------------------------------
        const dataBal = await ethers.provider.getStorageAt('0x70997970C51812dc3A010C7d01b50e0d17dc79C8', index)
        console.log("total token balance " + dataBal);

        //get contract
        //get info for deployed contract 2 (token 2) and test token transaction
        ///
        ///
        */
        const contractaddress = "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2";
        const { getNamedAccounts } = hre;
        const { tokenOwner } = await getNamedAccounts()
        const settokenparams: SetTokenBalanceParams = { receiverAcc: tokenOwner, amount:100, contractAddr:contractaddress}
        hre.newplugin.SetTokenBalance(settokenparams);

    }catch(err) {
        console.error(err);
        process.exit(1)
    }
}

SetTokenBalance()
