import { SetTokenBalanceParams } from "../src/types/types";


  
async function FindContract() {
    try {
        const contractAddress = "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2";//WETH CONTRACT ADDRESS
        const accountToFund = "0x70997970C51812dc3A010C7d01b50e0d17dc79C8";//WILL BE CHANGED INTO INPUT (acc #1 in HH)

        const setTokenPrms: SetTokenBalanceParams = { receiverAcc: accountToFund, amount : 3, contractAddr : contractAddress};
        await hre.newplugin.SetTokenBalance(setTokenPrms);
    }
    catch (err) {
        console.error(err);
        process.exit(1)
    }
}
FindContract();
/*
interface fetchData {
  holders: [ address: Address, balance: BigNumber, share: BigInt]
}

async function getTopTokenHolders() {
return https.get("https://api.ethplorer.io/getTopTokenHolders/0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2?apiKey=freekey&limit=1" , res => {
  let data = '';
  res.on('data', chunk => {
    data += chunk;
  });
  res.on('end', () => {
    data = JSON.parse(data);
    console.log(data);
  })
}).on('error', err => {
  console.log(err.message);
})
}


/*
async function FindContract() {
    try {
        const provider = new hre.ethers.getDefaultProvider('http://127.0.0.1:8545/')
        const contractAddress = "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2";
        const contract = await new hre.ethers.Contract(contractAddress, abi, provider );
        console.log(await contract.name);
        const wallet = new ethers.Wallet("0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d")
        const connectedWallet = wallet.connect(provider)

        const trans = await contract.connect(connectedWallet).approve("0x70997970C51812dc3A010C7d01b50e0d17dc79C8", ethers.utils.parseUnits('0.1', 18).toString())
        const receipt = await trans.wait();
        console.log("receipt Block Number: ", receipt.blockNumber);
//----------------------------------------------------------------------------------------------------

const contractAddress = "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2";//WETH CONTRACT ADDRESS
//const accountToImpersonate = "0xf04a5cc80b1e94c69b48f5ee68a08cd2f09a7c3e" //WHALE ACCOUNT
const accountToFund = "0x70997970C51812dc3A010C7d01b50e0d17dc79C8" //WILL BE CHANGED INTO INPUT (acc #1 in HH)



const setTokenPrms: SetTokenBalanceParams = { receiverAcc: accountToFund, amount : 3, contractAddr : contractAddress};
await hre.newplugin.SetTokenBalance(setTokenPrms);

//console.log(daiContract.interface)
// const decimals = 18;
// //console.log(await daiContract.provider)

// console.log("debug: new amount = " + transferAmount)
// var tx = await daiContract.transfer(accountToFund, amount )
// console.log("LOL")
// const accountBalance = await daiContract.balanceOf(accountToFund)
// console.log("transfer complete")
// console.log("funded account balance", accountBalance / 1e18)

// const whaleBalanceAfter = await daiContract.balanceOf(accountToImpersonate)
// console.log("whale dai balance after", whaleBalanceAfter / 1e18)
// console.log("Eth Balance: ", await signer.getBalance())
// await getTopTokenHolders();
} */