import {Automine, Interval_Mining}  from "../src/Types/types";
import {AutomineParams}  from "../src/Types/types";

/* Default values for the paramms : 
func  - mandatory - no default values
state = true - optinal
when  called - without any state params - should get the current state 
when called with just set anad no params for set-  should set the state as true 
when called with both params - set accordingly 
*/

// check if Automine is turned on/off before toggle using an if statement and then check again usoing the 
async function Interval_Mining()
{
    try
    {  
        const test1 : AutomineParams = {func: "set",state:true};
        const func_before = await hre.newplugin.Automine(test1);
        console.log(func_before) //should be true
        const interval_5000: Interval_Mining = {interval:5000};
        const change_5000 = await hre.newplugin.Interval_Mining(interval_5000)
        const no_interval: Interval_Mining = {interval:0};
        const change_noInterval = await hre.newplugin.Interval_Mining(no_interval)
        const test2 : AutomineParams = {func: "get"};
        const func_current = await hre.newplugin.Automine(test2);
        console.log(func_current) //should be false
    }
    catch(error)
    {
        console.log(error);
        

    }
}Interval_Mining();