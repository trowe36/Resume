import { IncreaseTimeParams } from "../src/Types/types";

/*
 Test the IncreaseTime plugin function.

 * Input (Array )
   days = Number of days 
   hours = Number of hours 
   minutes = Number of minutes 
   Seconds = Number of seconds 
  
 * Post-Conditions
   TimeStamp of mined block after function execution should = 93784
 */

async function IncreaseTime() {
    const Days = 1;
    const Hours = 2;
    const Minutes = 3;
    const Seconds = 4;

    try {
        // Get current block number for comparison and validation later 
        const blockNumBefore = await hre.ethers.provider.getBlockNumber();
        const blockBefore = await hre.ethers.provider.getBlock(blockNumBefore);
        const timestampBefore = blockBefore.timestamp;
        console.log("time before increase:   " + timestampBefore);
        console.log(`Block Number before increase ${blockNumBefore}`);

        //mine block so that time can be increased accurately. Not include RunTime
        await hre.ethers.provider.send("evm_mine");
         
        // Set params and call  the plugin function 
        const prms: IncreaseTimeParams = { days: Days, hours: Hours, minutes: Minutes, seconds: Seconds };
        await hre.newplugin.IncreaseTime(prms);

        // Mine block after increasing time 
        await hre.ethers.provider.send("evm_mine");

        // Compare the block numbers before and after the function execution 
        const blockNumAfter = await hre.ethers.provider.getBlockNumber();
        const blockAfter = await hre.ethers.provider.getBlock(blockNumAfter);
        const timestampAfter = blockAfter.timestamp;
        console.log(`Block Number after ${blockNumAfter}`);

        // Confirm time increment 
        console.log("time after increase:  " + timestampAfter);
        console.log(
            `time difference ${timestampAfter - timestampBefore
            }  should equal:   93784`
        );
    }
    catch (err) {
        console.error(err);
        process.exit(1)
    }
}

IncreaseTime()