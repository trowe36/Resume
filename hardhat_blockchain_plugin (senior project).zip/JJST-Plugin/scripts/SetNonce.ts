import { SetNonceParam } from "../src/Types/types";

async function SetNonce() {
    try {
        const [bill, alice] = await ethers.getSigners();
        const billAddr = bill.address 
        const aliceAddr = alice.address
        console.log(billAddr);
        console.log(aliceAddr);


        const signerBill = await hre.ethers.getSigner(billAddr)

        const tx = await signerBill.sendTransaction({
            to: aliceAddr,
            value: `0x${1000}`,
          });
        
          tx.wait();
          console.log(tx);

          const nonceConfig: SetNonceParam = { nonce: 50, account : billAddr}
          await hre.newplugin.SetNonce(nonceConfig);


          const tx2 = await signerBill.sendTransaction({
            to: aliceAddr,
            value: `0x${1000}`,
          });
          
          
        
          tx2.wait();
          console.log(tx2);
          //NOTES:
          // nonce can only be increased not decreased 
          //

    }catch{

    }
}

SetNonce()