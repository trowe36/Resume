import { int, string } from "hardhat/internal/core/params/argumentTypes";
import { HardhatRuntimeEnvironment } from "hardhat/types";
import axios from "axios";

const abi = [
  {
    "inputs": [],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "spender",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "value",
        "type": "uint256"
      }
    ],
    "name": "Approval",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "value",
        "type": "uint256"
      }
    ],
    "name": "Transfer",
    "type": "event"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "spender",
        "type": "address"
      }
    ],
    "name": "allowance",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "spender",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "amount",
        "type": "uint256"
      }
    ],
    "name": "approve",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "account",
        "type": "address"
      }
    ],
    "name": "balanceOf",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "decimals",
    "outputs": [
      {
        "internalType": "uint8",
        "name": "",
        "type": "uint8"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "spender",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "subtractedValue",
        "type": "uint256"
      }
    ],
    "name": "decreaseAllowance",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "spender",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "addedValue",
        "type": "uint256"
      }
    ],
    "name": "increaseAllowance",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "name",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "symbol",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "totalSupply",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "amount",
        "type": "uint256"
      }
    ],
    "name": "transfer",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "amount",
        "type": "uint256"
      }
    ],
    "name": "transferFrom",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  }
]
//import ethers from "@nomiclabs/hardhat-ethers";

import {
  AccParams,
  SendTransParams,
  IncreaseTimeParams,
  HardHatMineParams,
  TimeStampValues,
  AutomineParameters,
  SetNonceParam,
  Interval_Mining,
  SetTokenBalanceParams,
} from "./Types/types";
//import ethers from "@nomiclabs/hardhat-ethers";
import {
  debugSendTransaction,
  isValidDate,
  isValidTime,
  DateTimeBuilder,
} from "./util";
import { IncreaseTimePrmsCheck } from "./util";
import { Console } from "console";
import { resolve } from "url";

async function getTopTokenHolders(address: String) {
  console.log("test get top token");
    const res = await axios.get(`https://api.ethplorer.io/getTopTokenHolders/${address}?apiKey=EK-8nfA5-9opFN9A-qE59G&limit=1`)
    return (res.data.holders[0].address.toString());
}

interface obj {
  holders: [];
}

export class NewPlugin {
  public SetTokenBalance = async ({
    receiverAcc,
    amount,
    contractAddr
  }: SetTokenBalanceParams): Promise<void> => {
      try {
          console.log(receiverAcc.toString());
          console.log(amount.toString());
          console.log("contract", contractAddr.toString());
          var whale = await getTopTokenHolders(contractAddr)
          console.log(whale)
          console.log("should be whale ", whale);
      const whaleacc = {
          hexAccAddress: whale
      }
          await hre.newplugin.ImpersonateAccount(whaleacc);
          const signer = await hre.ethers.getSigner(whale);
          console.log("assigning whale")
          var daiContract = await new ethers.Contract(contractAddr, abi, signer);
          console.log(await daiContract.name);
          var daiBalance = await daiContract.balanceOf(signer.getAddress())
          console.log("whale dai balance", daiBalance / 1e18)
          console.log("transfering to", receiverAcc);
          //console.log("transferring amount", (daiBalance/1e18) / 2
          //const transferAmount : string = ((daiBalance/1e18) / 2).toString();
          console.log(
              "-------------------------------------------------------------------------------------------------------------------------------------------------------------"
          );
          const x: AccParams = {
              hexAccAddress: whale,
              amount: 100,
              type: "ether",
          };
          await hre.newplugin.SetAccBalance(x);
          console.log("Balance: ", await signer.getBalance());
          const decimals = 18;
          //daiBalance = daiBalance/(2*1e18);
          const input = amount.toString(); // Note: this is a string, e.g. user input
          const transferAmount = hre.ethers.utils.parseUnits(input, decimals);

          await daiContract.transfer(receiverAcc, transferAmount);
          var daiBalance = await daiContract.balanceOf(whale)
          console.log("whale dai balance", daiBalance / 1e18)
          const sig = await hre.ethers.getSigner(receiverAcc);
          var sigdaibal = await daiContract.balanceOf(sig.address)
          console.log("receiver dai bal: ", await sigdaibal/1e18);
          //await printTopTokenHolderBalance(contractAddr);
      } catch (error) { console.log(error) } };

  public SetNonce = async ({
    nonce,
    account,
  }: SetNonceParam): Promise<void> => {
    const hexAmount = nonce.toString(16);
    await hre.network.provider.send("hardhat_setNonce", [
      `${account}`,
      `0x${hexAmount}`,
    ]);
  };

  public setNextBlockTimestamp = async ({
    date,
    time,
  }: TimeStampValues): Promise<void> => {
    
          if (isValidDate(date) && isValidTime(time)) {  //DO we want the set next block timestamp to be able to go backwards in time?
          try {
            const nextblockdate = DateTimeBuilder(date, time);
            //convert the date & time to a valid parameter that is accepted by the exm_setNextBlockTimestamp
            await hre.network.provider.send("evm_setNextBlockTimestamp", [
            `0x${nextblockdate.toString(16)}`,
          ]);
          } catch (error) {
            return Promise.reject("Invalid date, please check date provided.")
          }
          
        } else {
          return Promise.reject("Invalid date/time format, only yyyy-mm-dd , h:m:s format is excepted.");
        }
      
     
  };
  public HardhatMine = async (prms: HardHatMineParams): Promise<void> => {
    try {
      const { numberOfBlocks, interval } = prms;
      // Validate that mining block number is a positive integer
      if (numberOfBlocks <= 0 || typeof numberOfBlocks == "string") {
        throw "The mining block number is not a positive number";
      }
      // Validate that mining interval is a positive integer
      if (interval <= 0 || typeof interval == "string") {
        throw "The mining interval is not a positive number";
      }
      const blocksHex = numberOfBlocks.toString(16);
      const intervalHex = interval.toString(16);
      // mine 1000 blocks with an interval of 1 minute
      await hre.network.provider.send("hardhat_mine", [
        `0x${blocksHex}`,
        `0x${intervalHex}`,
      ]);
    } catch (error) {
      console.error(error);
    }
  };

  public IncreaseTime = async (prms: IncreaseTimeParams): Promise<void> => {
    await hre.network.provider.send("evm_mine"); //mine block so that time can be increased accurately
    const { days, hours, minutes, seconds } = prms; //deconstruct params passed in
    await IncreaseTimePrmsCheck(prms); //if any params are negative numbers, throw error
    /*console.log(
      "---------------------------------------------------------------------------------------------"
    );
    console.log(
      `Increasing time by ${days} days, ${hours} hours, ${minutes} minutes and ${seconds} seconds`
    );
    console.log(
      "---------------------------------------------------------------------------------------------"
    );*/

    //convert days/hours/minutes to seconds and create total seconds variable
    const daysAsSeconds = days * 24 * 60 * 60;
    const hoursAsSeconds = hours * 60 * 60;
    const minutesAsSeconds = minutes * 60;
    const total = daysAsSeconds + hoursAsSeconds + minutesAsSeconds + seconds;
    
    /*const blockNumBefore = await hre.ethers.provider.getBlockNumber();
    const blockBefore = await hre.ethers.provider.getBlock(blockNumBefore);
    const timestampBefore = blockBefore.timestamp;
    console.log("time before increase:   " + timestampBefore);
    console.log(`Block Number before increase ${blockNumBefore}`);*/

    await hre.network.provider.send("evm_increaseTime", [total]);
    await hre.network.provider.send("evm_mine");

    /*const blockNumAfter = await hre.ethers.provider.getBlockNumber();
    const blockAfter = await hre.ethers.provider.getBlock(blockNumAfter);
    const timestampAfter = blockAfter.timestamp;
    console.log(`Block Number after ${blockNumAfter}`);
    console.log("time after increase:  " + timestampAfter);*/
    // console.log(
    //   `time difference ${
    //     timestampAfter - timestampBefore
    //   }  should equal:   ${total}`
    //);
    //Question: https://ethereum.stackexchange.com/questions/86633/time-dependent-tests-with-hardhat
    //should we call evm_mine to solidify the timestamp on the next block within the function?????
  };

  //hre = require("hardhat"); TODO: could make global. However could have unintended consequences (Jacob)
  public ImpersonateAccount = async ({
    hexAccAddress,
  }: AccParams): Promise<void> => {
    await hre.network.provider.request({
      method: "hardhat_impersonateAccount",
      params: [hexAccAddress],
    });
  };

  public SetAccBalance = async (prms: AccParams): Promise<void> => {
    try {
      let { hexAccAddress, amount } = prms;
      // Validate amount input is a positive integer
      if (amount < 0) {
        throw "Account balance must be zero or more";
      }

      //if debug == yes. call helper function from external file, pass params in to check

      if (prms.type === "ether") {
        amount = amount * 10 ** 18;
        var hexAmount = amount.toString(16);
        await hre.network.provider.send("hardhat_setBalance", [
          hexAccAddress,
          `0x${hexAmount}`,
        ]);
      } else {
        // do wei stuff
        var hexAmount = amount.toString(16);
        await hre.network.provider.send("hardhat_setBalance", [
          hexAccAddress,
          `0x${hexAmount}`,
        ]);
      }
    } catch (error) {
      console.error(error);
    }
  };

    //only set up to use type = "wei"
  public SendTransaction = async (prms: SendTransParams): Promise<void> => {
    let txHasError = false;
    //parse params, impersonate 'from account' and get that singer info
    let { to, from, amount, type, debug } = prms;
    if (debug) {
      txHasError = await debugSendTransaction(prms);
    }
    //if no
    if (!txHasError) {
      const impersonedAcct = { hexAccAddress: from };
      hre.newplugin.ImpersonateAccount(impersonedAcct);
      const signer = await hre.ethers.getSigner(impersonedAcct.hexAccAddress);
      let tx;
      if (type === "wei") {
        const hexAmount = amount.toString(16);
        tx = await signer.sendTransaction({
          to: to,
          value: `0x${hexAmount}`,
        });
      } else {
        //ether
        amount = amount * 10 ** 18;
        const hexAmount = amount.toString(16);
        tx = await signer.sendTransaction({
          to: to,
          value: `0x${hexAmount}`,
        });
      }
      await tx.wait(); //wait for tx receipt so that result can be logged effectively.
      // console.log(tx);
    } else {
      console.log("test: no transfer has error");
    }
  };

  /*
    The MineTo function takes a date string in the format of yyyy-mm-dd and an interval
    between mining blocks in seconds and determines the number of blocks that would need to be mined
    to simulate the passing of time. These params are then passed to the hardhat_mine function.
    Input: date as a string and interval as a number, default interval is 600 sec.
    Returns: An error if the data format is not yyyy-mm-dd, if the user date parameter is not in the future,
    or if the mining interval is a non-positive integer.
    */
  public MineTo = async (
    date: string,
    interval: number = 600
  ): Promise<void> => {
    try {
      // Validate input params
      if (isValidDate(date)) {
        // Create date object based on input cast as a number
        const userDate = Number(new Date(date));
        // Get current datetime
        const now = Date.now();
        // Validate that userDate is in the future
        if (userDate < now) {
          throw "The date that you are trying to mine to is not in the future, please supply a new date.";
        }
        // Validate that mining interval is a positive integer
        if (interval <= 0 || typeof interval == "string") {
          throw "The mining interval is not a positive number";
        }
        // Calculate difference between current and input datetime in milliseconds and
        // divide by interval in milliseconds to calculate total number of blocks to mine
        const blockNumber = Math.round((userDate - now) / (interval * 1000));
        // console.log("Number of mined blocks is " + blockNumber);
        // Convert mineBlocks and mineInterval to hex
        const mineBlocks = blockNumber.toString(16);
        const mineInterval = interval.toString(16);
        // Call hardhat_mine with params
        await hre.network.provider.send("hardhat_mine", [
          `0x${mineBlocks}`,
          `0x${mineInterval}`,
        ]);
      } else {
        throw "Invalid date format, yyyy-mm-dd expected";
      }
    } catch (error) {
      console.error(error);
      //process.exit(1);
    }
  };

  /* The SetCoinBase function sets the user supplied address as the miner
  of the next block in the blockchain.
  Input:account address as a hex string.
  */
  public SetCoinBase = async ({ hexAccAddress }: AccParams): Promise<void> => {
    await hre.network.provider.request({
      method: "hardhat_setCoinbase",
      params: [hexAccAddress]
    });
  };

  /* The SetMinGasPrice function sets a new gas price that is accepted by the network.
  Input: gasPrice as a number that represents the new gas price in Gwei.
  Return: Error if the gas price is equal to or less than zero.
  */
 public SetMinGasPrice = async (
  gasPrice: number
  ): Promise<void> => {
    if(typeof gasPrice != 'number') {
      return Promise.reject('Gas price must be a numerical value')
    }
    if(gasPrice <= 0) {
      return Promise.reject('Gas price must be a value greater than zero');
    }
    const GAS_PRICE = (gasPrice * 1e9).toString(16);
    await hre.network.provider.send(
      "hardhat_setNextBlockBaseFeePerGas",
      [`0x${GAS_PRICE}`]
    );
  };

  /* The SetGasLimit function sets the upper gas price that all the transactions
  in a block can consume.
  Input: gasLimit as a number that represents the new gas limit in Gwei.
  Returns: Error if the the gas limit is equal to or less than zero.
  */
  public SetGasLimit = async (
    gasLimit: number
    ): Promise<void> => {
      if(typeof gasLimit != 'number') {
        return Promise.reject('Gas limit must be a numerical value')
      }
      if(gasLimit <= 0) {
        return Promise.reject('Gas limit must be a value greater than zero');
      }
      const GAS_LIMIT = (gasLimit * 1e9).toString(16);
      await hre.network.provider.send(
        "evm_setBlockGasLimit",
        [`0x${GAS_LIMIT}`]
      );
    };

  // Set/get Automine :input boolean to change it.
  public  Automine = async  ({
    func , state
   }: AutomineParameters): Promise<void>=> {
     if (func=='get')
     {
       return (await hre.network.provider.request({
         method: "hardhat_getAutomine"
 
     })
       );
       
     }
     else if (func=='set')
     {
       
       await hre.network.provider.send("evm_setAutomine", [state]);
         return(await hre.network.provider.request({
           method: "hardhat_getAutomine"
         })
         );
 
     }  
    };  
    public evmMine = async ({
      date,
      time
    }: TimeStampValues): Promise<void> => {
      const timeStamp : TimeStampValues = {
        date: date,
        time: time
      };
      await this.setNextBlockTimestamp(timeStamp);
      await hre.ethers.provider.send("evm_mine"); 
    }
    public  Interval_Mining = async  ({
      interval
     }: Interval_Mining): Promise<void>=> {
     
      await hre.network.provider.send("evm_setAutomine", [false]);
      await hre.network.provider.send("evm_setIntervalMining", [interval]);
  
      return(await hre.network.provider.request
        ({
             method: "hardhat_setIntervalMining"
        })
        );
      };
};