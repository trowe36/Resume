import { Contract } from "ethers";

interface MineToFunctionParams {
  date: string;
  interval: number;
}

export interface SetNonceParam {
  nonce: number,
  account: string,
}

export interface SetTokenBalanceParams{
  receiverAcc : string,
  amount : number, 
  contractAddr : string,
}

export interface BaseSendTransParams {
  from: string;
  to: string;
  amount: number;
    type: string;
    debug?: boolean;
}/*
interface YesInfoConfig extends BaseSendTransParams {
  debug: true;
}
interface NoInfoConfig extends BaseSendTransParams {
  debug: false;
}
*/
export type SendTransParams = BaseSendTransParams;// | YesInfoConfig | NoInfoConfig; original method however forces debug as an option

export interface BaseAccParams {
    hexAccAddress: string;
  amount: number;
  balance?: number; 
  time?: string;
  blockNumber?: number;
  type?: string;
}

interface EtherConfig extends BaseAccParams {
  type: "ether";
}

interface WeiConfig extends BaseAccParams {
  type: "wei";
}

export type AccParams = EtherConfig | WeiConfig | BaseAccParams;

interface SetNextBlockTimestamp {
  date: string;
  time: string;
}

interface EvmMineParams {
  date: string;
  time: string;
}
export interface IncreaseTimeParams {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export interface HardHatMineParams {
  numberOfBlocks: number;
  interval: number;
}

export interface TimeStampValues {
  date: string;
  time: string;
}

export const setNextBlockTimestamp = async ({
  date,
  time,
}: SetNextBlockTimestamp): Promise<void> => {};

export const evmMine = async ({
  date,
  time,
 }: EvmMineParams): Promise<void> => {};

export const increaseTime = async ({ time }: AccParams): Promise<void> => {};

export const setAccBalance = async ({
  hexAccAddress,
  balance,
}: AccParams): Promise<number> => {
  return 200; //placeholder return
};

export const ImpersonateAccount = async ({
  hexAccAddress,
}: AccParams): Promise<void> => {};

export const StopImpersonateAccout = async ({
  hexAccAddress,
}: AccParams): Promise<void> => {};

export const mineTo = async (
  date: string,
  interval: number
): Promise<void> => {};

export interface AutomineParameters
{
  func:string,
  state?:Boolean;
}
export interface  get_Automine  extends AutomineParameters
{
  func:"get";
}
export interface  set_Automine_t  extends AutomineParameters
{
  func:"set";
  state:true;
}
export interface  set_Automine_f  extends AutomineParameters
{
  func:"set";
  state:false;
}

export interface  interval  
{
  interval:number;
}


export type Interval_Mining =interval;

export type AutomineParams = get_Automine | set_Automine_t |set_Automine_f ;

export const Automine = async ({
  func: string,
  state: Boolean,}
    : AutomineParameters): Promise<void> => { };
