import { AccParams, SendTransParams, IncreaseTimeParams } from "./Types/types";
//import { ethers } from "hardhat";
import { int } from "hardhat/internal/core/params/argumentTypes";
import { providers } from "ethers";


export async function debugSendTransaction(prms: SendTransParams) {
  console.log("function imported");
  //check that from account has enough balance
  console.log(prms);
  const { from, to, amount, type, debug } = prms;
  const sig = await hre.ethers.getSigner(from);
  const fromBalance = hre.ethers.utils.formatEther(await sig.getBalance());
  console.log("balance : " + fromBalance);
  const x = { hexAccAddress: from };
  hre.newplugin.ImpersonateAccount(x); //impersonate the accounts
  console.log("signer  " + sig.address);
  console.log(` acc balance ${await sig.getBalance()}    amount:  ${amount}     
    can Transfer: ${fromBalance - amount > 0} `); //>= 0
  if (fromBalance - amount <= 0) {
    //check gas price?
    console.log("transfer amount cannot be <= 0: throw error");
    return true; //return true as params have error
  }
  //check amount is not 0
  //if(await from.getBalance())
  return false;
  //3. check account string is not 0

  //additional logging?
  //check params, eg amount is not 0
}

export async function IncreaseTimePrmsCheck(prms: IncreaseTimeParams) {
  const { days, hours, minutes, seconds } = prms;
  if (days < 0 || hours < 0 || minutes < 0 || seconds < 0) {
    throw "Increase time params for day/hours/minutes/seconds cannot be negative numbers, thrown in util/IncreaseTimePrmsCheck";
  }
}

// Validates that the input string is a valid date formatted as "yyyy-mm-dd"
export function isValidDate(dateString: string) {
  // First check for the pattern
  if (!/^\d{4}\-\d{1,2}\-\d{1,2}$/.test(dateString)) return false;

  // Parse the date parts to integers
  const parts = dateString.split("-");
  const day = parseInt(parts[2], 10);
  const month = parseInt(parts[1], 10);
  const year = parseInt(parts[0], 10);

  // Check the ranges of month and year
  if (year < 1000 || year > 3000 || month == 0 || month > 12) return false;

  const monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  // Adjust for leap years
  if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
    monthLength[1] = 29;

  // Check the range of the day
  return day > 0 && day <= monthLength[month - 1];
}

export function isValidTime(timeString: string) {
  // First check for the pattern
  if (!/^\d{1,2}\:\d{2}\:\d{2}$/.test(timeString)) return false;

  // Parse the date parts to integers
  const parts = timeString.split(":");
  const Hours = parseInt(parts[0], 10);
  const Minutes = parseInt(parts[1], 10);
  const Seconds = parseInt(parts[2], 10);
  // Check the ranges of month and year
    if (
        Hours < 0 ||
        Hours > 24 ||
        Minutes < 0 ||
        Minutes > 60 ||
        Seconds < 0 ||
        Seconds > 60
    ) {
        return false;
    }
  // Check the range of the day
  return true; //Hours * 3600 + Minutes * 60 + Seconds;
}

//check If okay to modify Isvalid functions to output an int of the number of seconds for that timestamp (more valuable than true/false)
export function DateTimeBuilder(dateString: string, timeString: string) {
  const dateparts = dateString.split("-");
  const day = parseInt(dateparts[2], 10);
  const month = parseInt(dateparts[1], 10) - 1; //Months start at 0
  const year = parseInt(dateparts[0], 10);
  
  const timeparts = timeString.split(":");
  const Hours = parseInt(timeparts[0], 10);
  const Minutes = parseInt(timeparts[1], 10);
  const Seconds = parseInt(timeparts[2], 10);
  
  const finaldate = new Date(year, month, day, Hours, Minutes, Seconds);
  
  return finaldate.getTime();
}

// Helper function to create a date string using current year, month [0-11] and day
export function testDateString(testDate : Date){
  const str = `${testDate.getFullYear()}-${testDate.getMonth()+1}-${testDate.getDate()}`;
  return str;
}