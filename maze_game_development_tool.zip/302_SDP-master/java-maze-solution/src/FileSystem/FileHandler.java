package FileSystem;

import main.*;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;


public class FileHandler {
    public FileHandler(MazeGridPanel grid) {
        String path = "/maze-save-objects"; //current directory
        writeObjectToFile(grid);
    }

    /***
     *
     * @return retrieve a maze object from file
     */
    public static MazeGridPanel retrieveFromFile() {
        try {
            FileInputStream fi = new FileInputStream(new File("myObjects.txt"));
            ObjectInputStream oi = new ObjectInputStream(fi);
            // Read objects
            MazeGridPanel pr1 = (MazeGridPanel) oi.readObject();
            oi.close();
            fi.close();
            return pr1;
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        } catch (IOException e) {
            System.out.println("Error initializing stream");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }


    /***
     *
     * @param grid writer MazeGridPanel object to file
     */
    public static void writeObjectToFile(MazeGridPanel grid) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(new File("myObjects.txt"));
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            // Write objects to file
            objectOutputStream.writeObject(grid);
            //closes stream
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
            System.out.println(e.getCause());
        } catch (IOException e) {
            System.out.println(e);
            System.out.println(e.getCause());
        }
    }
}
