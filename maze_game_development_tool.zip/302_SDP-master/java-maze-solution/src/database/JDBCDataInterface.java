package database;

import main.MazeGridPanel;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicReference;



/**
 * Class for retrieving data from the XML file holding the address list.
 */
public class JDBCDataInterface implements DataInterface {
   public static AtomicReference<MazeGridPanel> newGrid;

   public static final String CREATE_TABLE =
           "CREATE TABLE IF NOT EXISTS mazes ("
                   + "idx INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE," // from https://stackoverflow.com/a/41028314
                   + "name VARCHAR(30) NOT NULL,"
                   + "author VARCHAR(30),"
                   + "lastEdited VARCHAR(20),"
                   + "date VARCHAR(10),"
                   + "blob VARBINARY(7500)," //saves maze object
                   + "screenshot VARBINARY(7500)" + ");";



  private static final String INSERT_MAZE = "INSERT INTO mazes (name, author, lastEdited, date, blob, screenshot) VALUES (?, ?, ?, ?, ?, ?);";

   private static final String GET_NAMES = "SELECT name FROM mazes";

   private static final String GET_LAST_EDITS = "SELECT lastEdited FROM mazes";

   private static final String GET_DATES = "SELECT date FROM mazes";

   private static final String GET_AUTHORS = "SELECT author FROM mazes";

   private static final String GET_MAZE = "SELECT * FROM mazes WHERE name=?";

   private static final String DELETE_MAZE = "DELETE FROM mazes WHERE name=?";

   private static final String COUNT_ROWS = "SELECT COUNT(*) FROM mazes";

   private static final String GET_MAZE_BLOB = "SELECT blob FROM mazes WHERE name=?";
   private static final String GET_SCREENSHOT_BLOB = "SELECT screenshot FROM mazes WHERE name=?";

   private Connection connection;

   private PreparedStatement addMaze;

   private PreparedStatement getNameList;

   private PreparedStatement getLastEditedList;

   private PreparedStatement getAuthorList;

   private PreparedStatement getDateList;

   private PreparedStatement getMaze;

   private PreparedStatement deleteMaze;

   private PreparedStatement loadMaze;
   private PreparedStatement loadScreenshotBytes;

   private PreparedStatement rowCount;

   public JDBCDataInterface() {
      connection = DBConnection.getInstance();
      try {
         Statement st = connection.createStatement();
         st.execute(CREATE_TABLE);
         addMaze = connection.prepareStatement(INSERT_MAZE);
         getNameList = connection.prepareStatement(GET_NAMES);
         getLastEditedList = connection.prepareStatement(GET_LAST_EDITS);
         getAuthorList = connection.prepareStatement(GET_AUTHORS);
         getDateList = connection.prepareStatement(GET_DATES);
         getMaze = connection.prepareStatement(GET_MAZE);
         deleteMaze = connection.prepareStatement(DELETE_MAZE);
         rowCount = connection.prepareStatement(COUNT_ROWS);
         loadMaze = connection.prepareStatement("SELECT blob FROM mazes WHERE name='testingLoad'");
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

   /**

    */
   public void addMaze(Maze maze) {
      try {
         addMaze.setString(1, maze.getName());
         addMaze.setString(2, maze.getAuthor());
         addMaze.setString(3, maze.getLastEdited());
         addMaze.setString(4, maze.getDate());
         System.out.println(maze.getMazeData());
         byte [] testByteArray = new byte[100]; //test that 10 is being saved. this line with DB GUI tool proves bytes are being saved
         addMaze.setBytes(5, maze.getMazeData()); //successfully sets maze data bytes
         addMaze.setBytes(6, maze.getScreenshotData());

         addMaze.execute();
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

   public byte[][] exportPicBytes(List selectedValuesList) {
      System.out.println(selectedValuesList);
      byte[][] test = new byte[selectedValuesList.size()][];
      for (int i = 0; i < test.length; i++){
         //get selected value
         String value = (String) selectedValuesList.get(i);
         //query db for BLOB column for that selected name
         byte[] singleImgBytes = queryImgBytes(value);
         //add results in correct table position
         test[i] = singleImgBytes;
      }
      return test;
   }

   private byte[] queryImgBytes(String value){
      byte[] arr = new byte[0];
      try{
         Statement statement = connection.createStatement();
         ResultSet resultSet = statement.executeQuery("SELECT screenshot FROM mazes WHERE name='"+value+"'"); //TODO does not work. result set == null. Trying to query bytes that exist in the

         System.out.println("testing");
         while(resultSet.next()){
            System.out.println(resultSet.getBytes("screenshot"));
            arr = resultSet.getBytes("screenshot"); //blob col should be blob object
            return arr;
         }
      } catch (SQLException e) {
         e.printStackTrace();
      }

      return arr;
   }

   public AtomicReference <MazeGridPanel> loadMaze(String name) {
        try {
         Statement statement = connection.createStatement();
         ResultSet resultSet = statement.executeQuery("SELECT blob FROM mazes WHERE name='"+name+"'");
                  while(resultSet.next()){
            byte[] arr = resultSet.getBytes("blob"); //email col should be blob object
            ByteArrayInputStream bais = new ByteArrayInputStream(arr);
            ObjectInputStream ois = null;
            try {
               ois = new ObjectInputStream(bais);
               newGrid = (AtomicReference<MazeGridPanel>) ois.readObject();
               return newGrid;
            } catch (IOException | ClassNotFoundException e) {
               e.printStackTrace();
            }
         }
      } catch (SQLException e) {
         e.printStackTrace();
      }
      return newGrid;
   }

   public Set<String> getDataSets(int index){
      ResultSet rs = null;
      try {
         if(index == 1){
            Set<String> authors = new TreeSet<>();
            rs = getAuthorList.executeQuery(); //get last edited list is query statement
            while (rs.next()) { //loops through result set. loop through all rows.
               authors.add(rs.getString("author")); //for each result. get the name of result
            }
            return authors;
         }else if(index == 2){
            Set<String> dates = new TreeSet<>();
            rs = getDateList.executeQuery(); //get last edited list is query statement
            while (rs.next()) { //loops through result set. loop through all rows.
               dates.add(rs.getString("date")); //for each result. get the name of result
            }
            return dates;
         }else if(index == 3){
            Set<String> lastEdits = new TreeSet<>();
            rs = getLastEditedList.executeQuery(); //get last edited list is query statement
            while (rs.next()) { //loops throgh result set. loop through all rows.
               lastEdits.add(rs.getString("lastEdited")); //for each result. get the name of result
            }
            return lastEdits;
         }

      } catch (SQLException ex) {
         ex.printStackTrace();
      } catch (NullPointerException ex){
         System.out.println(" rs = getLastEditedList Query returned null");
         ex.printStackTrace();
      }

      Set<String> emptySet = new TreeSet<>();
      return emptySet;
   }

   @Override
   /**
    * @see dataExercisenew.AddressBookDataSource#nameSet()
    */
   public Set<String> nameSet() {
      Set<String> names = new TreeSet<String>();
      ResultSet rs = null;

        try {
         rs = getNameList.executeQuery(); //getname list is query statement
         while (rs.next()) { //loops through result set. loop through all rows.
            names.add(rs.getString("name")); //for each result. get the name of result
         }
      } catch (SQLException ex) {
         ex.printStackTrace();
      } catch (NullPointerException ex){
         System.out.println(" rs = getNameList returned null");
         ex.printStackTrace();
      }


      return names;
   }

   public Maze getMaze(String name) {
      Maze maze = new Maze();
      ResultSet rs = null;
      try {
         getMaze.setString(1, name); //prepared get person statement .
         rs = getMaze.executeQuery();
         rs.next();
         maze.setName(rs.getString("name"));
         maze.setAuthor(rs.getString("author"));
         maze.setLastEdited(rs.getString("lastEdited"));
         maze.setDate(rs.getString("date"));
         maze.setBlob(rs.getString("blob"));
      } catch (SQLException ex) {
         ex.printStackTrace();
      }

      return maze;
   }

   /**
    *
    */
   public int getSize() {
      ResultSet rs = null;
      int rows = 0;

      try {
         rs = rowCount.executeQuery();
         rs.next();
         rows = rs.getInt(1);
      } catch (SQLException ex) {
         ex.printStackTrace();
      }

      return rows;
   }

   public void deleteMaze(String name) {
      try {
         deleteMaze.setString(1, name);
         deleteMaze.executeUpdate();
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

   /**
    *
    */
   public void close() {
      try {
         connection.close();
      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }
}
