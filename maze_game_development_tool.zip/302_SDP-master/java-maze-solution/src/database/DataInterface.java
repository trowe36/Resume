package database;

import main.MazeGridPanel;

import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Provides functionality needed by any data source for the database application
 *
 */
public interface DataInterface {

   /**
    * Adds a Maze to the address list, if they are not already in the list
    * 
    * @param maze Maze to add
    */
   void addMaze(Maze maze);

   /**
    * Extracts all the details of a Maze from the database based on the
    * name passed in.
    * 
    * @param name The name as a String to search for.
    * @return all details in a Maze object for the name
    */
   Maze getMaze(String name);

   /**
    * Gets the number of mazes in the database.
    * 
    * @return size of database.
    */
   int getSize();

   /**
    * Deletes a Maze from the database.
    * 
    * @param name The name to delete from the database.
    */
   void deleteMaze(String name);

   /**
    * Finalizes any resources used by the data source and ensures data is
    * persisted.
    */
   void close();

   /**
    * Retrieves a set of names from the data source that are used in
    * the name list.
    * 
    * @return set of names.
    */
   Set<String> nameSet();

   AtomicReference<MazeGridPanel> loadMaze(String name);

   byte[][] exportPicBytes(List selectedValuesList);


   Set<String> getDataSets(int by_author);
}