package database;
import main.GUIHandler;
import main.MazeGridPanel;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * Initiates user interface for the Database application. All listeners for
 * the application are included as inner classes of this class.
 */
public class DatabaseUI extends JFrame {
   private static JPanel detailsPanel;
   private static final long serialVersionUID = -5050538890770582361L;
   private static DatabaseUI field;

   private JList nameList;

   private JTextField name;

   private JTextField author;

   private JTextField lastEdited;


   public static JTextField date = new JTextField(20);

   private JButton newButton;

   private JButton saveButton;

   private JButton deleteButton;

   private JButton loadButton;

   private JButton exportButton;

   DataHandler data;

   /**
    *
    * @param field set the date time for passed JTextField
    */
   private void SetTimeAndDate(JTextField field) {
       DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
      LocalDateTime now = LocalDateTime.now();
      field.setText(dtf.format(now));
   }

   /**
    * Constructor sets up user interface, adds listeners and displays.
    * 
    * @param data The underlying data/model class the UI needs.
    */
   public DatabaseUI(DataHandler data) {
      this.data = data;
      initUI();
      checkListSize();

      // add listeners to interactive components
      addButtonListeners(new ButtonListener());
      addNameListListener(new NameListListener());
      addClosingListener(new ClosingListener());

      // decorate the frame and make it visible
      setTitle("Maze DB");
      setMinimumSize(new Dimension(400, 300));
      pack();
      setVisible(true);

   }

   /**
    * Places the detail panel and the button panel in a box layout with vertical
    * alignment and puts a 20 pixel gap between the components and the top and
    * bottom edges of the frame.
    */
   private void initUI() {
      Container contentPane = this.getContentPane();
      contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));


      contentPane.add(Box.createVerticalStrut(20));
      contentPane.add(makeDetailsPanel());
      contentPane.add(Box.createVerticalStrut(20));
      contentPane.add(makeButtonsPanel());
      contentPane.add(Box.createVerticalStrut(20));



   }

   /**
    * Makes a JPanel consisting of list of maze names
    * fields in a box layout with horizontal alignment and puts a 20 pixel gap
    * between the components and the left and right edges of the panel.
    * 
    * @return the detail panel.
    */
   private JPanel makeDetailsPanel() {
      detailsPanel = new JPanel();
      detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.X_AXIS));
      detailsPanel.add(Box.createHorizontalStrut(20));
      detailsPanel.add(makeNameListPane());
      detailsPanel.add(Box.createHorizontalStrut(20));
      detailsPanel.add(makeMazeFieldsPanel());
      detailsPanel.add(Box.createHorizontalStrut(20));
      return detailsPanel;
   }

   /**
    * Makes a JScrollPane that holds a JList for the list of names in the
    * data base.
    * 
    * @return the scrolling name list panel
    */
   private JScrollPane makeNameListPane() {

      nameList = new JList(data.getModel());

      nameList.setFixedCellWidth(200);

      JScrollPane scroller = new JScrollPane(nameList);
      scroller.setViewportView(nameList);
      scroller
            .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
      scroller
            .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
      scroller.setMinimumSize(new Dimension(200, 150));
      scroller.setPreferredSize(new Dimension(250, 150));
      scroller.setMaximumSize(new Dimension(250, 200));

      return scroller;
   }

   /**
    * Makes a JPanel containing labels and textfields for each of the pieces of
    * data that are to be recorded for each maze. The labels and fields are
    * layed out using a GroupLayout, with the labels vertically grouped, the
    * fields vertically grouped and each label/group pair horizontally grouped.
    * 
    * @return a panel containing the maze detail fields
    */
   private JPanel makeMazeFieldsPanel() {
      JPanel mazePanel = new JPanel();
      GroupLayout layout = new GroupLayout(mazePanel);
      mazePanel.setLayout(layout);

      // Turn on automatically adding gaps between components
      layout.setAutoCreateGaps(true);

      // Turn on automatically creating gaps between components that touch
      // the edge of the container and the container.
      layout.setAutoCreateContainerGaps(true);

      JLabel nameLabel = new JLabel("Name");
      JLabel authorLabel = new JLabel("Author");
      JLabel lastEditedLabel = new JLabel("LastEdited");
      JLabel dateLabel = new JLabel("Date");


      name = new JTextField(20);
      author = new JTextField(20);
      lastEdited = new JTextField(20);
      date = new JTextField(20);

      setFieldsEditable(false);

      // Create a sequential group for the horizontal axis.
      GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

      // The sequential group in turn contains two parallel groups.
      // One parallel group contains the labels, the other the text fields.
      hGroup.addGroup(layout.createParallelGroup().addComponent(nameLabel)
            .addComponent(authorLabel).addComponent(lastEditedLabel).addComponent(
                  dateLabel));
      hGroup.addGroup(layout.createParallelGroup().addComponent(name)
            .addComponent(author).addComponent(lastEdited).addComponent(date));
      layout.setHorizontalGroup(hGroup);

      // Create a sequential group for the vertical axis.
      GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

      // The sequential group contains five parallel groups that align
      // the contents along the baseline. The first parallel group contains
      // the first label and text field, and the second parallel group contains
      // the second label and text field etc. By using a sequential group
      // the labels and text fields are positioned vertically after one another.
      vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
            .addComponent(nameLabel).addComponent(name));

      vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
            .addComponent(authorLabel).addComponent(author));
      vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
            .addComponent(lastEditedLabel).addComponent(lastEdited));
      vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE)
            .addComponent(dateLabel).addComponent(date));
      vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE));
      layout.setVerticalGroup(vGroup);

      return mazePanel;
   }

   /**
    * Adds the buttons to a panel
    */
   private JPanel makeButtonsPanel() {
      JPanel buttonPanel = new JPanel();
      buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
      newButton = new JButton("New");
      saveButton = new JButton("Save");
      saveButton.setEnabled(false);
      deleteButton = new JButton("Delete");
      loadButton = new JButton("Load Maze"); //TODO set enabled == false. then when a maze is selected in db. enable. to load that maze etc.
      exportButton = new JButton("Export");
      buttonPanel.add(Box.createHorizontalStrut(20));
      buttonPanel.add(newButton);
      buttonPanel.add(Box.createHorizontalStrut(20));
      buttonPanel.add(saveButton);
      buttonPanel.add(Box.createHorizontalStrut(20));
      buttonPanel.add(deleteButton);
      buttonPanel.add(Box.createHorizontalStrut(20));
      buttonPanel.add(loadButton);
      buttonPanel.add(Box.createHorizontalStrut(20));
      buttonPanel.add(exportButton);

      JMenuBar dbMenuBar = new JMenuBar();
      JMenu sortEntries = new JMenu("Sort Entries By");
      JMenuItem name = new JMenuItem("Name");
      JMenuItem date = new JMenuItem("Date");
      JMenuItem lastEdited = new JMenuItem("lastEdited");
      JMenuItem author = new JMenuItem("Author");

      sortEntries.add(name);
      sortEntries.add(date);
      sortEntries.add(lastEdited);
      sortEntries.add(author);

      dbMenuBar.add(sortEntries);

      JMenu exportOptions = new JMenu("Export Options");
      JMenuItem defaultExport = new JMenuItem("Default");
      JMenuItem exportWithSolution = new JMenuItem("With Solution");
      JMenuItem exportWithoutSolution = new JMenuItem("WithoutSolution");

      exportOptions.add(defaultExport);
      exportOptions.add(exportWithoutSolution);
      exportOptions.add(exportWithSolution);

      dbMenuBar.add(exportOptions);

      setJMenuBar(dbMenuBar);

      name.addActionListener(event -> {
   makeNameListPane(1);
      });

      date.addActionListener(event -> {
         makeNameListPane(2);
      });

      lastEdited.addActionListener(event -> {
         makeNameListPane(3);
      });

      author.addActionListener(event -> {
         makeNameListPane(4);
      });
      return buttonPanel;
   }

   private JScrollPane makeNameListPane(int i) {
      if(i == 1){
         data.setAlpha();
      }
      else if(i == 2){
         data.orderByDate();
      }
      else if(i == 3){
         data.orderByLastEdited();
      }
      else if(i == 4){
         data.orderByAuthor();
      }

      nameList = new JList(data.getModel());

      nameList.setFixedCellWidth(200);

      JScrollPane scroller = new JScrollPane(nameList);
      scroller.setViewportView(nameList);
      scroller
              .setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
      scroller
              .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
      scroller.setMinimumSize(new Dimension(200, 150));
      scroller.setPreferredSize(new Dimension(250, 150));
      scroller.setMaximumSize(new Dimension(250, 200));

      return scroller;
   }

   /**
    * Adds a listener to the buttons
    */
   private void addButtonListeners(ActionListener listener) {
      newButton.addActionListener(listener);
      saveButton.addActionListener(listener);
      deleteButton.addActionListener(listener);
      loadButton.addActionListener(listener);
      exportButton.addActionListener(listener);
   }

   /**
    * Adds a listener to the name list 
    */
   private void addNameListListener(ListSelectionListener listener) {

      nameList.addListSelectionListener(listener);

   }

   /**
    * Adds a listener to the JFrame 
    */
   private void addClosingListener(WindowListener listener) {
      addWindowListener(listener);
   }

   /**
    * Sets the text in the text fields to the empty string.
    */
   private void clearFields() {
      name.setText("");
      author.setText("");
      lastEdited.setText("");
      date.setText("");
   }

   /**
    * Sets the address fields to be editable.
    */
   private void setFieldsEditable(boolean editable) {
      name.setEditable(editable);
      author.setEditable(editable);
      lastEdited.setEditable(editable);
      date.setEditable(false);
   }

   /**
    * Displays the details of a Maze in the address fields.
    * @param maze the Maze to display.
    */
   private void display(Maze maze) {
      if (maze != null) {
         name.setText(maze.getName());
         author.setText(maze.getAuthor());
         lastEdited.setText(maze.getLastEdited());
         date.setText(maze.getDate());
      }
   }

   /**
    * Checks size of data/model and enables/disables the delete button
    * 
    */
   private void checkListSize() {
      deleteButton.setEnabled(data.getSize() != 0);
   }

   /**
    * Handles events for the three buttons on the UI.
    */
   private class ButtonListener implements ActionListener {

      /**
       * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
       */
      public void actionPerformed(ActionEvent e) {
         int size = data.getSize();

         JButton source = (JButton) e.getSource();
         if (source == newButton) {
            newPressed();
         } else if (source == saveButton) {
            savePressed();
         } else if (source == deleteButton) {
            deletePressed();
         } else if (source == loadButton){
            loadButtonPressed();
         } else if (source == exportButton) {
            exportPressed();
         }
      }

      /**
       * When the new button is pressed, clear the field display, make them
       * editable and enable the save button.
       */
      private void newPressed() {
         clearFields();
         setFieldsEditable(true);
         saveButton.setEnabled(true);
         SetTimeAndDate(date);

      }


      private void loadButtonPressed(){
         if (name.getText() != null && !name.getText().equals("")) {
            AtomicReference<MazeGridPanel> mazeLoad = data.getLoadContents(name.getText());
            GUIHandler.reloadGUI(mazeLoad);
         }
      }
      /**
       * When the save button is pressed, check that the name field contains
       * something. If it does, create a new Maze object and attempt to add it
       * to the data model. Change the fields back to not editable and make the
       * save button inactive.
       * 
       * Check the list size to see if the delete button should be enabled.
       */
      private void savePressed() {
         if (name.getText() != null && !name.getText().equals("")) {
            byte[] mazeData = GUIHandler.getMazeData();
            byte[] screenshotData = GUIHandler.screenshotData();
            String lastOpen = getDate();
            System.out.println("last open: " + lastOpen);
            if(mazeData != null){
               Maze p = new Maze(name.getText(), author.getText(), lastOpen, date.getText(), mazeData, screenshotData);
               data.add(p);
            }
         }
         setFieldsEditable(false);
         SetTimeAndDate(lastEdited);
         saveButton.setEnabled(false);
         checkListSize();
      }

      private String getDate(){
         Date date = Calendar.getInstance().getTime();
         DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
         String strDate = dateFormat.format(date);
         return strDate;
      }

      /**
       * When the delete button is pressed remove the selected name from the
       * data model.
       * 
       * Clear the fields that were displayed and check to see if the delete
       * button should be displayed.
       * 
       * The index here handles cases where the first element of the list is
       * deleted.
       */
      private void deletePressed() {
         int index = nameList.getSelectedIndex();
         data.remove(nameList.getSelectedValue());
         clearFields();
         index--;
         if (index == -1) {
            if (data.getSize() != 0) {
               index = 0;
            }
         }
         nameList.setSelectedIndex(index);
         checkListSize();
      }

      private void exportPressed() {
         int imgCount = nameList.getSelectedValuesList().size();

         byte[][] imgsAsBytes = new byte[imgCount][];
         imgsAsBytes = data.export(nameList.getSelectedValuesList());
         GUIHandler.byteArrayImgExport(imgsAsBytes, nameList.getSelectedValuesList());
      }
   }

   /**
    * Implements a ListSelectionListener for making the UI respond when a
    * different name is selected from the list.
    */
   private class NameListListener implements ListSelectionListener {

      /**
       * @see javax.swing.event.ListSelectionListener#valueChanged(javax.swing.event.ListSelectionEvent)
       */
      public void valueChanged(ListSelectionEvent e) {
         if (nameList.getSelectedValue() != null
               && !nameList.getSelectedValue().equals("")) {
            display(data.get(nameList.getSelectedValue()));
         }
      }
   }

   /**
    * Implements the windowClosing method from WindowAdapter/WindowListener to
    * persist the contents of the data/model.
    */
   private class ClosingListener extends WindowAdapter {

      /**
       * @see java.awt.event.WindowAdapter#windowClosing(java.awt.event.WindowEvent)
       */
      public void windowClosing(WindowEvent e) {
         data.persist();
         setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
      }
   }
}
