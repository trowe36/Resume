package database;

import main.MazeGridPanel;

import javax.swing.DefaultListModel;
import javax.swing.ListModel;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

/**
 * This version uses an DataInterface and its methods to retrieve data
 */
public class DataHandler {

   DefaultListModel listModel;

   DataInterface mazeData;

   /**
    * Constructor initializes the list model that holds names as Strings and
    * attempts to read any data saved from previous invocations of the
    * application.
    * 
    */
   public DataHandler() {
      listModel = new DefaultListModel();

      mazeData = new JDBCDataInterface();

      for (String name : mazeData.nameSet()) {
         listModel.addElement(name);
      }
   }

   public void setAlpha() {
   List<String> tmpList = new ArrayList<>();
   for (String name : mazeData.nameSet()){
      tmpList.add(name);
   }
      Collections.sort(tmpList, String.CASE_INSENSITIVE_ORDER);

   Set<String> namesOrder = new TreeSet<String>();
   namesOrder = mazeData.nameSet();
   String arr[] = new String[namesOrder.size()];
   arr = namesOrder.toArray(arr);

      this.listModel.clear();
   for (int i = 0; i < tmpList.size(); i++){
      for (int j = 0; j<arr.length; j++){
         if(arr[j].equals(tmpList.get(i))){
               this.listModel.insertElementAt(tmpList.get(i), i);

            break;
         }
      }
   }

   }
   final int By_AUTHOR = 1;
   final int BY_DATE = 2;
   final int BY_LAST_EDITED = 3;

   public void orderByAuthor(){
      Set<String> authorSet = mazeData.getDataSets(By_AUTHOR);
      for(String author : authorSet){
         System.out.println(author);
      }
      //same as alpha but with author
   }
   public void orderByDate(){
      //set of dates
      Set<String> dateSet = mazeData.getDataSets(BY_DATE);
      for(String date : dateSet){
         System.out.println(date);
      }
      //create a list of corresponding names
      List<String> tmpList = new ArrayList<>();
      for (String name : mazeData.nameSet()){
         tmpList.add(name);
      }

      for(int i = 0; i < dateSet.size(); i++){

      }

   }

   public void orderByLastEdited() {
      //create set of maze names
      Set<String> mazes = new TreeSet<String>();
      mazes = mazeData.nameSet();
      System.out.println(mazes);
      //convert to array
      String arr[] = new String[mazes.size()];
      arr = mazes.toArray(arr);
      System.out.print(arr);

      Set<String> lastEditedSet = mazeData.getDataSets(BY_LAST_EDITED);
      for(String lastEdit : lastEditedSet){
         System.out.println(lastEdit);
      }

   }

   /**
    * Adds a person to the address book.
    * 
    * @param p A Maze to add to the address book.
    */
   public void add(Maze p) {

      // check to see if the person is already in the book
      // if not add to the address book and the list model
      if (!listModel.contains(p.getName())) {
         listModel.addElement(p.getName());
         mazeData.addMaze(p);
      }
   }
   public AtomicReference<MazeGridPanel> getLoadContents(String name) {
      return mazeData.loadMaze(name);
   }

   public byte[][] export(List selectedValuesList) {
      return(mazeData.exportPicBytes(selectedValuesList));
   }

   /**
    * Based on the name of the person in the address book, delete the person.
    * 
    * @param key
    */
   public void remove(Object key) {
      // remove from both list and map
      listModel.removeElement(key);
      mazeData.deleteMaze((String) key);
   }

   /**
    * Saves the data in the address book using a persistence
    * mechanism.
    */
   public void persist() {
      mazeData.close();
   }

   /**
    * Retrieves Maze details from the model.
    * 
    * @param key the name to retrieve.
    * @return the Maze object related to the name.
    */
   public Maze get(Object key) {
      return mazeData.getMaze((String) key);
   }

   /**
    * Accessor for the list model.
    * 
    * @return the listModel to display.
    */
   public ListModel getModel() {
      return listModel;
   }

   /**
    * @return the number of names in the Address Book.
    */
   public int getSize() {
      return mazeData.getSize();
   }
}
