package database;

import javax.swing.SwingUtilities;


/**
 * Invokes the database application.
 */
public class Database {
   
   /**
    * Create the GUI.  For thread safety,
    * this method should be invoked from the
    * event-dispatching thread.
    */
   private static void createAndShowGUI() {
      new DatabaseUI(new DataHandler());
   }

   /**
    * Run DB
    */
   public static void runDB() { //main method
       //Schedule a job for the event-dispatching thread:
       //creating and showing this application's GUI.
       SwingUtilities.invokeLater(new Runnable() {
           public void run() {
               createAndShowGUI();
           }
       });
   }
}
