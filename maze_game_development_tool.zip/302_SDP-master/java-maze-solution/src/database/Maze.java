package database;

import java.io.Serializable;

/**
 * Stores address details for a person.
 */
public class Maze implements Comparable<Maze>, Serializable {

   private static final long serialVersionUID = -7092701502990374424L;

   private String name;

   private String author;

   private String lastEdited;

   private String date;

   private byte[] mazeData;
   private byte[] screenshotData;

   private String blob;

   /**
    * No args constructor.
    */
   public Maze() {
   }

   /**
    * Constructor to set values for the Maze's details.
    * @param name
    * @param author
    * @param lastEdited
    * @param date
//    * @param email
    */
   public Maze(String name, String author, String lastEdited, String date, byte[] mazeData, byte[] screenshot) {
      this.name = name; 
      this.author = author;
      this.lastEdited = lastEdited;
      this.date = date;
      this.mazeData = mazeData;
      this.screenshotData = screenshot;
      //this.screenshot = screenshot;
      //this.email = email;
   }

   /**
    * @return the email
    */
   public String getBlob() {
      return blob;
   }
   public byte[] getMazeData(){return mazeData; }
   public byte[] getScreenshotData() {return screenshotData;}
   /**
    * @param blob the email to set
    */
   public void setBlob(String blob) {
      this.blob = blob;
   }

   /**
    * @return the name
    */
   public String getName() {
      return name;
   }

   /**
    * @param name the name to set
    */
   public void setName(String name) {
      this.name = name;
   }

   /**
    * @return the date
    */
   public String getDate() {
      return date;
   }

   /**
    * @param date the date to set
    */
   public void setDate(String date) {
      this.date = date;
   }

   /**
    * @return the author
    */
   public String getAuthor() {
      return author;
   }

   /**
    * @param author the author to set
    */
   public void setAuthor(String author) {
      this.author = author;
   }

   /**
    * @return the lastEdited
    */
   public String getLastEdited() {
      return lastEdited;
   }

   /**
    * @param lastEdited the lastEdited to set
    */
   public void setLastEdited(String lastEdited) {
      this.lastEdited = lastEdited;
   }

   /**
    * Compares this object with the specified object for order. Returns a
    * negative integer, zero, or a positive integer as this object is less than,
    * equal to, or greater than the specified object.
    * 
    * @param other The other Maze object to compare against.
    * @return a negative integer, zero, or a positive integer as this object is
    *         less than, equal to, or greater than the specified object.
    * @throws ClassCastException if the specified object's type prevents it from
    *            being compared to this object.
    */
   public int compareTo(Maze other) {
      return this.name.compareTo(other.name);
   }
   
   /**
    * @see java.lang.Object#toString()
    */
   public String toString() {
      return name + " " + author + ", " + lastEdited + " " + date + " " + blob;
   }


}
