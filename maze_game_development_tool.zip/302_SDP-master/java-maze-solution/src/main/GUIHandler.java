package main;

import FileSystem.FileHandler;
import database.Database;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import static javax.swing.JOptionPane.*;

public class GUIHandler{
    private static AtomicReference<MazeGridPanel> grid;
    private static final String[] GENERATION_METHODS = {"1. DFS" };
    private static final String[] SOLVING_METHODS = {"1. DFS"};
    private  static boolean toggle = true;

    public static int
            xDimensionValue = 10;
    public static int yDimensionValue = 10;

    public static int screenWidth;
    public static int screenHeight;
    public static JPanel mazeBorder;
    public static JPanel container;
    public static AtomicReference<MazeGridPanel> newMazeLoad;
    public static boolean loadState = false;

    //current frame. static. only one copy of GUI Maze at a time. used in screenshotdata()
    private static JFrame currentFrame;

    public static void reloadGUI(AtomicReference<MazeGridPanel> newGrid){
        loadState = true;
        createAndShowNewGUI(newGrid.get().WIDTH, newGrid.get().getRows(), newGrid.get().getCols(), newGrid.get().HEIGHT, newGrid);
    }

public static void createAndShowNewGUI(int WIDTH, int rows, int cols, int HEIGHT, AtomicReference<MazeGridPanel> newGrid){
    JFrame frame = new JFrame("Java Mazes");
    //menu bar below
    JMenuBar menuBar = new JMenuBar();
    // create a menu
    JMenu menu = new JMenu("Menu");
    // Settings menu & Items
    JMenu edit = new JMenu("Edit");

    JMenuItem selectLogo = new JMenuItem("Select logo");
    JMenuItem autoPlaceLogo = new JMenuItem("Automatically place logo");
    JMenuItem manuallyPlaceLogo = new JMenuItem("Manually place logo");
    JMenuItem newMaze = new JMenuItem(("New Maze"));

    SpinnerModel xDimensionModel = new SpinnerNumberModel(xDimensionValue, 0, 100, 1);
    SpinnerModel yDimensionModel = new SpinnerNumberModel(yDimensionValue, 0, 100, 1);

    JSpinner xDimension = new JSpinner(xDimensionModel);
    JSpinner yDimension = new JSpinner(yDimensionModel);

    // create menuitems
    JMenuItem saveButton = new JMenuItem("Database");
    JMenuItem retrieveButton = new JMenuItem("Retrieve-Maze");
    JMenuItem checkFileSysButton = new JMenuItem("Check maze file system");
    JMenuItem exportButton = new JMenuItem("Export");

    JMenuItem difficultyButton = new JMenuItem("Difficulty");
    JMenuItem screenshotButton = new JMenuItem("Screenshot and export");

    // add menu items to menu
    menu.add(saveButton);
    menu.add(retrieveButton);
    menu.add(checkFileSysButton);
    menu.add(exportButton);
    menu.add(difficultyButton);
    menu.add(screenshotButton);
    menu.add(newMaze);

    edit.add(selectLogo);
    edit.add(autoPlaceLogo);
    edit.add(manuallyPlaceLogo);

    menuBar.add(menu);
    menuBar.add(edit);

    frame.setJMenuBar(menuBar);

    GraphicsConfiguration gc = frame.getGraphicsConfiguration();
    Rectangle bounds = gc.getBounds();
    screenWidth = bounds.width;
    screenHeight = bounds.height;
    Insets ins = Toolkit.getDefaultToolkit().getScreenInsets(gc);
    screenHeight -= ins.bottom + ins.top;
    screenWidth -= ins.left + ins.right;


    exportButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            showMessageDialog(menuBar, "Maze Successfully Exported.");
        }
    });

    difficultyButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            showMessageDialog(menuBar, getDifficultyMsg());
        }
    });

    screenshotButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            BufferedImage img = screenshotImg(frame);
            exportImg(img);
            byte[] imgAsBytes = imgToBytes(img);
            if (imgAsBytes != null) {
                //print to test saved as bytes
                for (int i = 0; i < imgAsBytes.length; i++) {
                    System.out.print(imgAsBytes[i]);
                }
            } else {
                System.out.printf("there were no bytes in picture byte array");
            }
        }
    });

    checkFileSysButton.addActionListener(event -> {
               new BrowseImage();
    });



    container = new JPanel();
    container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
    frame.setContentPane(container);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //added if statement to handle loadLogic. see top method
    grid = newGrid;
    Maze.generated = grid.get().getGenerated();
    Maze.solved = grid.get().getSolved();

    grid.get().setBackground(Color.BLACK);

    mazeBorder = new JPanel();
    final int BORDER_SIZE = 5;
    GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
    int borderWidthCenter = (gd.getDisplayMode().getWidth())/2;


    mazeBorder.setBounds(0, 0, WIDTH + BORDER_SIZE, HEIGHT + BORDER_SIZE);
    mazeBorder.setBackground(Color.BLACK);
    mazeBorder.setBorder(BorderFactory.createEmptyBorder(BORDER_SIZE, borderWidthCenter, 0, 5));

    mazeBorder.add(grid.get());

    container.add(mazeBorder);

    CardLayout cardLayout = new CardLayout();

    JButton runButton = new JButton("Run");
    JButton solveButton = new JButton("Solve");
    JButton resetButton = new JButton("Reset");
    JButton solveAgainButton = new JButton("Toggle Solution");
    JButton saveSolutionButton = new JButton("Save Solution");


    JTextArea mazeDetails = new JTextArea("Maze details:"+
            "\nMaze Loaded : " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"))+
            "\nSolved: true");

    mazeDetails.setEditable(false);


    JComboBox<String> genMethodsComboBox= new JComboBox<>(GENERATION_METHODS);
    JComboBox<String> solveMethodsComboBox = new JComboBox<>(SOLVING_METHODS);

    genMethodsComboBox.setMaximumRowCount(genMethodsComboBox.getModel().getSize());
    solveMethodsComboBox.setMaximumRowCount(solveMethodsComboBox.getModel().getSize());

    Hashtable<Integer, JLabel> labels = new Hashtable<Integer, JLabel>();
    labels.put(1, new JLabel("Fast"));
    labels.put(40, new JLabel("Slow"));

    // Create the card panels.
    JPanel card1 = new JPanel();
    JPanel card2 = new JPanel();
    card1.setLayout(new GridBagLayout());
    card2.setLayout(new GridBagLayout());

    GridBagConstraints gridBagConstraints = new GridBagConstraints();

    gridBagConstraints.insets = new Insets(5, 0, 5, 18);
    gridBagConstraints.fill = GridBagConstraints.BOTH;

    gridBagConstraints.gridheight = 2;
    gridBagConstraints.weightx = 0.3;
    gridBagConstraints.gridx = 1;
    gridBagConstraints.gridy = 0;
    card1.add(mazeDetails);
    card1.add(runButton, gridBagConstraints);

    card1.add(xDimension);

    card1.add(yDimension);

    card2.add(solveButton, gridBagConstraints);

    JPanel card3 = new JPanel();
    card3.setLayout(new GridBagLayout());
    gridBagConstraints.gridx = 0;
    gridBagConstraints.gridy = 0;
    card3.add(solveAgainButton, gridBagConstraints);
    gridBagConstraints.gridx = 0;
    gridBagConstraints.gridy = 1;
    card3.add(resetButton, gridBagConstraints);
    gridBagConstraints.gridx = 0;
    gridBagConstraints.gridy = 2;
    card3.add(saveSolutionButton, gridBagConstraints);
    gridBagConstraints.gridx = 0;
    gridBagConstraints.gridy = 3;


    // Create the panel that contains the cards.
    JPanel cards = new JPanel(cardLayout);
    cards.setBorder(new EmptyBorder(0, 20, 0, 0));
    cards.setOpaque(false);
    cards.add(card1, "gen");
    cards.add(card2, "solve");
    cards.add(card3, "reset");

    container.add(cards);
    if(Maze.generated == true){
        cardLayout.next(cards);
    }

    if(Maze.solved){
        cardLayout.next(cards);//go to card three. reset and solve again button
    }

    runButton.addActionListener(event -> {
        if (xDimensionValue != (int) xDimension.getValue() || yDimensionValue != (int) yDimension.getValue()) {
            if (((int) xDimension.getValue() > 100 || 100 < (int) yDimension.getValue()) || ((int) xDimension.getValue() < 1 || 1 > (int) yDimension.getValue())){
                showMessageDialog(frame, "Dimensions must be between 1 and 100", "Dimension Warning", WARNING_MESSAGE);
            }
            else{
                xDimensionValue = (int) xDimension.getValue();
                yDimensionValue = (int) yDimension.getValue();
                frame.dispose();
                try {
                    Maze.W = Maze.getCellSize(yDimensionValue, xDimensionValue);
                    createAndShowGUI(WIDTH, yDimensionValue, xDimensionValue, HEIGHT);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        else if (xDimensionValue ==  (int) xDimension.getValue() && yDimensionValue == (int) yDimension.getValue()){
            Maze.generated = false;
            Maze.solved = false;
            grid.get().setGenerated(false);
            grid.get().setSolved(false);
            grid.get().generate(genMethodsComboBox.getSelectedIndex());
            cardLayout.next(cards);
        }
    });

    newMaze.addActionListener(event -> {
        frame.dispose();
        try {
            yDimensionValue = 10;
            xDimensionValue = 10;
            Maze.W = Maze.getCellSize(yDimensionValue, xDimensionValue);
            new Maze();
        } catch (IOException e) {
            e.printStackTrace();
        }
    });

    retrieveButton.addActionListener(event -> {
        Database.runDB();
    });

    saveSolutionButton.addActionListener(event -> {
        Database.runDB();
    });

    saveButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            Database.runDB();
        }
    });

    solveButton.addActionListener(event -> {
        if (Maze.generated) {
            grid.get().setGenerated(true);
            grid.get().solve();
            cardLayout.last(cards);
        } else {
            showMessageDialog(frame, "Please wait until the maze has been generated.");
        }
    });

    solveAgainButton.addActionListener(event -> {
        if (Maze.solved) {
            // = false;
            if (toggle) {
                grid.get().resetSolution();
                cardLayout.show(cards, "toggle");
                toggle = !toggle;
            } else if (!toggle) {
                grid.get().showSolution(mazeBorder.getGraphics());
                toggle = !toggle;
            }
        } else {
            showMessageDialog(frame, "Please wait until the maze has been solved.");
        }
    });

    resetButton.addActionListener(event -> {
        try {
            frame.dispose();
            createAndShowGUI(WIDTH, rows, cols, HEIGHT);
        } catch (IOException e) {
            e.printStackTrace();
        }
    });
    frame.pack();

    frame.setSize(screenWidth,screenHeight);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
    currentFrame = frame;
}
//this is the mast now
    public static void createAndShowGUI(int WIDTH, int rows, int cols, int HEIGHT) throws IOException {
        JFrame frame = new JFrame("Java Mazes");
        //menu bar below
        JMenuBar menuBar = new JMenuBar();
        // create a menu
        JMenu menu = new JMenu("Menu");
        // Settings menu & Items
        JMenu edit = new JMenu("Edit");

        JMenuItem selectLogo = new JMenuItem("Select logo");
        JMenuItem autoPlaceLogo = new JMenuItem("Automatically place logo");
        JMenuItem manuallyPlaceLogo = new JMenuItem("Manually place logo");
        JMenuItem newMaze = new JMenuItem(("New Maze"));

        SpinnerModel xDimensionModel = new SpinnerNumberModel(xDimensionValue, 0, 100, 1);
        SpinnerModel yDimensionModel = new SpinnerNumberModel(yDimensionValue, 0, 100, 1);

        JSpinner xDimension = new JSpinner(xDimensionModel);
        JSpinner yDimension = new JSpinner(yDimensionModel);

        // create menuitems
        JMenuItem saveButton = new JMenuItem("Database");
        JMenuItem retrieveButton = new JMenuItem("Retrieve-Maze");
        JMenuItem checkFileSysButton = new JMenuItem("Check maze file system");
        JMenuItem exportButton = new JMenuItem("Export");

        JMenuItem difficultyButton = new JMenuItem("Difficulty");
        JMenuItem screenshotButton = new JMenuItem("Screenshot and export");

        // add menu items to menu
        menu.add(saveButton);
        menu.add(retrieveButton);
        menu.add(checkFileSysButton);
        menu.add(exportButton);
        menu.add(difficultyButton);
        menu.add(screenshotButton);
        menu.add(newMaze);

        edit.add(selectLogo);
        edit.add(autoPlaceLogo);
        edit.add(manuallyPlaceLogo);

        menuBar.add(menu);
        menuBar.add(edit);

        frame.setJMenuBar(menuBar);

        GraphicsConfiguration gc = frame.getGraphicsConfiguration();
        Rectangle bounds = gc.getBounds();
        screenWidth = bounds.width;
        screenHeight = bounds.height;
        Insets ins = Toolkit.getDefaultToolkit().getScreenInsets(gc);
        screenHeight -= ins.bottom + ins.top;
        screenWidth -= ins.left + ins.right;

        exportButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showMessageDialog(menuBar, "Maze Successfully Exported.");
            }
        });

        difficultyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                grid.get().setDifficulty();
                showMessageDialog(menuBar, getDifficultyMsg());
            }

        });

        screenshotButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                BufferedImage img = screenshotImg(frame);
                exportImg(img);
                byte[] imgAsBytes = imgToBytes(img);
                if (imgAsBytes != null) {
                    //print to test saved as bytes
                    for (int i = 0; i < imgAsBytes.length; i++) {
                        System.out.print(imgAsBytes[i]);
                    }
                } else {
                    System.out.printf("there were no bytes in picture byte array");
                }
            }
        });

        checkFileSysButton.addActionListener(event -> {
            new BrowseImage();
        });

        container = new JPanel();
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
        frame.setContentPane(container);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        grid = new AtomicReference<>(new MazeGridPanel(rows, cols));

        grid.get().setBackground(Color.BLACK);

        mazeBorder = new JPanel();
        final int BORDER_SIZE = 5;
        GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        int borderWidthCenter = (gd.getDisplayMode().getWidth())/2;

        mazeBorder.setBounds(0, 0, WIDTH + BORDER_SIZE, HEIGHT + BORDER_SIZE);
        mazeBorder.setBackground(Color.BLACK);
        mazeBorder.setBorder(BorderFactory.createEmptyBorder(BORDER_SIZE, borderWidthCenter, 0, 5));

        mazeBorder.add(grid.get());

        container.add(mazeBorder);

        CardLayout cardLayout = new CardLayout();

        JButton runButton = new JButton("Run");
        JButton solveButton = new JButton("Solve");
        JButton resetButton = new JButton("Reset");
        JButton solveAgainButton = new JButton("Toggle Solution");
        JButton saveSolutionButton = new JButton("Save Solution");

        JTextArea mazeDetails = new JTextArea("Maze details:"+
                "\nDate generated : " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"))+
                "\nMaze can be solved: true");

        mazeDetails.setEditable(false);

        JComboBox<String> genMethodsComboBox= new JComboBox<>(GENERATION_METHODS);
        JComboBox<String> solveMethodsComboBox = new JComboBox<>(SOLVING_METHODS);

        genMethodsComboBox.setMaximumRowCount(genMethodsComboBox.getModel().getSize());
        solveMethodsComboBox.setMaximumRowCount(solveMethodsComboBox.getModel().getSize());

        Hashtable<Integer, JLabel> labels = new Hashtable<Integer, JLabel>();
        labels.put(1, new JLabel("Fast"));
        labels.put(40, new JLabel("Slow"));

        // Create the card panels.
        JPanel card1 = new JPanel();
        JPanel card2 = new JPanel();
        card1.setLayout(new GridBagLayout());
        card2.setLayout(new GridBagLayout());

        GridBagConstraints gridBagConstraints = new GridBagConstraints();

        gridBagConstraints.insets = new Insets(5, 0, 5, 18);
        gridBagConstraints.fill = GridBagConstraints.BOTH;

        gridBagConstraints.gridheight = 2;
        gridBagConstraints.weightx = 0.3;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        card1.add(mazeDetails);
        card1.add(runButton, gridBagConstraints);

        card1.add(xDimension);

        card1.add(yDimension);

        card2.add(solveButton, gridBagConstraints);

        JPanel card3 = new JPanel();
        card3.setLayout(new GridBagLayout());
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        card3.add(solveAgainButton, gridBagConstraints);
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        card3.add(resetButton, gridBagConstraints);
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        card3.add(saveSolutionButton, gridBagConstraints);
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;


        // Create the panel that contains the cards.
        JPanel cards = new JPanel(cardLayout);
        cards.setBorder(new EmptyBorder(0, 20, 0, 0));
        cards.setOpaque(false);
        cards.add(card1, "gen");
        cards.add(card2, "solve");
        cards.add(card3, "reset");

        container.add(cards);

        runButton.addActionListener(event -> {
            if (xDimensionValue != (int) xDimension.getValue() || yDimensionValue != (int) yDimension.getValue()) {
                if (((int) xDimension.getValue() > 100 || 100 < (int) yDimension.getValue()) || ((int) xDimension.getValue() < 1 || 1 > (int) yDimension.getValue())){
                    showMessageDialog(frame, "Dimensions must be between 1 and 100", "Dimension Warning", WARNING_MESSAGE);
                }
                else{
                    xDimensionValue = (int) xDimension.getValue();
                    yDimensionValue = (int) yDimension.getValue();
                    frame.dispose();
                    try {
                        Maze.W = Maze.getCellSize(yDimensionValue, xDimensionValue);
                        createAndShowGUI(WIDTH, yDimensionValue, xDimensionValue, HEIGHT);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            else if (xDimensionValue ==  (int) xDimension.getValue() && yDimensionValue == (int) yDimension.getValue()){
                Maze.generated = false;
                Maze.solved = false;
                grid.get().setGenerated(false);
                grid.get().setSolved(false);
                grid.get().generate(genMethodsComboBox.getSelectedIndex());

                cardLayout.next(cards);
            }
        });

        newMaze.addActionListener(event -> {
            frame.dispose();
            try {
                yDimensionValue = 10;
                xDimensionValue = 10;
                Maze.W = Maze.getCellSize(yDimensionValue, xDimensionValue);
                createAndShowGUI(WIDTH, yDimensionValue, xDimensionValue, HEIGHT);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });


        retrieveButton.addActionListener(event -> {
            Database.runDB();
            grid.set(FileHandler.retrieveFromFile());
        });

        saveSolutionButton.addActionListener(event -> {
            Database.runDB();
        });

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Database.runDB();
            }
        });

        solveButton.addActionListener(event -> {
            if (Maze.generated) {
                grid.get().solve();
                grid.get().setSolved(true);
                cardLayout.last(cards);
            } else {
                showMessageDialog(frame, "Please wait until the maze has been generated.");
            }
        });

        solveAgainButton.addActionListener(event -> {
            if (Maze.solved) {
                // = false;
                if (toggle) {
                    grid.get().resetSolution();
                    cardLayout.show(cards, "toggle");
                    toggle = !toggle;
                } else if (!toggle) {
                    grid.get().showSolution(mazeBorder.getGraphics());
                    toggle = !toggle;
                }
            } else {
                showMessageDialog(frame, "Please wait until the maze has been solved.");
            }
        });

        resetButton.addActionListener(event -> {
            try {
                frame.dispose();
                createAndShowGUI(WIDTH, rows, cols, HEIGHT);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        frame.pack();


        frame.setSize(screenWidth,screenHeight);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        currentFrame = frame;
    }

    /***
     * image to bytes
     * @param img
     * @return
     */
    public static byte[] imgToBytes(BufferedImage img) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            ImageIO.write(img, "png", baos);
        } catch (IOException e) {
            e.printStackTrace();
        }
        byte[] bytes = baos.toByteArray();
        return bytes;
    }

    /***
     * bytes to image
     * @param img
     * @return
     * @throws IOException
     */
    public static BufferedImage bytesToImg(byte[] img) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(img);
        BufferedImage returnImg = ImageIO.read(bais);
        return returnImg;
    }

    /***
     * create screenshot
     * @param frame
     * @return
     */
    public static BufferedImage screenshotImg(JFrame frame) {
        BufferedImage img = new BufferedImage(frame.getWidth(), frame.getHeight() - 50, BufferedImage.TYPE_INT_RGB);
        frame.paint(img.getGraphics());
        return img;
    }


    private static void exportImg(BufferedImage img){
        File outputfile = new File("saved.png");
        try {
            ImageIO.write(img, "png", outputfile);
         } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private static void exportImg(BufferedImage img, List selectedValuesList, int index) throws IOException {
        File outputfile = new File("screenshots/" + (String) selectedValuesList.get(index)+ ".png");
        if(outputfile.createNewFile()){
            try {
                ImageIO.write(img, "png", outputfile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            System.out.println("Screenshot of File (" + (String) selectedValuesList.get(index)+ ".png) already exists in screenshot folder");
        }
    }


    private static String getDifficultyMsg() {
        //get  difficulty to display. see usage
        double difficulty = MazeGridPanel.getMazeDifficulty();
        //check if maze is generated yet. if not give error message
        if(difficulty == 0.0){
            return "Maze has not been generated yet!";
        }else{
            return "Maze Difficulty: " + difficulty;
        }
    }
    public static byte[] screenshotData(){
        BufferedImage img = screenshotImg(currentFrame);
        exportImg(img);
        byte[] imgAsBytes = imgToBytes(img);
        return imgAsBytes;
    }

    public static byte[] getMazeData() { //when saving maze object to db
        byte[] data = MazeGridPanel.writeObjectToDatabase(grid);
        return data;
    }

    public static void byteArrayImgExport(byte[][] imgsAsBytes, List selectedValuesList) {
        System.out.printf(String.valueOf(imgsAsBytes.length));
        try{
            if(imgsAsBytes.length == 1){
                BufferedImage img = bytesToImg(imgsAsBytes[0]);
                exportImg(img, selectedValuesList, 0);
            }else{
                for (int i = 0; i < imgsAsBytes.length; i++){
                    BufferedImage img = bytesToImg(imgsAsBytes[i]);
                    exportImg(img, selectedValuesList, i);
                }
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void setImgInCells(JLabel l, int x, int y, boolean entry, boolean exit, boolean autoCheck) {
        int[] coordArray = new int[2];
        coordArray[0] = x;
        coordArray[1] = y;
        if(autoCheck){
            coordArray = MazeGridPanel.getAutoSetLocation(grid);
            l.setBounds(Maze.W * coordArray[0], Maze.W * coordArray[1], Maze.W*2, Maze.W*2);
            currentFrame.update(grid.get().add(l).getGraphics());
            currentFrame.setLocationRelativeTo(l);
        } if (x == 0 && y == 0){
            }else{
                l.setBounds(Maze.W * x, Maze.W * y, Maze.W*2, Maze.W*2);
                currentFrame.update(grid.get().add(l).getGraphics());
            }
        if(entry || exit){
            placeEntryExit(entry, exit, l);
        }
    }

    public static void placeEntryExit(boolean entry, boolean exit, JLabel l){
        if(entry && !exit){
            l.setBounds(0, 0, Maze.W*2, Maze.W*2);
            currentFrame.update(grid.get().add(l).getGraphics());
        }else if(exit && !entry){
            l.setBounds(Maze.W * grid.get().getCols() - (2*Maze.W), Maze.W * grid.get().getCols() - (2*Maze.W), Maze.W*2, Maze.W*2);
            currentFrame.update(grid.get().add(l).getGraphics());
        }else if(exit && entry){
            JLabel exitLabel;
            exitLabel = l;
            exitLabel.setBounds(Maze.W * grid.get().getCols() - (2*Maze.W), Maze.W * grid.get().getCols() - (2*Maze.W), Maze.W*2, Maze.W*2);
            l.setBounds(0, 0, Maze.W*2, Maze.W*2);
            currentFrame.update(grid.get().add(exitLabel).getGraphics());
            currentFrame.update(grid.get().add(l).getGraphics());
            currentFrame.setLocationRelativeTo(exitLabel);
        }
    }
}
