package main;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;
public class BrowseImage extends JFrame {
    public JLabel l;


    public static ImageIcon selectedIcon; // icon selected when browsing. later added to guihander jframe. edited in this class. then returned and save/handled in guihandler
    public static boolean hasChosen = false;

    public static int selectXCoord;
    public static int selectYCoord;
    private boolean entrySelected = true;
    private boolean exitSelected = true;
    private boolean autoCheckSelected = true;

    /***
     * Browse for an image in filesystem
     */
    public BrowseImage() {

        //super("Display an image from a JFileChooser");
        JButton btn = new JButton("Browse");
        //JButton addToMazeBtn = new Jbutton("Add to Maze");
        btn.setBounds(150, 310, 100, 40);

        l = new JLabel();

        add(btn);
        add(l);

        JCheckBox autoCheck = new JCheckBox("Auto", true);
        autoCheck.setBounds(270,295, 100,20);
        add(autoCheck);

        JCheckBox exitArrow = new JCheckBox("Exit", true);
        exitArrow.setBounds(270,315, 100,20);
        add(exitArrow);

        JCheckBox entryArrow = new JCheckBox("Entry", true);
        entryArrow.setBounds(270,335, 100,20);
        add(entryArrow);

        SpinnerModel xCoordModel = new SpinnerNumberModel(selectXCoord, 0, 100, 1);
        SpinnerModel yCoordModel = new SpinnerNumberModel(selectYCoord, 0, 100, 1);
        JSpinner xCoord = new JSpinner(xCoordModel);
        JSpinner yCoord = new JSpinner(yCoordModel);

        xCoord.setBounds(10,310,100,20);
        yCoord.setBounds(10,330,100,20);

        add(xCoord);
        add(yCoord);
        xCoordModel.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                selectXCoord = (int)xCoord.getValue();
            }
        });
        yCoordModel.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                selectYCoord = (int)yCoord.getValue();
            }
        });

        exitArrow.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exitSelected = !exitSelected;

            }
        });
        entryArrow.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                entrySelected = !entrySelected;
            }
        });

        autoCheck.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                autoCheckSelected = !autoCheckSelected;
            }
        });

        JLabel manualLabel = new JLabel("Manual");
        manualLabel.setBounds(10,290,50, 20);
        add(manualLabel);

        JLabel xLabel = new JLabel("X");
        JLabel yLabel = new JLabel("Y");
        xLabel.setBounds(115,310,10,20);
        yLabel.setBounds(115,330,10,20);
        add(xLabel);
        add(yLabel);


        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser file = new JFileChooser();
                file.setCurrentDirectory(new File(System.getProperty("user.home")));
                //filtering files
                FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", "jpg", "png");
                file.addChoosableFileFilter(filter);
                int res = file.showSaveDialog(null);
                //if the user clicks on save in Jfilechooser
                if (res == JFileChooser.APPROVE_OPTION) {
                    File selFile = file.getSelectedFile();
                    String path = selFile.getAbsolutePath();
                    Dimension size = l.getPreferredSize();
                    l.setSize(Maze.W*2, Maze.W*2);
                    l.setIcon(resize(path));
                    GUIHandler.setImgInCells(l, selectXCoord, selectYCoord, entrySelected, exitSelected, autoCheckSelected);
                    hasChosen = true;
                }
            }
        });

        setLayout(null);
        setLocationRelativeTo(null);
        setSize(400, 400);
        setVisible(true);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
    }

    // Method to resize the image with the same size of the Jlabel
    public ImageIcon resize(String imgPath) {
        ImageIcon path = new ImageIcon(imgPath);
        Image img = path.getImage();
        Image newImg = img.getScaledInstance(l.getWidth(), l.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }
}
