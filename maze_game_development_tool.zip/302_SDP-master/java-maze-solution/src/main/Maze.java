package main;

import java.awt.*;
import java.io.IOException;
import java.util.Hashtable;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Maze extends GUIHandler{

    public static int WIDTH;
    public static int HEIGHT;
    public static int newCellSize;
    public static int W; //CELL SIZE
    public static int H; //CELL SIZE height

    public static int speed = -1;
    public static boolean generated, solved;

    private int cols, rows;

    /***
     * Main method
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {

        new Maze();
    }

   public Maze() throws IOException {

        cols = xDimensionValue;
        rows = yDimensionValue;
        newCellSize = getCellSize(rows, cols);

        this.W = newCellSize;

        Toolkit tk = Toolkit.getDefaultToolkit();
        WIDTH = ((int)tk.getScreenSize().getWidth());
        HEIGHT = ((int)tk.getScreenSize().getHeight());

        GUIHandler.createAndShowGUI(WIDTH, rows, cols, HEIGHT);
    }

    /***
     * Determine cell size based on amount of cols and rows
     * @param rows
     * @param cols
     * @return
     */
    public static int getCellSize(int rows, int cols) {
       double cellRes;
       int screenWidth;
       int screenHeight;

       int cellDimension;
       int biggestDimension;

       Toolkit tk = Toolkit.getDefaultToolkit();
       screenWidth = ((int)tk.getScreenSize().getWidth());
       screenHeight = ((int)tk.getScreenSize().getHeight());

        cellRes = 0.55 * (Math.sqrt((screenHeight) * (screenWidth)));

       if (rows > cols){
           biggestDimension = rows;
       }
       else{
           biggestDimension = cols;
       }

       cellDimension = (int) Math.floor(cellRes / biggestDimension);
       System.out.println(cellDimension);

       return cellDimension;
    }
}
