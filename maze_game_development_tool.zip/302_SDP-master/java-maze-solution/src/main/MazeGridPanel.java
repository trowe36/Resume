package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import javax.swing.JPanel;

import generator.*;
import solver.*;
import utilityPackage.Cell;

public class MazeGridPanel extends JPanel implements Serializable {

    private static final long serialVersionUID = 7237062514425122227L;
    public final List<Cell> grid = new ArrayList<Cell>();
    private List<Cell> currentCells = new ArrayList<Cell>();
    private static int rows, cols;
    public static MazeGridPanel currentMaze;
    public static int diffCount = 0;
    private boolean solved,generated; //used to loadmaze in newgui method



    public int getRows() {
        return rows;
    }
    public int getCols(){
        return cols;
    }
    public boolean getSolved(){
        return solved;
    }
    public boolean getGenerated(){
        return generated;
    }

    public void setSolved(boolean value){
        solved = value;
    }
    public void setGenerated(boolean value){
        generated = value;
    }

    public MazeGridPanel(int rows, int cols) throws IOException {
        this.rows = rows;
        this.cols = cols;
        for (int x = 0; x <= rows - 1; x++) {
            for (int y = 0; y <= cols - 1; y++) {
                grid.add(new Cell(x, y));
            }
        }

    }

    public static byte[] writeObjectToDatabase(AtomicReference<MazeGridPanel> grid){
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        ObjectOutputStream objectStream;
        byte[] data = null;
        try {
            objectStream = new ObjectOutputStream(byteStream);
            objectStream.writeObject(grid);
            data = byteStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return data;
    }

    @Override
    public Dimension getPreferredSize() {
        // +1 pixel on width and height so bottom and right borders can be drawn.
        return new Dimension(Maze.WIDTH + 1, Maze.HEIGHT + 1);
    }

    public void generate(int index) {
        new DFSGen(grid, this);
        currentMaze = this;
        this.generated = true;
    }

    public void solve() {
        new DFSSolve(grid, this);
        this.solved = true;
    }

    public void resetSolution() {
        for (Cell cell : grid) {
            cell.setDeadEnd(false);
            cell.setPath(false);
            cell.setDistance(-1);
            cell.setParent(null);
        }
        repaint();
    }

    public void showSolution(Graphics graphics) {
        for (Cell cell : grid) {
            if(cell.getIsPartofSolution()){
                cell.setPath(true);
            }
        }
        repaint();
    }

    private int setDiffCount() {
        int tmp = 0;
        for (Cell c : grid){
            if(c.getIsPartofSolution()) {
                tmp++;
            }
        }
        return tmp;
    }

    public void setDifficulty() {
        diffCount = setDiffCount();
    }

    public static double getMazeDifficulty() {
        int pathCount = diffCount;
        double difficulty = Double.valueOf(pathCount)/Double.valueOf(rows * cols);
        return difficulty;
    }


    public void setCurrent(Cell current) {
        if(currentCells.size() == 0){
            currentCells.add(current);
        } else {
            currentCells.set(0, current);
        }
    }

    public void setCurrentCells(List<Cell> currentCells) {
        this.currentCells = currentCells;
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        //createWalledOffArea(2,2);
        for (Cell cell : grid) {
            cell.draw(graphics);
        }
        for (Cell cell : currentCells) {
            if(cell != null) cell.displayAsColor(graphics, Color.ORANGE);
        }
        grid.get(0).displayAsColor(graphics, Color.GREEN); // start cell
        grid.get(grid.size() - 1).displayAsColor(graphics, Color.RED); // end or goal cell


    }


    public static int[] getAutoSetLocation(AtomicReference<MazeGridPanel> currGrid) {
        boolean set = false;
        int[] returnArr = new int[2];
        //pass in grid object to method implemented in maze grid panel. contains the necessary data
        while(!set){
            for(Cell c : currGrid.get().grid){
                if(!c.getIsPartofSolution()){
                   List<Cell> neighbours = new ArrayList<Cell>();
                   neighbours = c.getAllNeighboursImgPlace(currGrid.get().grid);
                   //check neighbours not solution
                    int count = 1;
                    for (Cell cell: neighbours){
                        if(!cell.getIsPartofSolution()){
                            count++;
                        }
                    }
                    //check neighbours all unvisited
                    if(count > 3){
                        returnArr[0] = c.getX();
                        returnArr[1] = c.getY();
                        set = true;
                        return returnArr;
                    }
                }
            }
            set = true;
        }
        return returnArr;
    }

}
