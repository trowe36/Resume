package MazeTesting;

import FileSystem.FileHandler;
import main.Maze;
import main.MazeGridPanel;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

public class TestMaze {

    @Test
    public void testMaze() throws Exception {
        System.out.println("Maze generation");
        Maze maze = new Maze();
        assertEquals(maze != null, true);
    }

    @Test
    public void mazeGridPanelTest() throws Exception {
        System.out.println("Maze grid panel");
        try {
            MazeGridPanel maze = new MazeGridPanel(5, 5);
            maze.generate(5);
            assertEquals(maze, maze);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void mazeGridPanelTestBoundaryHigh() throws Exception {
        System.out.println("Maze grid panel boundary high");
        try {
            MazeGridPanel maze = new MazeGridPanel(99, 99);
            assertEquals(maze.getRows() == 99, true);
            assertEquals(maze.getCols() == 99, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void mazeGridPanelTestBoundaryLow() throws Exception {
        System.out.println("Maze grid panel boundary low");
        try {
            MazeGridPanel maze = new MazeGridPanel(1, 1);
            assertEquals(maze.getRows() == 1, true);
            assertEquals(maze.getCols() == 1, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void writeObjectTest() throws Exception {

        MazeGridPanel grid = new MazeGridPanel(5,5);
        try {
            FileHandler.writeObjectToFile(grid);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void retrieveObjectTest() throws Exception {
        MazeGridPanel grid = new MazeGridPanel(5,5);
        try {
            FileHandler.writeObjectToFile(grid);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
