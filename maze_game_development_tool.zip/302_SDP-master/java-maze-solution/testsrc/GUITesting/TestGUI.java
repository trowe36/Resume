package GUITesting;

import main.GUIHandler;
import main.Maze;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestGUI {


    @Test
    public void testGUI() {
        System.out.println("GUI generation");
        try {
            GUIHandler.createAndShowGUI(5, 5, 5, 5);
            assertEquals(Maze.xDimensionValue = 5, 5);
            assertEquals(Maze.yDimensionValue = 5, 5);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
