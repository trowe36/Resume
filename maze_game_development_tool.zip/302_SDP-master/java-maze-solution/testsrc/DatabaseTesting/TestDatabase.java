package DatabaseTesting;

import database.DBConnection;
import org.junit.jupiter.api.Test;


import java.sql.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestDatabase {

    @Test
    public void testOpenConnection() throws Exception {
        System.out.println("Connection open");
        try {
            Connection connection = DBConnection.getInstance();
            assertEquals(connection != null, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testCloseConnection() throws Exception {
        System.out.println("Connection close");
        try {
            Connection connection = DBConnection.getInstance();
            connection.close();
            assertTrue(connection.isClosed());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



//    @Test
//    public void testCreateTable() throws Exception {
//        System.out.println("Table creation");
//        String createTable = "CREATE TABLE IF NOT EXISTS testMazes ("
//                + "idx INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE,"
//                + "name VARCHAR(30) NOT NULL,"
//                + "author VARCHAR(30),"
//                + "lastEdited VARCHAR(20),"
//                + "date VARCHAR(10),"
//                + "blob VARBINARY(7500),"
//                + "screenshot VARBINARY(7500)" + ");";
//        try {
//            Connection connection = DBConnection.getInstance();
//            Statement st = connection.createStatement();
//            ResultSet rs = st.executeQuery(createTable);
//            ResultSetMetaData rsmd = rs.getMetaData();
//              String column1 = rsmd.getColumnName(1);
//          assertEquals("idx", columnName1);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


}
