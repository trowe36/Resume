package DatabaseTesting;

import static org.junit.jupiter.api.Assertions.*;

import main.GUIHandler;
import main.Maze;
import org.junit.jupiter.api.*;

public class testDimensions {

    // Test 1: Checking rows and columns equal correct value
    @Test
    public void setXDimensions(){
        GUIHandler.xDimensionValue = 50;

        assertEquals(50,Maze.xDimensionValue );
    }
}
