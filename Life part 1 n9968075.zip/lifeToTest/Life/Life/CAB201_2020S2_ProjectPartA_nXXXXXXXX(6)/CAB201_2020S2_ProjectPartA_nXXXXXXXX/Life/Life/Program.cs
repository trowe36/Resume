﻿using System;
using System.Diagnostics;
using Display;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;

namespace Life
{
    /// <summary>
    /// Main program, implements methods from ArgHandleClass.cs, ProgramOperations.cs and other API files to successfully simulate 'the game of life' 
    /// </summary>
    /// <author>Thomas Rowen</author>
    /// <date>September 2020</date>
    class Program
    {
        public static int[,] CurrentCells;
        public static int[,] NextGenerationCells;

        /// <summary>
        /// Uses data collected in ArgHandleClass from provide command arguments and displays them as settings to the user in the output console
        /// </summary>
        public static void DisplayMessageToConsole()
        {
            Console.WriteLine("The program will use the following settings: ");
            Console.WriteLine();
            Console.WriteLine("Input Files: {0}\n", ArgHandleClass.GetFileName());
            Console.WriteLine("\tStep Mode Enabled: {0}", ArgHandleClass.stepEnabled);
            Console.WriteLine("\tGenerations: {0}", ArgHandleClass.generations);
            Console.WriteLine("\tUpdate Rate: {0} each second", ArgHandleClass.updateRate);
            Console.WriteLine("\tRefresh Rate: ");
            Console.WriteLine("\tPeriodic: {0}", ArgHandleClass.periodic);
            Console.WriteLine("\tRows: {0}", ArgHandleClass.height);
            Console.WriteLine("\tColumns: {0}", ArgHandleClass.width);
            Console.WriteLine("\tRandom Factor: {0}\n", ArgHandleClass.probability);
            Console.WriteLine("The following error messages were detected: \n");
            foreach (string error in ArgHandleClass.errorMessages)
            {
                Console.WriteLine(error);
            }
            Console.WriteLine("The following success messages were detected: \n");
            foreach (string successItem in ArgHandleClass.successMessages)
            {
                Console.WriteLine(successItem);
            }
            Console.WriteLine();
            Console.WriteLine("Press Spacebar to Run: ");
            while (Console.ReadKey().Key != ConsoleKey.Spacebar)
            {
                continue;
            }

        }
        static void Main(string[] args)
        {
            string[] cmdArgs = args;
            ArgHandleClass argobj = new ArgHandleClass(cmdArgs);
            argobj.ProcessArgs(cmdArgs);
            int rows = ArgHandleClass.GetHeight(), columns = ArgHandleClass.GetWidth();

            //array size assigned using rows and columns so that all cells can be alive at once
            CurrentCells = new int[rows * columns, 2];
            NextGenerationCells = new int[rows * columns, 2];

            if (ArgHandleClass.seedDataMissing)
            {
                double probability = ArgHandleClass.GetProb();
                CurrentCells = ProgramOperation.GenerateRandomCells(probability, rows, columns);
            }
            else
            {
                string seedPath = argobj.seedPath;
                CurrentCells = argobj.FormatSeed(seedPath);
            }

            DisplayMessageToConsole();

            // Construct grid...
            Grid grid = new Grid(rows, columns);

            grid.InitializeWindow();

            Stopwatch stopwatch = new Stopwatch();
            double updateRate = (1 / ArgHandleClass.updateRate) * 1000;
            for (int i = 0; i <= ArgHandleClass.generations; i++)
            {
                if (ArgHandleClass.stepEnabled)
                {
                    while (Console.ReadKey().Key != ConsoleKey.Spacebar)
                    {
                        continue;
                    }
                }
                else
                {
                    stopwatch.Start();
                }

                //populate the cells
                for (int j = 0; j < CurrentCells.GetLength(0); j++)
                {
                    grid.UpdateCell(CurrentCells[j, 0], CurrentCells[j, 1], CellState.Full);
                }

                grid.SetFootnote(i.ToString());
                grid.Render();

                if (ArgHandleClass.stepEnabled == false)
                {
                    while (stopwatch.ElapsedMilliseconds < updateRate)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    stopwatch.Reset();
                }

                //dont clear the currentCells on last generation
                if (i != ArgHandleClass.generations)
                {
                    for (int CountVar = 0; CountVar < CurrentCells.GetLength(0); CountVar++)
                    {
                        grid.UpdateCell(CurrentCells[CountVar, 0], CurrentCells[CountVar, 1], CellState.Blank);
                    }
                }
                ProgramOperation.GetNextGen(ref CurrentCells, ref NextGenerationCells);
            }


            grid.SetFootnote(ArgHandleClass.generations.ToString());
            grid.IsComplete = true;
            grid.Render();

            // Wait for user to press enter to finish program
            while (Console.ReadKey().Key != ConsoleKey.Spacebar)
            {
                continue;
            }
            // Revert grid window size and buffer to normal
            grid.RevertWindow();
        }


    }
}
