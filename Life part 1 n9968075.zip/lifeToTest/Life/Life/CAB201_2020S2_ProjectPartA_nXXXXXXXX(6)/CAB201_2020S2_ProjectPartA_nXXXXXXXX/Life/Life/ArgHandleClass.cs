﻿using System;
using System.Diagnostics;
using Display;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;

namespace Life
{
    /// <summary>
    /// This class's purpose is to read command line arguments, validate them and prepare them as input for the main program and algorithms used in 'programoperation.cs'
    /// </summary>
    /// <author>Thomas Rowen</author>
    /// <date>September 2020</date>
    class ArgHandleClass
    {
        //default settings of program, used when user doesn't specify setting in parameters 
        public static int height = 16;
        public static int width = 16;
        public static bool periodic = false;
        public static double probability = 0.5;
        public static int generations = 50;
        public static string fileName = "";       
        public static bool stepEnabled = false;
        public static double updateRate = 5;

        public string[] path;
        public static int lineCount;
        public string seedPath;
        //message array's used in displayMessage() method
        public static string[] errorMessages = new string[10];
        public static string[] successMessages = new string[10];

        //message count variables use within methods throughout the class
        int errorMessageCount = 0;
        int successMessageCount = 0;

        //set these to false once they are interpreted at command line: assign missing commands to string array at handlArg function termination       
        public static bool seedDataMissing = true, inputFileMissing = true, randomFactorMissing = true, periodicMissing = true,
            rowsAndColumnsMissing = true, generationsMissing = true, maxUpRateMissing = true, stepModeMissing = true, dimensionsMissing = true;

        public ArgHandleClass(string[] feilPath)
        {
            path = feilPath;
        }

        /// <summary>
        /// Get methods below. These four methods are basic methods used to retrieve values later on in the program, used to increase code readability. 
        /// </summary>
        /// <returns></returns>
        public static double GetProb()
        {
            return probability;
        }

        public static int GetHeight()
        {
            return height;
        }

        public static int GetWidth()
        {
            return width;
        }

        public static string GetFileName()
        {
            if (seedDataMissing)
            {
                string seedMissingError = "No seed file provided, using default randomisation";
                return seedMissingError;
            }
            else
            {
                return fileName;
            }

        }

        /// <summary>
        /// Program to read command arguments specified by user and save them into data variables used later in the program
        /// </summary>
        /// <param name="args"></param>
        public void ProcessArgs(string[] args)
        {
            //counter variables used to access arguments and their options correctly
            int idx = 0;
            int posCounter = 0;

            while (idx < args.Length)
            {               
                string valueIn = args[idx];                
                if (valueIn == "--step")
                {
                    stepEnabled = true;
                    stepModeMissing = false;
                }
                if (valueIn == "--dimensions")
                {
                    dimensionsMissing = false;
                    posCounter = idx + 1;
                    height = int.Parse(args[posCounter]);
                    posCounter++;
                    width = int.Parse(args[posCounter]);                                                               //IF PARSE STRING THEN DIMENSION MISSING?

                    //validation 
                    if (width <= 3 || height <= 3)
                    {
                        errorMessages[errorMessageCount] = "\tThe dimensions provided were not greater than or equal to 4";
                        errorMessageCount++;
                    }
                    else
                    {
                        successMessages[successMessageCount] = "\tWidth and height dimensions satisfy the lower bound";
                        successMessageCount++;
                    }
                    if (width >= 49 || height >= 49)
                    {
                        errorMessages[errorMessageCount] = "\t-The dimensions provided were not less than or equal to 49";
                        errorMessageCount++;
                    }
                    else
                    {
                        successMessages[successMessageCount] = "\tWidth and height dimensions satisfy the upper bound";
                        successMessageCount++;
                    }
                }
                if (valueIn == "--periodic")
                {
                    periodicMissing = false;
                    periodic = true;
                }
                if (valueIn == "--random")
                {
                    randomFactorMissing = false;
                    posCounter = idx + 1;
                    bool canParse = double.TryParse(args[posCounter], out double result);
                    if ((result <= 1) && (result >= 0))
                    {
                        probability = result;
                        successMessages[successMessageCount] = "\tThe random factor provided was a float between 0 and 1 (inclusive)";
                        successMessageCount++;
                    }
                    else
                    {
                        errorMessages[errorMessageCount] = "\tThe random factor provided was not a float between 0 and 1 (inclusive)";
                        errorMessageCount++;
                    }
                }
                if (valueIn == "--seed")
                {

                    posCounter = 0;
                    posCounter = idx + 1;
                    fileName += args[posCounter];
                    seedPath = fileName;
                    if (File.Exists(fileName))
                    {
                        seedDataMissing = false;
                    }
                    else
                    {
                        seedDataMissing = true;
                    }
                }
                if (valueIn == "--generations")
                {
                    generationsMissing = false;
                    posCounter = idx + 1;
                    bool canParse = int.TryParse(args[posCounter], out int result);
                    if (canParse)
                    {
                        if (result > 0)
                        {
                            generations = result;
                            successMessages[successMessageCount] = "\tThe generations provided was a positive non-zero integer";
                            successMessageCount++;
                        }
                        else
                        {
                            errorMessages[errorMessageCount] = "\tThe generation number provided was not a positive non-zero integer";
                            errorMessageCount++;
                        }
                    }
                    else
                    {
                        errorMessages[errorMessageCount] = "\tThe generation number provided was not an integer";
                        errorMessageCount++;
                    }
                }

                if (valueIn == "--max-update")
                {
                    maxUpRateMissing = false;
                    posCounter = idx + 1;
                    bool canParse = double.TryParse(args[posCounter], out double result);
                    if (canParse)
                    {
                        if ((result >= 0) && (result <= 30))
                        {
                            updateRate = result;
                            successMessages[successMessageCount] = "\tThe maximum update rate provided was a float between 0 and 30 (inclusive)";
                            successMessageCount++;
                        }
                        else
                        {
                            errorMessages[errorMessageCount] = "\tThe maximum update rate provided was not a float between 0 and 30 (inclusive)";
                            errorMessageCount++;
                        }
                    }
                }
                idx++;
            }
        }

        /// <summary>
        /// Opens file based on path specified in command arguments and reads lines into 2D array which will be used later in program as intial configuration of alive
        /// cells should the user specify valid file path and .seed extension
        /// </summary>
        /// <param name="path"></param>
        /// <returns>Seed file in form of 2D Array</returns>
        public int[,] FormatSeed(string path)
        {
            int rowHolder = 0;
            int j = 0;
            TextReader readFile = new StreamReader(fileName);
            //This code to remove first version line of the seed file. so that only data remains
            readFile.ReadLine();
          
            lineCount = File.ReadAllLines(fileName).Length; 
            int[,] arr = new int[lineCount - 1, 2];            
            string lines = readFile.ReadToEnd();
            //multiplied by two to allow both col1 and col2 rows to be stored
            int[] seedAsSingleArray = new int[lineCount * 2 - 2]; 

            string newLines = lines.Replace("\n", "").Replace("\r", " ");
            string currentChar = "";

            foreach (char item in newLines)
            {
                if (item != ' ')
                {
                    currentChar += item;
                }
                else
                {
                    seedAsSingleArray[j] = int.Parse(currentChar);
                    currentChar = "";
                    j++;
                }
            }

            bool isCol1 = true;
            //convert single array into 2D array where coordinates can be specified
            foreach (int item in seedAsSingleArray)
            {
                if (isCol1 == true)
                {
                    arr[rowHolder, 0] = item;
                    isCol1 = false;
                }
                else if (isCol1 != true)
                {
                    arr[rowHolder, 1] = item;
                    isCol1 = true;
                    rowHolder++;
                }
            }

            readFile.Close();
            readFile = null;
            CheckSeedInDimensions(arr, height, width);
            return arr;
        }

        /// <summary>
        /// Checks that the maximum dimensions provided in the seed file (array parameter) to not exceed the width and height dimensions such that alive cells
        /// exist outside the universe
        /// </summary>
        /// <param name="arr"></param>
        /// <param name="height"></param>
        /// <param name="width"></param>
        private void CheckSeedInDimensions(int[,] arr, int height, int width)
        {
            int arrayRowMax = 0;
            int arrayColMax = 0;
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                if (arr[i, 0] > arrayRowMax)
                {
                    arrayRowMax = arr[i, 0];
                }
                if (arr[i, 1] > arrayColMax)
                {
                    arrayColMax = arr[i, 1];
                }
            }
            //after finding max value check if in bounds of specified dimensions
            if (arrayRowMax >= height)
            {
                arrayRowMax++;
                errorMessages[errorMessageCount] = "\tThere are alive cells that exist outside the bounds of the universe, please increase row size to " + arrayRowMax;
                errorMessageCount++;
            }
            if (arrayColMax >= width)
            {
                arrayColMax++;
                errorMessages[errorMessageCount] = "\tThere are alive cells that exist outside the bounds of the universe, please increase column size to " + arrayColMax;
                errorMessageCount++;
            }
        }
    }
}
