﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Display;



namespace Life
{
    /// <summary>
    /// The methods used in this class are associated with the inner mechanics of 'the game of life'. After the initial configurations are set up, this is the class that
    /// mainly runs the program. The purpose of the methods in this class are to take the intial configuration of alive cells and manipulate that data using algorithms
    /// to successfully save next generation configuration of cells and feed this data back into the main program. 
    /// </summary>
    /// <author>Thomas Rowen</author>
    /// <date>September 2020</date>
    class ProgramOperation
    {

        /// <summary>
        /// For each cell in the grid, this function will determine whether the cell is dead or alive depending on the probability specified by the user. 
        /// </summary>
        /// <param name="probability"></param>
        /// <param name="rows"></param>
        /// <param name="columns"></param>
        /// <returns>The initial cell configuration in the form of a two dimensional array</returns>
        public static int[,] GenerateRandomCells(double probability, int rows, int columns)
        {
            int[,] returnArr = new int[rows * columns, 2]; // need to make size dynamic
            int arrayIndex = 0;
            Random randomGen = new Random();

            for (int i = 0; i < rows; i++)
            {
                for (int k = 0; k < columns; k++)
                {
                    double randomVal = randomGen.NextDouble();
                    //generate random double between 
                    if (randomVal < probability)
                    {
                        int rowToAdd = i;
                        int colToAdd = k;

                        returnArr[arrayIndex, 0] = i;
                        returnArr[arrayIndex, 1] = k;
                        arrayIndex++;
                    }
                }
            }
            return returnArr;
        }

        /// <summary>
        /// Method takes on x,y coordinate from the grid and returns its 'neighbours' or 'neighbourhood' based on the rules of life. Method is called within main method GetNextGen() 
        /// </summary>
        /// <param name="col1"></param>
        /// <param name="col2"></param>
        /// <returns>A two dimensional array containing the row and column coordinates of one cell's neighbours</returns>
        private static int[,] GetNeighbourXY(int col1, int col2)
        {
            //neighbour array to return and p counter vaiable which controls array depth increment
            int[,] CellNeighbours = new int[8, 2];
            int p = 0;

            //each neighbour is 1 column above and below the cell in question. Also 1 row to the right and left of the cell in question
            for (int i = -1; i <= 1; i++)
            {
                for (int k = -1; k <= 1; k++)
                {
                    int j = 0;
                    int col11 = col1 + k, col22 = col2 + i;
                    //below if statement included so that the cell in question (the parameters of the function) are not included as a neighbour
                    if (i == 0 && k == 0)
                    {
                        continue;
                    }
                    else
                    {
                        CellNeighbours[p, j] = col11; // for p check first for loop
                        j++;//to increment column, resets .   
                        CellNeighbours[p, j] = col22;
                        p++;
                        //check for loop commented code basbove abvove
                    }
                }
            }
            return CellNeighbours;
        }

        /// <summary>
        /// Uses return array[,] value from GetNeighbourXY() and calculates how many of these neighbours are alive by comparing to the CurrentCells[,] array
        /// </summary>
        /// <param name="neighbourArray"></param>
        /// <param name="CurrentCells"></param>
        /// <returns>An integer value specifying the number of alive neighbours that are in the neighbour array</returns>
        private static int GetAliveNeighbours(int[,] neighbourArray, int[,] CurrentCells)
        {
            int aliveCount = 0;
            for (int i = 0; i < neighbourArray.GetLength(0); i++)
            {
                for (int j = 0; j < CurrentCells.GetLength(0); j++)
                {
                    int tmpN1 = neighbourArray[i, 0];
                    int tmpN2 = neighbourArray[i, 1];
                    int tmpC1 = CurrentCells[j, 0];
                    int tmpC2 = CurrentCells[j, 1];

                    if ((tmpN1, tmpN2) == (tmpC1, tmpC2))
                    {
                        aliveCount++;
                    }
                }
            }
            return aliveCount;
        }

        /// <summary> takes two reference parameters, runs data from currentCells array through algorithm which determines the next generation based on the current
        /// formation of alive cells. Methods GetNeighbourXY and GetAliveNeighbours are implemented in this main algorithm. At the end of the method, nextGeneration 
        /// Cells are assigned to CurrentCells and the Values in NextGenerationCells are emptied. 
        /// </summary>
        /// <param name="CurrentCells"></param>
        /// <param name="NextGenerationCells"></param>       
        public static void GetNextGen(ref int[,] CurrentCells, ref int[,] NextGenerationCells)//currentcells is curent alive cells on screen. Next gen cells is what is be ref'd into.
        {
            //Counter variable used to control height increment in assigning values to NextGenerationCells
            int cellsCurrentlyAlive = 0;
            //For all cells in the grid, check if they are equal to any of the alive cells in CurrentCells array
            for (int r = 0; r < ArgHandleClass.height - 1; r++)
            {
                for (int c = 0; c < ArgHandleClass.width - 1; c++)
                {
                    for (int i = 0; i < CurrentCells.GetLength(0); i++)
                    {
                        int col1 = CurrentCells[i, 0];
                        int col2 = CurrentCells[i, 1];
                        //the current row and column from the entire grid is alive.
                        if ((r, c) == (col1, col2))
                        {
                            int[,] neighbourArray = GetNeighbourXY(col1, col2);
                            int aliveNeighbours = GetAliveNeighbours(neighbourArray, CurrentCells);

                            //assess whether the current alive cell is alive next generation based on 'rules of life'
                            if (aliveNeighbours == 2 || aliveNeighbours == 3)
                            {
                                bool doesExistAlready = CheckIfExists(col1, col2, NextGenerationCells);
                                if (doesExistAlready)
                                {
                                    continue;
                                }
                                else
                                {
                                    NextGenerationCells[cellsCurrentlyAlive, 0] = col1;
                                    NextGenerationCells[cellsCurrentlyAlive, 1] = col2;
                                    cellsCurrentlyAlive++;
                                }
                            }
                        }

                        //When current row and column x,y is dead. Determination must still be made regarding if they are alive next generation. As the x,y may have 3 alive neighbours
                        else
                        {
                            int[,] neighbourArray = GetNeighbourXY(r, c);
                            int aliveNeighbours = GetAliveNeighbours(neighbourArray, CurrentCells);

                            if (aliveNeighbours == 3)
                            {
                                bool doesExistAlready = CheckIfExists(r, c, NextGenerationCells);
                                if (doesExistAlready)
                                {
                                    continue;
                                }
                                else
                                {
                                    NextGenerationCells[cellsCurrentlyAlive, 0] = r;
                                    NextGenerationCells[cellsCurrentlyAlive, 1] = c;
                                    cellsCurrentlyAlive++;
                                }
                            }
                        }
                    }
                }
            }
            //NextGenerationCells contains many empty values, as its size can allow for all cells to be alive at once. Therefore, trim empty values and assign to Current
            CurrentCells = TrimZeroFromArray(NextGenerationCells);
            RevertToPrevious(NextGenerationCells);
        }

        /// <summary>
        /// Empties array and reverts it to its empty form. 
        /// </summary>
        /// <param name="nextGenerationCells"></param>
        private static void RevertToPrevious(int[,] nextGenerationCells)
        {
            for (int i = 0; i < nextGenerationCells.GetLength(0); i++)
            {
                if ((nextGenerationCells[i, 0] != 0) || (nextGenerationCells[i, 1] != 0))
                {
                    nextGenerationCells[i, 0] = 0;
                    nextGenerationCells[i, 1] = 0;
                }
            }
        }

        /// <summary>
        /// Checks if the row and column to be added to NextGenerationCells already exists in nextGenerationCells. Implemented in GetNextGen()
        /// </summary>
        /// <param name="col1"></param>
        /// <param name="col2"></param>
        /// <param name="NextGenerationCells"></param>
        /// <returns>True or false depending on whether exists or not</returns>
        private static bool CheckIfExists(int col1, int col2, int[,] NextGenerationCells)
        {
            for (int i = 0; i < NextGenerationCells.GetLength(0); i++)
            {
                if ((col1, col2) == (NextGenerationCells[i, 0], NextGenerationCells[i, 1]))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Reduces size of array as it is intially configured to be capable of having all cells in the grid alive at once. 
        /// </summary>
        /// <param name="nextGenerationCells"></param>
        /// <returns>The array provided as a parameter but without trailing 0's</returns>
        private static int[,] TrimZeroFromArray(int[,] nextGenerationCells)
        {
            for (int i = 0; i < nextGenerationCells.GetLength(0); i++)
            {
                int colHolder1 = nextGenerationCells[i, 0];
                int colHolder2 = nextGenerationCells[i, 1];

                if (colHolder1 == 0 && colHolder2 == 0)
                {
                    int index = i;
                    int[,] returnArr = new int[i, 2];

                    for (int zz = 0; zz < returnArr.GetLength(0); zz++)
                    {
                        returnArr[zz, 0] = nextGenerationCells[zz, 0];
                        returnArr[zz, 1] = nextGenerationCells[zz, 1];
                    }
                    return returnArr;
                }
            }
            return nextGenerationCells;
        }
    }
}
