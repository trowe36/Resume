var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt')
var idCount;
//var idCount = 3;
router.post("/", (req, res, next) => {
  //const{email, password} = JSON.stringify(req.body);
  req.db.from('users').max('id').then(
    (id) => {
       idCount = id;
      //idCount = newMaxId;
    }
  )

  if (!req.body.email || !req.body.password) {
      //res.message = 'msg property';
      console.log("no email")
      res.status(400).send({ Error: 'true', message: "Request body incomplete, both email and password are required" });
  } else {
      const user = {
          "email": req.body.email
      };
      //checks the user is not already existant
      //console.log({user})
      req.db.from('users').select('email').where(user)
          .then(occurrance => {
              console.log(occurrance)
              if (occurrance.length == 0) {
                  next()
              }
              else {
                  res.status(409).json({ error: true, message: 'User already exists' });
              }
          }).catch(error => {
              console.log(error);
              res.status(400).json({ message: 'Bad Request' });
          })
  }
})

function getFields(input, field) {
  var output = [];
  for (var i=0; i < input.length ; ++i)
      output.push(input[i][field]);
  return output;
}

//creates the user
router.post('/', (req, res) => {
  const[objArray] = idCount
  const{email, password} = req.body;
  const hash = bcrypt.hashSync(password, 10)

  const user = {
      "id" : parseFloat(Object.values(objArray)) + 1, //assigns id as DB.MAX(id) + 1. To get into correct spot
      "email": email,
      "password": hash
  };
  req.db("users").insert(user)
      .then(occurrance => {
          console.log("returning status 201")
          res.status(201).json({ message: 'User created' });
      }).catch(error => {
          console.log(error)
          res.status(500).json({ message: 'Database error - not updated' });
      })
});
//see swagger docs post request 
  module.exports = router; 