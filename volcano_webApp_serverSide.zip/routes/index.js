var express = require('express');
var router = express.Router();

/* GET home page. */
//we use express to serve api endpoints, not serve webpages or html docs 
var countriesRouter = require('./Data/countries');
var volcanoesRouter = require('./Data/volcanoes');
var volcanoRouter = require('./Data/volcano');

router.use('/countries', countriesRouter);
router.use('/volcano', volcanoRouter)
router.use('/volcanoes' , volcanoesRouter)

router.get('/me', function(req,res){
    res.status(200).json({
        name: "Thomas Rowen",
        student_number: "n9968075"
    })
})


module.exports = router;
