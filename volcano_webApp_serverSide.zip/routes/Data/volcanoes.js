var express = require('express');
var router = express.Router();

/* GET users listing. */
// router.get('/', function(req, res, next) { /// /countries URL
//     res.send('respond with volcanoes data');
//   });
const queryParamsOK = (req, res) => {
  const [country, pop] = Object.keys(req.query)
  if(Object.keys(req.query).length >= 3){
    res.status(400).send({ error: true, message: "Invalid query parameters. Only country and populatedWithin are permitted."})
    return;
  }
  else if(Object.keys(req.query).length == 2){
    if(country !== "country" || pop !== "populatedWithin"){
      console.log(country)
      //console.log(pop)
      if(!(req.query.populatedWithin === "5km" || req.query.populatedWithin === "10km" || req.query.populatedWithin === "30km" || req.query.populatedWithin === "100km")){
        res.status(400).send({ error: true, message: "Invalid value for populatedWithin. Only: 5km,10km,30km,100km are permitted."})
        return;
      }
      res.status(400).send({ error: true, message: "Invalid query parameters. Only country and populatedWithin are permitted."})
      return;
    }
    return true;
  }
  else if(Object.keys(req.query).length == 0){
    res.status(400).send({ error: true, message: "Country is a required query parameter."})
    return;
  }
  else{return true;}
}

router.get('/', function(req, res, next){
  const country = req.query.country;
  const populatedWithin = req.query.populatedWithin;
  //req.db.from('data').select('*').where('country', '=',CountryCode)
  //console.log(req.params)
if(queryParamsOK(req, res)){
  if(populatedWithin && country){
    if(populatedWithin == "5km"){
      console.log('in 5 km query')
      req.db.from('data').select('id', 'name', 'country', 'region', 'subregion').where('country', '=', country)
      .andWhere('population_5km', '>', 0)
      .then(rows => {
        res.status(200).json(rows)
      })
      return;
    }
    if(populatedWithin == "10km"){
      req.db.from('data').select('id', 'name', 'country', 'region', 'subregion').where('country', '=', country)
      .andWhere('population_10km', '>', 0)
      .then(rows => {
        res.status(200).json(rows)
      })
      return;
    }
    if(populatedWithin == "30km"){
      req.db.from('data').select('id', 'name', 'country', 'region', 'subregion').where('country', '=', country)
      .andWhere('population_30km', '>', 0)
      .then(rows => {
        res.status(200).json(rows)
      })
      return;
    }
    if(populatedWithin == "100km"){
      console.log('in 100 km query')
      req.db.from('data').select('id', 'name', 'country', 'region', 'subregion').where('country', '=', country)
      .andWhere('population_100km', '>', 0)
      .then(rows => {
        res.status(200).json(rows)
      })
      return;
    }
  }
  else if (country && !populatedWithin){
    req.db.from('data').select('*').where('country', '=', country)
    .then(rows => {
      res.status(200).json(
        rows
      )
      return;
    })
  }
  else if(populatedWithin && !country){
    res.status(400).send({ error: true, message: "Country is a required query parameter."})
    return;
  }
}


  //else if. check swagger code 400 
  //MissingCountryParameterVolcanoes{...}
  //InvalidParametersVolcanoes{...}
  //InvalidPopulatedWithinParameterVolcanoes{...}
})
  module.exports = router; 