var express = require('express');
var router = express.Router();
var jwt = require('jsonwebtoken')
/* GET users listing. */
router.get('/', function (req, res, next) { /// /countries URL
  if (Object.keys(req.query).length > 0) {
    res.status(400).json({
      error: true,
      message: "Invalid query parameters. Query parameters are not permitted."
    })
    return;
  }
  res.send('Please enter a volcano id parameter. Example path: /volcano/1');
});

const authorize = function(req, res, next){
  const authHeader = req.headers.authorization;
  const id = req.params.id; 
  
  if(authHeader === undefined){
    req.db.from('data').select('id', 'name', 'country', 'region', 'subregion', 
    'last_eruption', 'summit', 'elevation', 'latitude', 'longitude').where('id', '=', id)
    .then(dbRecord => {
      if(dbRecord.length == 0){
        res.status(404).send({ error: true, message: `Volcano with ID: ${id} not found.` })
      }else{
        res.status(200).json(dbRecord[0]);
        return;
      }
      
    })
    .catch(error => {
      console.log(error)
      res.status(400).json({
        error: true,
        message: "Invalid query parameters. Query parameters are not permitted"
      })
      return;
    })
  }else{
    console.log(authHeader.split(" ")[0])
    if(!authHeader || authHeader.split(" ").length !== 2 || authHeader.split(" ")[0] !== 'Bearer') {
      console.log("testing auth header line 35: " + authHeader)
      res.status(401).json({
        error: true,
        message: "Authorization header is malformed"
      });
      return;
    }
    const token = authHeader.split(" ")[1];
    try{    
      const tokenPayload = jwt.verify(token, secretKey)
      //check data 
      if(Date.now > tokenPayload.exp){
        res.status(401).json({
          error: true, 
          message: "Expired JWT Token"
        })
        return;
      }
      //check id in range . authorized 
      const id = req.params.id;
      if(id >= 1343){
        console.log("auth but out of range id")
        res.status(404).json({ error: true, message: "volcano does not exist"})  
        return;      
      }
      next()
    } catch(error){
      //console.log(error)
      res.status(401).json({
        error: true,
        message: "Invalid JWT token"
      })
      return
    }
  }
}

router.get('/:id', authorize, function (req, res) { /// /countries URL
  const id = req.params.id;
  //const MAX_ID = 1343; //SELECT MAX(id) FROM `volcanoes`.`data`  TODO replace with query, not hardcoded
  if (Object.keys(req.query).length > 0) {    
      res.status(400).json({
      error: true,
      message: "Invalid query parameters. Query parameters are not permitted."
    })
    return;
  }else{
    req.db.from('data').select('id', 'name', 'country', 'region', 'subregion', 
    'last_eruption', 'summit', 'elevation', 'latitude', 'longitude', 'population_5km',
    'population_10km', 'population_30km', 'population_100km').where('id', '=', id)
    .then(
      rows => {
        if (rows.length == 1) {
          res.status(200).json(rows[0]) //TODO sends extra data if JWT token is supplied in header of request
          return;
        } else {
          res.status(404).send({ error: true, message: `Volcano with ID: ${id} not found.` })
          return;
        }

      }
    )
  }

})
//catch error 400 invalid query params
//401 invalid jwt token -- check 'schema' 
//404 volcano ID not found 


module.exports = router; 
