var express = require('express');
var router = express.Router();

/* GET users listing. */


router.get("/", function (req, res, next) {
  if (Object.keys(req.query).length > 0) {
    res.status(400).json({
      error: true,
      message: "Invalid query parameters. Query parameters are not permitted."
    })
    return;
  } else {
    req.db.from('data').distinct('country').orderBy('country', 'asc')
      .then(
        (rows) => {
          res.status(200).json(rows.map(z => z.country))
        })
      .catch((err) => {
        res.status(400).json({
          error: true,
          message: "Invalid query parameters. Query parameters are not permitted."
        })
      })

  }

});

module.exports = router; 