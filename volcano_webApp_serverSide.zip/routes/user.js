var express = require('express');
var router = express.Router();
var profileRouter = require('./profile');
var loginRouter = require('./Authentication/login');
var registerRouter = require('./Authentication/register');
/* GET users listing. */



router.use('/register', registerRouter);
router.use('/login', loginRouter)
router.use('/', profileRouter)

module.exports = router;
