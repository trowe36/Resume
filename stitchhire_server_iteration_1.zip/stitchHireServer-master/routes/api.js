var express = require('express');
var router = express.Router();
var roster_start = ''; //can use global for all middleware calls as this is not accessible to normal users. 
var currDate = '';
var rosterFilled = false;
var duration = 6;

router.get('/me', function(req,res){
    //console.log("in /me")
    res.status(200).json({
        name: "Thomas Rowen",
        student_number: "n9968075"
    })
})


function checkRosterStart(req, res, next){
    duration = req.body.duration
    ////console.log(Object.values(req.body.duration))
    roster_start = req.body.rosterStart
    let tmp = req.body.rosterStart.toString().substring(0,2)
    let tmp_2 = req.body.today.toString().substring(0,2)

    if(tmp_2.substring(0,1) == '0'){
        tmp_2 = tmp_2.substring(1,2)
        //console.log(tmp_2)
    }
    if(tmp.substring(0,1) == '0'){
        tmp = tmp.substring(1,2)
        //console.log(tmp)
    }
    let ddRoster = parseInt(tmp)
    let ddToday = parseInt(tmp_2)


    ddToday +=7; //for compare if a week until roster start 

    if(ddToday >= ddRoster){
        //console.log("start roster")
        next()
    }else{
        //skip next middleware, roster should be created yet. 
        next('route')
    }
}

function createRoster(req,res, next){
//console.log("creating table")
req.db.schema.hasTable(`aroster_table_${req.body.rosterStart}`).then(function(exists) {
    if (!exists) {
      return req.db.schema.createTable(`aroster_table_${req.body.rosterStart}`, function(t) {
                    t.integer('id').primary();
                    t.boolean('jobFilled')
                    t.integer('assignStatus')
                    t.boolean('replyStatus')
      });
    }
  });
  rosterFilled = false;
    next()
}

router.put("/update-roster", checkRosterStart, createRoster, function (req,res){
//console.log("in main put")
})

function AddRosterRow(req, dbRec){
    let currRosterDay;
    if(roster_start.substring(0,1) == '0'){
        currRosterDay = roster_start.substring(1,2)
    }else{
        currRosterDay = roster_start.substring(0,2)
    }
   
    let currRosterMonth = roster_start.substring(3,5)
    let currRosterYear = roster_start.substring(6,10)

    let recDay = (dbRec.jobDate).toString().substring(0,2)
    let recMonth = (dbRec.jobDate).toString().substring(3,5)
    let recYear = (dbRec.jobDate).toString().substring(6,10)

    let rosEnd = parseInt(currRosterDay) + parseInt(duration) //have input in admin front end for total roster days. manually put so not monthly crossover

    //console.log(rosEnd)
    // let jobD = (dbRec.jobDate).toString()
    // //console.log(jobD)


    //could hvae rollover issues, therefore keep rosters to same months. eg have 4 rosters in a month
    if(parseInt(recDay) <= rosEnd && parseInt(recDay) >= parseInt(currRosterDay)){
        
        //check month is same
        if(parseInt(recMonth) == parseInt(currRosterMonth)){
            if(parseInt(recYear) == parseInt(currRosterYear)){
                ////console.log("adding job date to do  :  " + dbRec.jobDate)
                const info = {
                    "id": dbRec.id,
                    "jobFilled" : false,
                    "assignStatus" :false, //change this to a counter that counts fill status unlike jobFilled
                    "replyStatus" : false
                }
                req.db(`aroster_table_${roster_start}`).insert(info)
                .then((rec) => {
                    return; //do nothin, continue through middleware
                })
            }
        }
    }

}


//dd/mm/yyyy
router.get("/generate-roster", function(req,res,next){
    //roster_start = '11/10/1999'
    if(!rosterFilled){
        req.db.from('jobs_table').select('id', 'jobDate')
        .then((dbRec) => {
            //console.log(dbRec.length)
            for(let i = 0; i < dbRec.length; i++){
                AddRosterRow(req, dbRec[i])
            }
            rosterFilled = true;
        })
    }
})

function createJobPanels(req, res, next){
//for each row in roster   //get that row id
roster_start = '29/07/2022' //TODO set roster start to req.body
req.db.from(`aroster_table_${roster_start}`).select('id')
.then((dbRec) => {
    //console.log("table found")
    for(let i = 0; i < dbRec.length; i++){
        req.db.from(`z_card_${dbRec[i].id}`).select('quantity', 'id')
        .then((record) => {
            //console.log("found z card table")
            //console.log(record[0].quantity)
            for(let x = 0; x < record.length; x++){
                //create panel table 
                req.db.schema.hasTable(`job_panel_${dbRec[i].id}_${record[x].id}`).then(function(exists) {
                    if (!exists) {
                      req.db.schema.createTable(`job_panel_${dbRec[i].id}_${record[x].id}`, t => {
                                    t.integer('id').primary();
                                    t.boolean('assignStatus')
                                    t.boolean('replyStatus')
                                    t.integer('jobIDFK').references('id').inTable('jobs_table')
                                    t.integer('cardIDFK').references('id').inTable(`z_card_${dbRec[i].id}`)
                                    t.integer('workerIDFK');
                      }).then((prom) => {
                        for(let y = 0; y < parseInt(record[0].quantity); y++){
                            const info = {
                                "id" : y + 1,
                                "assignStatus": false,
                                "replyStatus": false,
                                "jobIDFK" : dbRec[i].id,    //id on job
                                "cardIDFK": record[x].id,  //id on card row . these should form the table name 
                                "workerIDFK" : null
                            }
                            req.db(`job_panel_${dbRec[i].id}_${record[x].id}`).insert(info)
                            .then((rec => {
                                if(res.headersSent !== true){
                                    res.status(200).send()          
                                }
                            }))
                            ////console.log("insert now")
                        }    
                      }) //then insert rows based on quantity in z_card row
                    }
                  });
                //insert rows based on z_card quantity 
            }
            
            //for each row in z_card_table_rowID. use quantity to construct z_pnale_jobID table 
        })
    }
    

}) 

    next()

}

router.get("/job-panel", createJobPanels, function(req, res, next) {
    //console.log("creating job panels")
})

function allocateWorkers(req, res, next){
    next()
}

router.get("/allocate-workers", allocateWorkers, function (req, res, next) {
    //console.log("allocating workers")
    //foreach job in roster, get id. 
    req.db("aroster_table_29/07/2022").select('id')
        .then((rosterRecord) => {
            for (let i = 0; i < rosterRecord.length; i++) {
                ////console.log(rosterRecord[0].id)
                //use each id to go to each z_card_JobID
                req.db(`z_card_${rosterRecord[i].id}`).select('id')
                    .then((zCardRec) => {
                        //console.log(zCardRec)
                        //use each each jobid and z_card id PK to iterate through each job panel row
                        for (let z = 0; z < zCardRec.length; z++)
                            req.db(`job_panel_${rosterRecord[i].id}_${zCardRec[z].id}`).select('assignStatus', 'id')
                                .then((jobPanelPosition) => {
                                    //for each job panel position
                                    for (let panelRow = 0; panelRow < jobPanelPosition.length; panelRow++) {
                                        //get assign status
                                        if (jobPanelPosition[panelRow].assignStatus === 0) { //if not filled then fill below
///------------------------------------------------------------------------------------------------                                            
                                            //get work type. use panel name data JobID_Cardid PK to go to card (using jobID) then the row using id. return work type
                                            let workType;
                                            returnWorkType(req, res, rosterRecord[i].id, zCardRec[z].id).then((str) => {
                                                workType = str
                                                let workerSkill;
                                                returnWorkerSkill(req, res, rosterRecord[i].id, zCardRec[z].id).then((str) => {
                                                    workerSkill = str
                                                    let workTime;
                                                    returnWorkTime(req, res, rosterRecord[i].id, zCardRec[z].id).then((str) => {
                                                        workTime = str
                                                        let workDuration;
                                                        returnWorkDuration(req, res, rosterRecord[i].id, zCardRec[z].id).then((str) => {
                                                            workDuration = str
                                                            let workDay;
                                                            returnWorkDay(req, res, rosterRecord[i].id, zCardRec[z].id).then((str) => {
                                                                workDay = str
///------------------------------------------------------------------------------------------------ -------------------------------    
                                                                req.db("worker_skills_availability").select('*')
                                                                    .then((skillAvailRecord) => {
                                                                        // console.log(workType)
                                                                        // console.log(workerSkill)
                                                                        // console.log(workTime)
                                                                        // console.log(workDuration)
                                                                        // console.log(workDay)
                                                                        for (let x = 0; x < skillAvailRecord.length; x++) {
                                                                            //
                                                                            checkAvailability(req, workTime, skillAvailRecord[x].id).then((tmp) => { //eg weekends
                                                                                if(tmp !== 0){ //if 0, no one available
                                                                                    //let idAvailable = tmp
                                                                                    //check not working on same day as z_card.workDay - eg check day is 0 in skills - eg workDay
                                                                                    checkDayAvailability(req, workDay, skillAvailRecord[x].id).then((tmp) => {
                                                                                        if(tmp !== 0){
                                                                                            //check worker hours are not maxed out - work duration
                                                                                            checkHoursNotMaxed(req, workDuration, skillAvailRecord[x].id).then((tmp) => {
                                                                                                if(tmp != 0){
                                                                                                    //check worker skill eg premium (level 1-4) 
                                                                                                    checkWorkerSkill(req, workerSkill, skillAvailRecord[x].id).then((tmp) => {
                                                                                                        if(tmp != 0){
                                                                                                            //check worker skills eg can handle task eg > 3
                                                                                                            checkWorkerType(req, workType ,skillAvailRecord[x].id).then((tmp) => {
                                                                                                                if(tmp != 0){
///------------------------------------------------------------------------------------------------ ------------------------------- -------------------------------------------------------------------------------------   
                                                                                                                    //assign that worker 
                                                                                                                    //assignWorker(jobID, z_cardID, panel row ID, worker ID)
                                                                                                                    //console.log("worker " + skillAvailRecord[x].id)//worker to assign
                                                                                                                    assignWorkerToPanel(skillAvailRecord[x].id, rosterRecord[i].id, zCardRec[z].id, jobPanelPosition[panelRow].id, req).then((tmp) => {
                                                                                                                        console.log("reply from assignWorekrToPanel = " + tmp)
                                                                                                                    }).catch((e) => console.log(e.message))

                                                                                                                }

                                                                                                            })
                                                                                                        }

                                                                                                    })
                                                                                                    

                                                                                                }
                                                                                            })
                                                                                        }//else skip to next id
                                                                                    })
                                                                                }
                                                                            })  
                                                                        }

                                                                    })
                                                            })
                                                        })
                                                    }) //assign value from func here
                                                        .catch((e) => console.log("promise not resolved"))
                                                })
                                            })                        
                                        } else {
                                            //position is already assign. maybe double check worker FK is present
                                        }
                                    }
                                })
                    })
            }
        })
})

async function returnWorkType(req , res, jobIdentifier, cardIDIdentifier){
    const dbRec = await req.db(`z_card_${jobIdentifier}`).where('id', '=', cardIDIdentifier).select('workerType') 
        return Promise.resolve(dbRec[0].workerType) 
}

async function returnWorkerSkill(req , res, jobIdentifier, cardIDIdentifier){
    const dbRec = await req.db(`z_card_${jobIdentifier}`).where('id', '=', cardIDIdentifier).select('workerSkill')
    return Promise.resolve(dbRec[0].workerSkill)
}
async function returnWorkDay(req, res, jobIdentifier, cardIDIdentifier){
    const dbRec = await req.db(`z_card_${jobIdentifier}`).where('id', '=', cardIDIdentifier).select('workDay')
    return Promise.resolve(dbRec[0].workDay)
}

async function returnWorkTime(req , res, jobIdentifier, cardIDIdentifier){
    //var dbRec;
        const dbRec = await req.db(`z_card_${jobIdentifier}`).where('id', '=', cardIDIdentifier).select('timeFrom', 'timeTo')
            let resolveStr = "blank"
            dateFrom = new Date(dbRec[0].timeFrom)
            dateTo = new Date(dbRec[0].timeTo)
            if(dateFrom.getDay() == 6 || dateFrom.getDay() == 0){
                console.log("weekend shift")
                if(dateFrom.getHours() >= 17){
                    resolveStr = "nw" //night weekend
                }
                if(dateFrom.getHours() < 17){
                    //day shift
                    resolveStr ="dw" //day weekdn 
                }
            }else{
                if(dateFrom.getHours() >= 17){
                    //night shift
                    resolveStr ="nd"  //nighttime weekday
                }
                if(dateFrom.getHours() < 17){
                    //day shift
                    resolveStr ="dd"
                }
            }
            return Promise.resolve(resolveStr)         
}

async function returnWorkDuration(req , res, jobIdentifier, cardIDIdentifier){
    const jobTimeRec = await req.db(`z_card_${jobIdentifier}`).where('id', '=', cardIDIdentifier).select('timeFrom', 'timeTo') 
        dateFrom = new Date(jobTimeRec[0].timeFrom)
        dateTo = new Date(jobTimeRec[0].timeTo)
        //use times to determine shift duration in hours 
        let from = parseInt(dateFrom.getHours())
        let to = parseInt(dateTo.getHours())
        return Promise.resolve(to-from) //gets duration  
}

async function checkAvailability(req, workTime, skillsTableID){
    const availRecord = await req.db(`worker_skills_availability`).where('id', '=', skillsTableID)
    .select('id','dayShift', 'nightShift', 'weekendShift')
    if(workTime === "dd"){//day 
        if(availRecord[0].dayShift == 1){
            return Promise.resolve(availRecord[0].id)
        }
    }else if(workTime === "nd"){ //night 
        if(availRecord[0].nightShift == 1){
            return Promise.resolve(availRecord[0].id)
        }
    }else if(workTime === "dw"){ //day + weekend
        if(availRecord[0].dayShift == 1 || availRecord[0].weekendShift == 1){
            return Promise.resolve(availRecord[0].id)
        }
    }else if(workTime === "nw"){ //night + weekend 
        if(availRecord[0].nightShift == 1 || availRecord[0].weekendShift == 1){
            return Promise.resolve(availRecord[0].id)
        }
    }else{
        return Promise.resolve(0) //no id found with availability for that job
    }
}

async function checkDayAvailability(req, workDay, skillsTableID){
    const availRecord = await req.db(`worker_skills_availability`).where('id', '=', skillsTableID)
    .select(`${workDay}`)
    var day = workDay
    //console.log("in checkdayavailablilitys")
    if(availRecord[0][workDay] == 0){//not filled yet
        return Promise.resolve(1)
    }else{
        return Promise.resolve(0) //fail. move to next skill id
    } 
}

async function checkHoursNotMaxed(req, workDuration, skillsTableID){
//get allocated hours and workerID in skills table. Then get maxHours using workerId in workertable.
    const availRecord = await req.db(`worker_skills_availability`).where('id', '=', skillsTableID)
    .select('allocatedHours', 'workerTableID')
    const totalHours = await req.db(`worker_table`).where('id', '=', availRecord[0].workerTableID)
    .select('maxHours')
    //check allocated + workDuration < maxHours. if yes. return true. else false
    if((parseInt(availRecord[0].allocatedHours) + parseInt(workDuration)) < parseInt(totalHours[0].maxHours)){
        return Promise.resolve(1) //pass. the skill table ID has enough hours
    }else{
        return Promise.resolve(0)
    }   
}
async function checkWorkerSkill(req, workerSkill, skillsTableID){
    //get allocated hours and workerID in skills table. Then get maxHours using workerId in workertable.
        const availRecord = await req.db(`worker_skills_availability`).where('id', '=', skillsTableID)
        .select('workerLevel')
        
        if(workerSkill ==='standard' && (parseInt(availRecord[0].workerLevel) >= 2) && (parseInt(availRecord[0].workerLevel) != 4)){
            // standard matched with level 2 and 3 workers
            return Promise.resolve(1)
        }
        else if(workerSkill == 'premium' && parseInt(availRecord[0].workerLevel) === 4){
            //match premium with only premium 
            return Promise.resolve(1)
        }
        else if(workerSkill == 'juniorOld' && (parseInt(availRecord[0].workerLevel) === 2 || parseInt(availRecord[0].workerLevel) === 3)){
            //junior 18s matched with junior 18s and standards   
            return Promise.resolve(1)         
        }
        else if(workerSkill == 'juniorYoung' && parseInt(availRecord[0].workerLevel) === 1){
            //junior with only junior 
            return Promise.resolve(1)

        }else{
            return Promise.resolve(0)
        }
}

async function checkWorkerType(req, workType, skillsTableID){
    const availRecord = await req.db(`worker_skills_availability`).where('id', '=', skillsTableID)
        .select(`${workType}`)

        if(availRecord[0][workType] >= 3){
            return Promise.resolve(1)
        }else{
            return Promise.resolve(0)
        }  
}

async function assignWorkerToPanel(skillTableID, jobID, cardID, panelRowID, req){
    //go to skills table with skills id -> get workerID
    const workerRecord = await req.db(`worker_skills_availability`).where('id', '=', skillTableID)
    .select('workerTableID')
    //go to panel_jobid_cardID //get row. where row insert workerID
    //console.log(workerRecord[0].workerTableID)
    const info = { "workerIDFK" : workerRecord[0].workerTableID}
    const assignStat = await req.db(`job_panel_${jobID}_${cardID}`).where('id', '=', panelRowID).update(info)

    //deduct from worker allocated hours
    // +1 to assignStatus col in roster table

     return Promise.resolve(1)     
}

module.exports = router;


//check roster full admin button
    //for each roster row get assign status, jobid
        //if assignstatus === jobtable.total workers where job id
        //double check that a worker is in each job panel assignworkerIDFK row. if so.. then..
        //that roster row.jobFilled == true. 
//finally iterate over whole roster, if all jobFilled == true, job is filled 



//--------------------Construct text from roster 
//first for each roster row check that jobFilled ==true. all jobs full before preceding  -> then create an empty roster text table ->createRosterTextTable()

//if above. Construct a list of every workerID (using panels) that is assign for this roster 

//for each workerID from list above. 
    //for each job row
        //for each z_card_row
            //for each panel row select panel id,jobID, cardID, workerID
                //if panel row contains that workersID
                    //createRosterTextRow(workerID, jobID, cardID)




//function createRosterTextRow(workerID, jobID, cardID)
//goto z_card_jobID . select cardID row. select workerType, timefrom, timeTo, hours total


//use jobID, goto job_table. select job date, meeting location, attire, special considerations, client_id_FK, userID
//use clientIDFK to clients table row. select from that row companyName, ContactName, contactNumber 
//insert all this information into roster text table userID as PK no not unique in table


//