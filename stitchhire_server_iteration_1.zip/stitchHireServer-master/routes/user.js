var express = require('express');
var router = express.Router();
var profileRouter = require('./profile');
var loginRouter = require('./Authentication/login');
var registerRouter = require('./Authentication/register');
var workformRouter = require('./workform')
/* GET users listing. */



router.use('/register', registerRouter);
router.use('/login', loginRouter)
router.use('/', profileRouter)
//router.use('/work', workformRouter)

module.exports = router;
