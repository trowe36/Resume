var express = require('express');
var router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');


//checks the user's email exists
router.post("/", (req, res, next) => {
  //checks body for email and password
  //console.log(req.body.email)
  if (!req.body.email || !req.body.password) {
      res.status(400).json({
          error: true,
          message: "Request body incomplete, both email and password are required"
      })
  } else {
      const person = {
          "email": req.body.email,
      };
      //query to server to check user exists
      req.db.from('users').select('email').where(person)
          .then(occurrance => {
              if (occurrance.length == 0) {
                  res.status(401).json({ error: true, message: 'Incorrect email or password' });
              }
              else {
                  next()
              }
          }).catch(error => {
            
              res.status(400).json({ message: 'Bad Request' });
          })
  }
})

//checks that the password of the body matches the password for the user in the db
router.post('/', (req, res) => {
    const{email, password} = req.body; 
    let type = null;
  //const email = req.body.email; //email has been determined as existent 
  //console.log(password)
  //console.log({email});
  req.db('users').select('*').where({email})
      .then(dbRecord => {
          //console.log(dbRecord)
          //const { hash } = Object.values(dbRecord[2])
          //console.log(password);
          //console.log(dbRecord[0].password)
          type = dbRecord[0].type;
          return bcrypt.compare(password, dbRecord[0].password)
      })
      .then((match) => {
          if(!match){
            res.status(401).json({
            error: true,
            message: "Incorrect email or password"
            })
          }
          else{
            
            const expires_in = 60 * 60 * 24;
            console.log("YES")
            const exp = Date.now() + expires_in * 1000;
            const token = jwt.sign({email, exp }, secretKey);
            res.status(200).json({ token, token_type: "Bearer", expires_in, type })
          }
      })
})


  module.exports = router; 