var express = require('express');
var router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { response } = require('express');
const secretKey = "secret key"
let tokenIsValid = false;
let responseSent = false;
let idCount = 1;

function leapYear(year)
{
  return ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
}
function notInFuture(year, month, day, todayYear, todayMonth, todayDay){
    if(year < todayYear){
        return true; 
    }
    else if (year === todayYear){
        if(month > todayMonth){
            return false; 
        }
        if(month < todayMonth){
            return true;
        }
        if(month == todayMonth){
            if(day > todayDay){
                return false;
            }
            if(day <= todayDay){
                return true;
            }
        }
    }
}

const daysMonthsInBounds = (year, month, day) => {
    const isLeap = leapYear(year);
    
    if(month === 01){
        if(day > 31){
            return false; 
        }
    }else if(month === 02){
        if(isLeap){
            console.log("month = 02 and is a leap year")
            console.log("day is eqaul to   :" + day)
            if(day > 29){
                return false; 
            }
            return true;
        }else{
            if(day > 28){
                return false
            }
            return true;           
        }
    }else if(month === 03){
        if(day > 31){
            return false;
        }return true; 
    }else if(month === 04){
        if(day > 30){
            return false;
        }return true; 
    }else if(month === 05){
        if(day > 31){
            return false;
        }return true; 
    }else if(month === 06){
        if(day > 30){
            return false;
        }return true; 
    }else if(month === 07){
        if(day > 31){
            return false;
        }return true; 
    }else if(month === 08){
        if(day > 30){
            return false;
        }return true; 
    }else if(month === 09){
        if(day > 30){
            return false;
        }return true; 
    }else if(month === 10){
        if(day > 31){
            return false;
        }return true; 
    }else if(month === 11){
        if(day > 30){
            return false;
        }return true; 
    }else if(month === 12){
        if(day > 31){
            return false;
        }return true; 
    }
    return false; 
}

function dateIsValid(dateStr, res) {
    const regex = /^\d{4}-\d{2}-\d{2}$/;
  
    if (dateStr.match(regex) === null) {
      return false;
    }else{
        //check out of bounds, rollover and valid future date (cant be these)
        const arr = dateStr.split("-");
        //console.log(arr);
        let year = parseInt(arr[0])
        let month = parseInt(arr[1])
        let day = parseInt(arr[2])
        
        const daysInBounds = daysMonthsInBounds(year, month, day)

        if(daysInBounds){
            //get current date and check entered year is not in the future 
            let today = new Date().toISOString().slice(0, 10)
            const todayArr = today.split("-")
            //console.log(todayArr)
            let todayYear = parseInt(todayArr[0])
            let todayMonth = parseInt(todayArr[1])
            let todayDay = parseInt(todayArr[2])
            if(!notInFuture(year, month, day, todayYear, todayMonth, todayDay)){
                responseSent = true;
                res.status(400).send({ error: true, message: "Invalid input, dob must be a date in the past."})
                return; 
            }
        }else{
            return false; 
        }        
        return true; 
    }
}

const tokenCheck = (req, res) => {
    const authorizationBody = req.headers.authorization;
    if (authorizationBody && authorizationBody.split(" ").length == 2) { //checking that the authorization body is sufficient (stored as string)
        token = authorizationBody.split(" ")[1]
        try {
            const decodedToken = jwt.verify(token, secretKey)
            if (decodedToken.exp < Date.now()) { //if token expired
                res.status(401).send({ error: true, "message": "JWT token has expired" })
                return;               
            }
            else {
                return decodedToken.email; //returns decoded token email for comparison in profile
            }
        } catch (e) {
            res.status(401).send({ error: true, "message": "Invalid JWT token" })
            return;
        }
    }
    else { 
        res.status(401).send({ error: true, "message": "Authorization header ('Bearer token') not found" })
        return;
        }
}

function containsNumber(str) {
    return /[0-9]/.test(str);
  }

function containsBoolean(str){
    if(str == 'true' || str == 'false'){
        return true; 
    }
}

const paramsOK = (firstname, lastname, dob, address, res) => {
    responseSent = false;
    //console.log("inside params ok");
    if ((typeof firstname !== 'string') || (typeof lastname !== 'string') || (typeof address !== 'string')) {
        //console.log("lastname,first and address must be string ")
        res.status(400).json({ error: true, message: "Request body invalid: firstName, lastName and address must be strings only." })
        return;
    }
    else if(containsNumber(firstname) || containsNumber(lastname) ){
        res.status(400).json({ error: true, message: "Request body invalid: firstName, lastName and address must be strings only." })
        return;
    }
    //check address is not a boolean
    else if(containsBoolean(address) || containsBoolean(firstname) || containsBoolean(lastname) || containsBoolean(dob)){
        res.status(400).json({ error: true, message: "Request body invalid: firstName, lastName and address must be strings only." })
        return;
    }
    if(!dateIsValid(dob, res)){ //TODO test this works 
        console.log(responseSent)
        if(!responseSent){ //avoid http headers sent error 
            res.status(400).json({ error: true, message: "Invalid input: dob must be a real date in format YYYY-MM-DD." })
            return;
        }  
        // console.log("error happening year because responseSent == " + responseSent);
        // res.status(400).json({ error: true, message: "Invalid input: dob must be a real date in format YYYY-MM-DD." })
        // return; 
    }
    //TODO check for date is in correct format here : swagger>put>error 400
    else { return true; }
}

/* GET users listing. */
router.get('/:email/profile', function(req, res, next) { /// /countries URL
    validtoken = false
    if (req.headers.authorization) {
        //this sets valid token to true then runs the token checker as the token checker function pushes to the next method
        let decoded = tokenCheck(req, res) //function created in app.js
        if ((decoded) === (req.params.email)) { //checks the token holder and the email match
            validtoken = true
        }
        next()
    }
    else {
        next()
    }
  });

//get profile 
router.get('/:email/profile', (req, res) => {
  var q;
  const user = {
      "email": req.params.email,
  };
  //creates the query dependant on the auth
  //if (validtoken) { query = req.db("accounts").select('email', 'firstname', 'lastname', 'dob', 'address').where(user) }
  //else { query = req.db("accounts").select('email', 'firstname', 'lastname').where(user); }
  //the following queries the server and then returns the appropriate information
  console.log(validtoken)
  if(validtoken){q = req.db('users').select('email', 'firstName', 'lastName', 'dob', 'address').where(user)}
  else{q = req.db('users').select('email', 'firstName', 'lastName').where(user)}
  q.then(dbRecord => {
      if (dbRecord.length == 0) {
          res.status(404).json({ error: true, message: "User not found" })
          return;
      }
      else {
          res.status(200).send(dbRecord[0]);//TODO send record based on authentication. eg return extra records
          return;
      }
  })
});

//jacbos
router.put('/:email/profile', function (req, res, next) {
    //if the user and email req match

    let decodedToken = tokenCheck(req, res)
    if ((decodedToken) === (req.params.email)) {//token does contain the email
        next();
    }
    else { 
        res.status(403).json({ error: true, message: "Forbidden" }) 
        return; 
        }

})

function firstMiddleware(req, res, next){
    //do insert 
console.log("first middleware")
req.db.from('worker_table').max('id').then(
    (id) => {
        const [objDestruc] = id;
        if(isNaN(parseFloat(Object.values(objDestruc)))){ idCount = 1}
        else{idCount = parseFloat(Object.values(objDestruc)) + 1}
    }
  )

    //else  -> goto next middleware. where its an update done. 
    req.db("users").where('email', '=', req.params.email).select('id') //updates info
    .then(dbRecord => {
      req.db("worker_table").where('userID', '=', Object.values(dbRecord[0]))
      .then(rec => {
          console.log(rec.length)
          if (rec.length == 0){ //if there exists no foreign key record. create the row. 
              const info = {
                  "id": idCount,
                  "firstName": req.body.firstName,
                  "lastName": req.body.lastName,
                  "DOB": req.body.dob,
                  "suburb": req.body.suburb,
                  "postCode": req.body.postCode,
                  "maxHours": req.body.maxHours,
                  "phoneNumber": req.body.phoneNumber,
                  "userID": Object.values(dbRecord[0])
              };
              req.db("worker_table").insert(info).
              then((rec =>{
                if(res.headersSent !== true){
                    res.status(200).send({error: false, message: "insert success"});
                    return;
                }
              })).catch(error =>{
                if(res.headersSent !== true){
                    res.status(400).send({error: true, message: "error inserting table values"})
                    return;
                }
              })
          }else if(rec.length > 1){
            next()
            //return
          }else{
            if (res.headersSent !== true){
                return res.status(400).send({error: true, message: "there was an error"})
            }            
          }
      })   
    //next()
})}

function secondMiddleware(req,res, next){
    //update
    console.log("second middleware")
    const info = {
        "firstName": req.body.firstName,
        "lastName": req.body.lastName,
        "DOB": req.body.dob,
        "suburb": req.body.suburb,
        "postCode": req.body.postCode,
        "maxHours": req.body.maxHours,
        "phoneNumber": req.body.phoneNumber
    };
    req.db("worker_table").where('userID', '=', Object.values(dbRecord[0])).update(info).then((rec =>{
        if(res.headersSent !== true){
            return res.status(200).send("success");
        }       
    ;}))
    //next()
}
router.put('/:email/profile', firstMiddleware, secondMiddleware, (req, res, next) => {

})

//jacbos
router.put('/:email/profileeeeeeeeeeeeeeeeeeee', firstMiddleware, secondMiddleware, (req, res, next) => {

  //console.log(req.params.email)
//   if (!(req.body.firstName && req.body.lastName && req.body.dob && req.body.suburb)) {
//       res.status(400).send({ error: true, message: `Request body incomplete: firstName, lastName, dob and address are required.` });
//       return; 
//   } 
  //const proceed = paramsOK(req.body.firstName, req.body.lastName, req.body.dob, req.body.address, res)
  let proceed = true;
    if(proceed) { //TODO comment this out
        
    console.log("line 119 params are deemed ok")
      const skills = {
        "cockAttendant": req.body.cockAttendant,
        "barista": req.body.barista,
        "management": req.body.management,
        "frontHouse": req.body.frontHouse,
        "backHouse" : req.body.backHouse,
        "chef": req.body.chef
      }     
    }
    //return res.status(499).send(error: false, message: "fadf")
    return;
});

  module.exports = router; 