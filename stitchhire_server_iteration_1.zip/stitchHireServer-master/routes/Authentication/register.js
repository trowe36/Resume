var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt')
var idCount = 1;
//First check input of user to be registered. check body contains correct value and if user already exists 
router.post("/", (req, res, next) => {
  req.db.from('users').max('id').then(
    (id) => {
        const [objDestruc] = id;
        if(isNaN(parseFloat(Object.values(objDestruc)))){ idCount = 1}
        else{idCount = parseFloat(Object.values(objDestruc)) + 1}
    }
  )
  if (!req.body.email || !req.body.password) {
      res.status(400).send({ 
        Error: 'true', 
        message: "Request body incomplete, both email and password are required" 
    });
  } else {
      const user = {
          "email": req.body.email
      };
      req.db.from('users').select('email').where(user)
          .then(dbRecord => {
              if (dbRecord.length == 0) {
                  next()
              }
              else {
                  res.status(409).json({ 
                    error: true, 
                    message: 'User already exists' 
                });
              }
          }).catch(error => {
              console.log(error);
              res.status(400).json({ message: 'Bad Request' });
          })
  }
})

//practical 10
//Create new user and insert into database 
router.post('/', (req, res) => {
  const{email, password, type} = req.body;
  const hash = bcrypt.hashSync(password, 10)

  const user = {
      "id" : idCount, 
      "email": email,
      "password": hash,
      "type": type
  };

  req.db("users").insert(user)
      .then(dbRecord => {
          res.status(201).json({ 
            message: 'User created' 
        });
      }).catch(e => {
          res.status(500).json({ 
            message: 'Database error - not updated' 
        });
      })
});

module.exports = router; 
