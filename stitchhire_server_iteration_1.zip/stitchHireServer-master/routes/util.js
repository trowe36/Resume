module.exports = {
    getCardHours: function (from, to) {
        const fromTime = new Date(from)
        const toTime = new Date(to)
        var diff = (toTime.getTime() - fromTime.getTime()) / 1000;
        diff /= (60 * 60);
        return Math.abs(Math.round(diff));
        //return 10;
    },
    getJobDay: function (from) {
        // whatever
        const fromTime = new Date(from)
        const dayIndex = fromTime.getDay()

        if (dayIndex == 0) {
            return 'sun'
        } else if (dayIndex == 1) {
            return 'mon'

        } else if (dayIndex == 2) {
            return 'tue'

        } else if (dayIndex == 3) {
            return 'wed'

        } else if (dayIndex == 4) {
            return 'thur'

        }
        else if (dayIndex == 5) {
            return 'fri'
        }
        else if (dayIndex == 6) {
            return 'sat'
        }
    }
};
