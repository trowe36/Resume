var express = require('express');
var router = express.Router();
var utils = require('./util');
let idCount = 0;
let jobID; 
/* GET home page. */
//we use express to serve api endpoints, not serve webpages or html docs 
// var countriesRouter = require('./Data/countries');
// var volcanoesRouter = require('./Data/volcanoes');
// var volcanoRouter = require('./Data/volcano');

// router.use('/countries', countriesRouter);
// router.use('/volcano', volcanoRouter)
// router.use('/volcanoes' , volcanoesRouter)

router.get('/me', function(req,res){
    res.status(200).json({
        name: "Thomas Rowen",
        student_number: "n9968075"
    })
})


function handleJobInsert(req,res,next){
    req.db.from('jobs_table').max('id').then(
        (id) => {
            const [objDestruc] = id;
            if(isNaN(parseFloat(Object.values(objDestruc)))){ idCount = 1}
            else{idCount = parseFloat(Object.values(objDestruc)) + 1}
        }
      ).catch(error => {console.log(error)})
      req.db("users").where('email', '=', req.params.email).select('id') //updates info
      .then(dbRecord => {
        
        jobID = idCount// used later in job card to reference this table
        currUserID = Object.values(dbRecord[0])
        req.db("clients_table").where('userIDclient', '=', currUserID).select('id')
        .then(rec => {
            let clientID = Object.values(rec[0])         
            //console.log("rec = " + Object.values(rec[0]))
             //if there exists no foreign key record. create the row. 
                const info = {
                    "id": idCount,
                    "totalWorkers": req.body.totalWorkers,
                    "workerAssignStatus": 0,
                    "jobDate": req.body.date,
                    "meetingLocation": req.body.meetingLocation,
                    "attire": req.body.dress,
                    "specialConsideration": req.body.notes,
                    "client_id_FK": clientID,
                    "user_id_FK": currUserID
                };
                req.db("jobs_table").insert(info).
                then((rec =>{
                  if(res.headersSent !== true){
                    
                      //return res.status(200).send({error: false, message: "insert success"});
                      next()
                  }
                })) 
                .catch(error => {
                    console.log(error)
                })
                next()            
              })
            .catch(error => {
                console.log(error);
      })}).catch(error => {console.log(error)})
      //get the user id
      //ues user id to get client id

    // console.log(req.params.email)
    // console.log(req.body)
    // console.log(req.body.stateObj)
    // console.log("----------------------------")
    // console.log(req.body.stateObj[1])
    // next()
}
function createTable(req,res,next){

    req.db.schema.createTable(`z_card_${jobID}`, table => {
        table.integer('id').primary();
        table.string('workerType', 45);
        table.string('workerSkill', 45);
        table.integer('quantity');
        table.string('timeFrom');
        table.string('timeTo');
        table.integer('hoursTotal');
        table.string('workDay', 10);
        table.integer('jobTableFK');
        table.foreign('jobTableFK').references('id').inTable('jobs_table')
       }).then((prom) => {
        next()
       })
}



function getUserJobDetails(req,res,next){
           //then do this. needed for next middleware
           req.db("users").where('email', '=', req.params.email).select('id') //updates info
           .then(dbRecord => {
             currUserID = Object.values(dbRecord[0])
             console.log( "logging userID" + Object.values(dbRecord[0]))
             req.db("jobs_table").where('user_id_FK', '=', currUserID).select('id')
             .then(rec => {
                 console.log("logging job ID" + Object.values(rec[0]))
                 //jobID = Object.values(rec[0])
                 next()
             }
             )
             //next()
           })
    //next()
}

router.put('/:email/workform', handleJobInsert, createTable , getUserJobDetails, (req, res) => {
 for(let i = 0; i <= 4; i++){ //only 5 job cards allowed at this time
    let hours = utils.getCardHours(req.body.stateObj[i+ 1].timeFromX, req.body.stateObj[i+ 1].timeToY)
    let jobDay = utils.getJobDay(req.body.stateObj[i+ 1].timeFromX)
     if(req.body.stateObj[i + 1].workerSkill !== ''){
        const info = {
            "id" :  i + 1,
             "workerType" : req.body.stateObj[i+ 1].workerType,
             "workerSkill" : req.body.stateObj[i+ 1].workerSkill,
            "quantity" :req.body.stateObj[i+ 1].requiredWorkers,
            "timeFrom": req.body.stateObj[i+ 1].timeFromX,
            "timeTo" : req.body.stateObj[i+ 1].timeToY,
            "workDay" : jobDay,
            "hoursTotal" : hours,
            "jobTableFK": jobID
        }
        req.db(`z_card_${jobID}`).insert(info)
        .then((rec => {
            if(res.headersSent !== true){
                //res.status(200).send()          
            }
        })).catch(error => {console.log(error.message)})}}




if(headersSent !== true){
    return res.status(200)
}
    
})


module.exports = router;
