// var cron = require('node-cron');

const knexfile = require("../knexfile");
var http = require('http')
// var cron = require('node-cron');

// var task = cron.schedule('* * * * *', () =>  {
//   console.log('stopped task');
// }, {
//   scheduled: false
// });


//get roster one start date const value (TODO: have fetch middleware for admin to update value )
var roster_start = new Date('07/18/2022')
 var ddd = String(roster_start.getDate()).padStart(2, '0');
 var mmm = String(roster_start.getMonth() + 1).padStart(2, '0'); //January is 0!
 var yyy = roster_start.getFullYear();

// //var intdd = parseInt(String(roster_start.getMonth() + 1).padStart(2, '0'))
 roster_start = mmm + '/' + ddd + '/' + yyy;


function CallDB(){

    var options = {
        host: 'http://localhost:3001/api/me',
        //path: ''
      };
      
    //   var req = http.get(options, function(res) {
    //     console.log('STATUS: ' + res.statusCode);
    //     console.log('HEADERS: ' + JSON.stringify(res.headers));})
    //     req.on('error', function(e) {
    //         console.log('ERROR: ' + e.message);
    //       });

    // req.db.hasTable(`aroster_table_${ddd}_${mmm}_${yyy}`).then(function(exists){
    //         if(!exists){
    //             return knex.schema.createTable(`aroster_table_${ddd}_${mmm}_${yyy}`, function(t) {
    //                 t.increments('id').primary();
    //                 t.boolean('jobFilled')
    //                 t.boolean('assignStatus')
    //                 t.boolean('replyStatus')
    //               });
    //         }else{console.log("table exists in db")}
    //     })
        //if cant access the req object. do a fetch call to api middlware, have that create the table if not exists. 
}

module.exports = {
    cronTest: function () {      

            console.log(roster_start)
            //everyday
            //first watcher: checks the roster start date and creates the table filling it with jobs for that roster 
    
            //get todays date 
            //const date = new Date()
            var today = new Date();
            var dd = String(today.getDate()).padStart(2, '0');
            var todayddInt = parseInt(dd)
            todayddInt += 7; //check a week ahead
            var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            var yyyy = today.getFullYear();
            today = dd + '/' + mm + '/' + yyyy;
    
            console.log(todayddInt)
            console.log(roster_start)
            console.log(parseInt(ddd))
    
            if (todayddInt >= ddd){ //if todays date is within 7 days of roster start date -> create roster 
                console.log(`roster_table_${ddd}_${mmm}_${yyy}`) //
                //create table if not exists roster_1_DATE
                CallDB()
                console.log('after db method')
                // knex.schema.hasTable(`aroster_table_${ddd}_${mmm}_${yyy}`).then(function(exists){
                //     if(!exists){
                //         return knex.schema.createTable(`aroster_table_${ddd}_${mmm}_${yyy}`, function(t) {
                //             t.increments('id').primary();
                //             t.boolean('jobFilled')
                //             t.boolean('assignStatus')
                //             t.boolean('replyStatus')
                //           });
                //     }else{console.log("table exists in db")}
                // })
    
            }
            //then
            //foreach row in jobs_table
            //check date. if falls within roster start - end date. add to table roster is mon-Sun 
            
    
            
    
            //get roster_1 start date (should be in roster 1 title )
    
            //if todays date (sun) is 8 days away from roster start (next monday)
    
                    //for each job_table date that falls within roster 
                    //add job to roster_table
    
    //set roster_fill to complete  when roster_table_DATE is full. for each job creates many job_panels 
    
    //----then 
    
    //foreach job in the roster_table if roster_fill == complete 
    
    //go to jobs_card_jobID
        //for each row in job_card
            //create a jobs_panel_jobID table (therefore, only needing to be filled jobs_panels at any one time)
    
    
        
        } 

        }






//second watcher: once a day 
//main pseuodocode algorithm - 
//eg foreach row in roster, foreach panel_table for that roster, foreach row in panel table -> fill ->update panel row stat. after fill -> check 
//all panel row status == true. Then set card_row == true using card_FK in panel table. 

//once all panels should have been attempted to fill and status attempted change etc 
//For each job in roster
    //foreach card_table row for that job id. if == true
    //set that job row in roster_table == true. --> links to third watcher


//third watcher: once a day 
//iterates over all roster_1 jobs. for each job, check status. if all rows have status == true. and roseter !=textSent -> constructText()

//


